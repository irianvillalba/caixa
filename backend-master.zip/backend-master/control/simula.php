<?php

print date('Y-m-d H:i:s');

Transaction::open('database');
$logger = isset($this->logger) ? $this->logger : NULL;
Transaction::setLogger($logger);
