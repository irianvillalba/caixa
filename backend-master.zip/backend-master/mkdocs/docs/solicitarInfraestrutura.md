Gera uma solicitação de infraestrutura pendente de relacionamento.

|MÉTODO|CHAMADA|
|:----------|:-----------|
|POST|https://infra.devops.caixa/api/api.php?acao=solicitarInfraestrutura|

-----

#### Parâmetros obrigatórios

|PARÂMETRO|DESCRIÇÃO|
|:----------|:-----------|
|**sistema**|Nome do Sistema.|
|**repositorio**|URL do repositório criado para o sistema no ADS.|
|**plataforma**|Plataforma a ser utilizada pelo sistema.|
|**versao**|Versão da plataforma a ser utilizada.|
|**solicitante**|Matrícula do solicitante.|
|**ambientes**|Ambiente de execução do sistema.|
|**backends**|Backends que serão utilizados pelo sistema.|

-----

#### Exemplo de JSON a ser usado na chamada

```json
{
  "sistema": "sitre",
  "repositorio": "http://labdevops.caixa/DefaultCollection/template_JAVA/_git/siads_ptr",
  "plataforma": "jboss",
	"versao": "7",
  "solicitante": "c080028",
  "centralizadora": "ceptirj",
	"ambientes": [
			"des"
	],
	 "backends": [
    "oracle",
			"mq"
  ]
}
```