<?php

class Solicitacao extends Record {
    
    const TABLENAME = 'solicitacoes_infra';
    
}