<?php
    class ConfigTask {

        //ENDPOINTS
        const ENDPOINT_REQ      		= "/api/arsys/v1/entry/GSC:RF223:IntSRM_Definicao?fields=values(GSC_chrIDRegistro,GSC_chrNumeroRequisicao)";
        const ENDPOINT_QUESTIONARIO     = "/api/arsys/v1/entry/GSC:RF224:IntSRM_Perguntas?fields=values(GSC_chrIDRegistro)";
        const ENDPOINT_PROCESSAREQ      = "/api/arsys/v1/entry/GSC:RF223:IntSRM_Definicao";
        const ENDPOINT_LOGIN 			= "/api/jwt/login";
        const ENDPOINT_LOGOUT 			= "/api/jwt/logout";
        const API_HMP                   = "http://scthmapllx0106.df.caixa:8008";
        const API_PRD                   = "http://cctdcapllx0388.df.caixa:8008";

        
        const ENDPOINT_ALLOCATION_CRQ 	= "/api/arsys/v1/entry/CHG:CFG%20Ticket%20Num%20Generator/";
        const ENDPOINT_GET_PEOPLE 		= "/api/arsys/v1/entry/CTM:People/";
        const ENDPOINT_CREATE_CHANGE 	= "/api/arsys/v1/entry/CHG:ChangeInterface_Create/";
        const ENDPOINT_QUERY_CHANGE 	= "/api/arsys/v1/entry/CHG:Infrastructure%20Change/";

        

        public $paramTask = [
            'log' => array("values" => array(
                "z1D_WorkInfoType" => "General Information",
                "z1D_WorkInfoSecureLog" => "Yes",
                "z1D_WorkInfoViewAccess" => "Public",
                "z1D_WorkInfoSummary" => "{Sumário da Tarefa}",
                "z1D_WorkInfoNotes" => "{Descrição Detalhada}"
            )),
            'andamento' => array("values" => array(
                "Status" => "Work In Progress",
                "StatusReasonSelection" => null
            )),
            'fechamento' => array("values" => array(
                "Status" => "Closed",
                "StatusReasonSelection" => "Success"
            ))

        ];
    }
?>