<?php

class Usuario extends Record {
    
    const TABLENAME = 'usuarios';
    
}

