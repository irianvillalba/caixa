<?php

function relatorioInventario() {
    try {
      Transaction::open('database');
      $db = Transaction::get();
      $arrayBindValue = [ ];

      $sql = "SELECT DISTINCT si.modulo, si.ambiente, s.plataforma, s.site, p.plataforma tecnologia, TO_CHAR(si.data_solicitacao, 'DD/MM/YYYY') as dt_inclusao
      FROM solicitacoes_infra si
      FULL JOIN solicitacoes_plataforma sp ON sp.id_solicitacao = si.id
      full JOIN plataforma p ON p.id_plataforma = sp.id_plataforma
      INNER JOIN servidores s ON s.sistema = si.modulo
     WHERE si.status = 'ativado' and s.status = 'ativado'";

      $statement = $db->prepare($sql);
      
      $statement->execute();
      $registros = $statement->rowCount();
      $arrayResultado = array();
      $arrayResultado["registros"] = $registros;
      
      if ($registros == 0) {
        $array['info'] = "não foram encontrados resultados.";
        return $array;
        die;
      }

      foreach ($statement as $row ) {
        
        $arrayRetorno[] = array (
        'modulo' => $row['modulo'],
        'ambiente' => $row['ambiente'],
        'plataforma' => $row['plataforma'],
        'tecnologia' => $row['tecnologia'],
        'site' => $row['site'],
        'dt_inclusao' => $row['dt_inclusao']
        );
      }
      
      $arrayResultado["dados"] = $arrayRetorno;
      
      return $arrayResultado;
      } catch ( Exception $e ) {
      $array = [];
      $array['erro'] = "erro execucao da query";
      Transaction::close ();
      return $array;
      } finally {
      Transaction::close ();
    }    
  }
?>