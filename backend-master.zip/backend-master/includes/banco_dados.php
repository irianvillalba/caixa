<?php
ini_set("xdebug.var_display_max_children", -1);
ini_set("xdebug.var_display_max_data", -1);
ini_set("xdebug.var_display_max_depth", -1);

class BancoDados
{
    public function criarReqBancoDados($json)
    {
        $retorno = [];

        try {
            $gsc = new GSCClient(gsc_endpoint, gsc_user, gsc_password);

            if ($gsc->connected == false) {
                $retorno = [
                    "title" => 'ERRO_API',
                    "mensagem" => 'Erro na comunicação com a API do GSC'
                ];
                return;
            }

            // Criando a capa da requisição
            // Retorno é o id do formulário da requisição
            $capa = $gsc->recPostDefinitition('Multiplataforma - Criar Instância / Database de Banco de Dados', gsc_instance_id_banco_dados, gsc_user, gsc_user);

            if (isset($capa->error)) {
                $retorno = [
                    "title" => 'ERRO_API',
                    "mensagem" => $capa->error
                ];

                return;
            }

            $registerId = $capa->values->GSC_chrIDRegistro;

            $perguntas = [
                'Informar a unidade demandante' => $json->unDemandante,
                'Selecionar a área de operações responsável pela sustentação do serviço' => $json->loc,
                'Selecionar em qual ambiente a instância será criada' => $json->environment,
                'Informar o character enconding' => $json->charset,
                'Informar o tamanho inicial' => $json->tam . "GB",
                'Informar a taxa de crescimento' => $json->txCres . $json->uni . '/' . $json->periodCres,
                'Informar o nome da instância' => $json->name,
                'Informar qual SGBD e versão' => $json->sgbd,
                'Informar o serviço que utilizará a instância' => $json->system,
                'Informar telefones para contato' => $json->phone,
                'Informar caixa postal da unidade demandante' => $json->mail,
                'Informar mais detalhes sobre o atendimento a ser realizado' => $json->details
                    . ' - Área de sustentação do serviço: ' . $json->areaSust
                    . ' - Disponibilidade: ' . $json->availability
                    . ($json->obs != null ? ' - ' . $json->obs : '')
            ];

            foreach ($perguntas as $chave => $valor) {
                $q = ['values' => [
                    'GSC_chrIDRegistroPai' => $registerId,
                    'GSC_chrPergunta' => $chave,
                    'GSC_chrResposta' => $valor
                ]];

                $gsc->recPostQuestion($registerId, $q);
            }

            //atualizando a requisição
            $gsc->recPutProcess($registerId, "Inicio");

            $requestNumber =  $gsc->recGetRequestNumber($registerId);

            if ($requestNumber->entries[0]->values->GSC_chrNumeroRequisicao == 'ERRO') {
                $retorno = [
                    "title" => 'ERRO_API',
                    "mensagem" => $requestNumber->entries[0]->values->GSC_chrMensagem
                ];

                return;
            }

            $numreq = $requestNumber->entries[0]->values->GSC_chrNumeroRequisicao;

            //RETORNANDO REQ
            $retorno = [
                "title" => 'OK',
                "requisicao" => $numreq,
                "mensagem" => $requestNumber->entries[0]->values->GSC_chrMensagem,
                "registroPai" => $requestNumber->entries[0]->values->GSC_chrIDRegistro
            ];
        } catch (\Exception $e) {
            $retorno = [
                "title" => 'ERRO',
                "mensagem" => $e->getMessage()
            ];
        } finally {
            $gsc = null;

            return  $retorno;
        }
    }
}
