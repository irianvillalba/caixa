<?php




function editarNfs($json_post)
{

  $json_post_encoded["dados"] = json_decode($json_post, true);
  $json_post_encoded["dados"]["data_cadastro"] = date('Y-m-d H:i:s');
  $json_post_encoded["dados"]["status"] = "ativado";


  try {
    Transaction::open('database');
    $db = Transaction::get();

    $db->exec("UPDATE backends SET 
      nome = '{$json_post_encoded['dados']['nome']}',
      ambiente = '{$json_post_encoded['dados']['ambiente']}',
      ip = '{$json_post_encoded['dados']['ip']}',
      porta = {$json_post_encoded['dados']['porta']},
      id_tipo_nfs = {$json_post_encoded['dados']['tipo_nfs']}
      where id = {$json_post_encoded['dados']['id']}");

    $json_post_encoded["retorno"]["status"] = "sucesso";
    $json_post_encoded["retorno"]["mensagem"] = "cadastro atualizado com sucesso!";
    http_response_code(201);
  } catch (Exception $e) {
    $json_post_encoded["retorno"]["status"] = "erro";
    $json_post_encoded["retorno"]["mensagem"] = "Erro ao salvar o item. Descrição: {$e->getMessage()}";
  } finally {
    Transaction::close();
  }

  return ($json_post_encoded);
}

function editarInfraestrutura($json_post)
{

  $array_json["dados"] = json_decode($json_post, true);
  $array_json["dados"]["data_solicitacao"] = date('Y-m-d H:i:s');
  $array_json["dados"]["status"] = "ativado";

  try {

    Transaction::open('database');
    $db = Transaction::get();
    $sistema = strtolower($array_json["dados"]["sistema"]);
    $backends = json_encode($array_json["dados"]["backends"]);
    $sol = json_encode($array_json["dados"]);
    $db->exec("UPDATE solicitacoes_infra SET 
      modulo = '{$sistema}',
      solicitante = '{$array_json["dados"]["solicitante"]}',
      backends = '{$backends}',
      centralizadora = '{$array_json["dados"]["centralizadora"]}',
      json_solicitacao = '{$sol}'
      where id = {$array_json['dados']['id']}");

    $db->exec("delete from solicitacoes_plataforma where id_solicitacao = {$array_json['dados']['id']}");
    $db->exec("delete from solicitacoes_tipo_backends where id_solicitacao = {$array_json['dados']['id']}");

    foreach ($array_json["dados"]["plataforma"] as $plataforma) {
      if (isset($plataforma['id_plataforma']))
        $id = $plataforma['id_plataforma'];
      else
        $id = $plataforma;
      $db->exec("INSERT INTO solicitacoes_plataforma (id_solicitacao, id_plataforma, data_inclusao) values ({$array_json['dados']['id']},{$id}, '{$array_json["dados"]["data_solicitacao"]}')");
    }

    foreach ($array_json["dados"]["backends"] as $backend) {
      $id_tipo_backend = getIDTipoBackend($backend);
      $id_tipo_backend = $id_tipo_backend["dados"][0]["id"];
      relacionarSolicitacaoTipoBackend($array_json['dados']['id'], $id_tipo_backend, $array_json["dados"]["data_solicitacao"], $array_json["dados"]["ambiente"], "novo");
    }

    $array_json["retorno"]["status"] = "sucesso";
    $array_json["retorno"]["mensagem"] = "solicitacao de infraestrutura atualizada!";

    http_response_code(201);
  } catch (Exception $e) {
    $array_json["retorno"]["status"] = "erro";
    $array_json["retorno"]["mensagem"] = "Erro ao criar solicitacao. Descrição: {$e->getMessage()}";
  } finally {
    Transaction::close();
  }

  return ($array_json);
}

function cadastrarNfs($json_post)
{

  $json_post_encoded["dados"] = json_decode($json_post, true);
  $json_post_encoded["dados"]["data_cadastro"] = date('Y-m-d H:i:s');
  $json_post_encoded["dados"]["status"] = "ativado";


  try {
    Transaction::open('database');
    $criteria = new Criteria();
    $criteria->add(new Filter('nome', '=', $json_post_encoded["dados"]["nome"]));
    $criteria->add(new Filter('status', '=', 'ativado'));
    $criteria->add(new Filter('ambiente', '=', $json_post_encoded["dados"]["ambiente"]));
    $backend = Backend::all($criteria);
    if ((empty($backend)) or ($backend === NULL)) {

      $backend = new Backend();
      $backend->nome = $json_post_encoded["dados"]["nome"];
      $backend->tipo = 23;
      $backend->id_tipo_nfs = $json_post_encoded["dados"]["tipo_nfs"];
      $backend->ambiente = $json_post_encoded["dados"]["ambiente"];
      $backend->ip = $json_post_encoded["dados"]["ip"];
      $backend->porta = $json_post_encoded["dados"]["porta"];

      $backend->data_cadastro = $json_post_encoded["dados"]["data_cadastro"];
      $backend->status = $json_post_encoded["dados"]["status"];
      $backend->store();

      $json_post_encoded["retorno"]["status"] = "sucesso";
      $json_post_encoded["retorno"]["mensagem"] = "cadastro realizado com sucesso!";
      http_response_code(201);
    } else {
      $json_post_encoded["retorno"]["status"] = "erro";
      $json_post_encoded["retorno"]["mensagem"] = "Erro ao salvar: item já cadastrado na base!";
    }
  } catch (Exception $e) {
    $json_post_encoded["retorno"]["status"] = "erro";
    $json_post_encoded["retorno"]["mensagem"] = "Erro ao salvar o item. Descrição: {$e->getMessage()}";
  } finally {
    Transaction::close();
  }

  return ($json_post_encoded);
}

function cadastrarPlataforma($json_post)
{

  $json_post_encoded["dados"] = json_decode($json_post, true);

  try {
    Transaction::open('database');
    $criteria = new Criteria();
    $criteria->add(new Filter('plataforma', '=', $json_post_encoded["dados"]["plataforma"]));
    $criteria->add(new Filter('versao', '=', $json_post_encoded["dados"]["versao"]));
    $plataforma = Plataforma::all($criteria);
    if ((empty($plataforma)) or ($plataforma === NULL)) {

      $plataforma = new Plataforma();
      $plataforma->plataforma = $json_post_encoded["dados"]["plataforma"];
      $plataforma->versao = $json_post_encoded["dados"]["versao"];
      $plataforma->store();

      $json_post_encoded["retorno"]["status"] = "sucesso";
      $json_post_encoded["retorno"]["mensagem"] = "cadastro realizado com sucesso!";
      http_response_code(201);
    } else {
      $json_post_encoded["retorno"]["status"] = "erro";
      $json_post_encoded["retorno"]["mensagem"] = "item já cadastrado na base!";
    }
  } catch (Exception $e) {
    $json_post_encoded["retorno"]["status"] = "erro";
    $json_post_encoded["retorno"]["mensagem"] = "Erro salvar o item. Descrição: {$e->getMessage()}";
  } finally {
    Transaction::close();
  }

  return ($json_post_encoded);
}



function setLog($acao, $matricula, $info, $metodo)
{
  $data = date('Y-m-d H:i:s');
  try {
    Transaction::open('database');
    $db = Transaction::get();
    $db->exec("insert into log (acao, matricula, dados, datahora, metodo) values ('{$acao}', '{$matricula}', '{$info}', '{$data}', '{$metodo}')");
  } catch (Exception $e) {
    $array = [];
    $array['erro'] = "erro execucao da query";
    Transaction::close();
    return $array;
  } finally {
    Transaction::close();
  }
}

function autenticarUsuario($json_post)
{
  $json_post_decoded = json_decode($json_post, true);
  $uri = new URI();
  $url = $uri->base();
  $site = strripos($url, 'portal-api');

  if (!$site) {
    $auth = new Autentica();
    $perfil = $auth->existeNoAD($json_post_decoded["usuario"], $json_post_decoded["senha"]);
  } else {
    $perfil['status'] = true;
    $perfil['nome'] = "Usuário Teste";
  }

  return $perfil;
}


function removerPlataforma($json)
{

  $arrayJson = json_decode($json, true);

  $id = $arrayJson['id_plataforma'];
  $nome = $arrayJson['plataforma'];

  try {
    Transaction::open('database');
    $db = Transaction::get();
    $db->exec("delete from plataforma where id_plataforma = {$id}");
    $mensagem = "plataforma excluida com sucesso";
  } catch (Exception $e) {
    $mensagem = "Ao excluir a plataforma: {$nome}. Descricao: {$e->getMessage()}";
  } finally {
    Transaction::close();
  }

  return ($mensagem);
}

function removerSolicitacao($json)
{

  $arrayJson = json_decode($json, true);

  $id = $arrayJson['id'];
  $sistema = $arrayJson['sistema'];

  try {
    Transaction::open('database');
    $db = Transaction::get();

    $criteria = new Criteria();
    $criteriaBck = new Criteria();

    $criteria->add(new Filter('id', '=', $id));
    $criteriaBck->add(new Filter('id_solicitacao', '=', $id));
    $solicitacao_criteria = Solicitacao::all($criteria);
    $solicitacao_bck = SolicitacoesTipoBackends::all($criteriaBck);

    if ((empty($solicitacao_criteria)) or ($solicitacao_criteria === NULL)) {
      $mensagem = "A solicitação com nome {$arrayJson['sistema']} não foi encontrado.";
      http_response_code(400);
    } else {

      foreach ($solicitacao_bck as $bck) {
        $bck->status = "desativado";
        $bck->data_atualizacao = date('Y-m-d H:i:s');
        $bck->store();
      }

      $ambientes = ["des", "tqs", "hmp", "prd"];
      $pos = array_search($arrayJson['ambiente'], $ambientes);

      if ($pos > 0) {
        $sql = "update solicitacoes_infra set evolui = 'sim' where ambiente = '{$ambientes[$pos - 1]}' and modulo = '{$arrayJson['sistema']}'";
        $db->exec($sql);
      }

      $solicitacao = $solicitacao_criteria[0];
      $solicitacao->status = "desativado";
      $solicitacao->data_atualizacao = date('Y-m-d H:i:s');
      $solicitacao->store();
      $mensagem = "A solicitação {$sistema} foi desabilitada.";
      http_response_code(201);
    }
  } catch (Exception $e) {
    $mensagem = "Ao gravar dados da Solicitação: {$sistema}. Descricao: {$e->getMessage()}";
  } finally {
    Transaction::close();
  }

  return ($mensagem);
}

function solicitarInfraestrutura($json_post)
{

  $array_json["dados"] = json_decode($json_post, true);
  $array_json["dados"]["data_solicitacao"] = date('Y-m-d H:i:s');
  $array_json["dados"]["status"] = "ativado";

  try {
    Transaction::open('database');
    $db = Transaction::get();
    $ambientes = ["des", "tqs", "hmp", "prd"];
    $pos = array_search($array_json["dados"]["ambiente"], $ambientes);
    if (isset($array_json["dados"]["id"])) {
      $sql = "update solicitacoes_infra SET evolui = 'nao' where id= {$array_json["dados"]["id"]}";
      $db->exec($sql);
    }
    $sistema = trim(strtolower($array_json["dados"]["sistema"]));

    if ($pos <= 2) {
      $sql = "select id from solicitacoes_infra where modulo = '{$sistema}' and ambiente='{$ambientes[$pos + 1]}' and status='ativado'";
      $res = $db->query($sql, PDO::FETCH_ASSOC);
      $row = $res->fetch();
    }

    if (isset($row['id']))
      $array_json["dados"]["evolui"] = 'não';

    $solicitacao = new Solicitacao();
    $solicitacao->modulo = $sistema;
    $solicitacao->solicitante = $array_json["dados"]["solicitante"];
    $solicitacao->backends = json_encode($array_json["dados"]["backends"]);
    $solicitacao->centralizadora = isset($array_json["dados"]["centralizadora"]) ? $array_json["dados"]["centralizadora"] : null;
    $solicitacao->data_solicitacao = $array_json["dados"]["data_solicitacao"];
    $array_json["dados"]["ambientes"] = array($array_json["dados"]["ambiente"]);
    $solicitacao->json_solicitacao = json_encode($array_json["dados"]);
    $solicitacao->evolui = $array_json["dados"]["evolui"];
    $solicitacao->id_sistema = $array_json["dados"]["id_sistema"];
    $solicitacao->id_limites_cotas = $array_json["dados"]["id_cota"];

    if (!empty($array_json["dados"]["solicitacao_pai"])) {
      $solicitacao->solicitacao_pai = $array_json["dados"]["solicitacao_pai"];
    }

    $solicitacao->status = $array_json["dados"]["status"];
    $solicitacao->ambiente = $array_json["dados"]["ambiente"];

    $solicitacao->store();

    $array_json["retorno"]["status"] = "sucesso";
    $array_json["retorno"]["mensagem"] = "solicitacao de infraestrutura enviada!";
    $id_solicitacao = getIDSolicitacao($array_json["dados"]["data_solicitacao"]);
    $array_json["retorno"]["id_solicitacao"] = $id_solicitacao["dados"][0]["id"];


    foreach ($array_json["dados"]["plataforma"] as $plataforma) {
      if (isset($plataforma['id_plataforma']))
        $id = $plataforma['id_plataforma'];
      else
        $id = $plataforma;
      $db->exec("INSERT INTO solicitacoes_plataforma (id_solicitacao, id_plataforma, data_inclusao) values ({$id_solicitacao["dados"][0]["id"]},{$id}, '{$array_json["dados"]["data_solicitacao"]}')");
    }

    // desativando a solicitacao pai
    // atualizarSolicitacaoInfraestrutura($array_json["dados"]["solicitacao_pai"], "desativado");


    foreach ($array_json["dados"]["ambientes"] as $ambiente) {

      foreach ($array_json["dados"]["backends"] as $backend) {
        $id_tipo_backend = getIDTipoBackend($backend);
        $id_tipo_backend = $id_tipo_backend["dados"][0]["id"];
        relacionarSolicitacaoTipoBackend($id_solicitacao["dados"][0]["id"], $id_tipo_backend, $array_json["dados"]["data_solicitacao"], $ambiente, "novo");
      }
    }

    http_response_code(201);
  } catch (Exception $e) {
    $array_json["retorno"]["status"] = "erro";
    $array_json["retorno"]["mensagem"] = "Erro ao criar solicitacao. Descrição: {$e->getMessage()}";
  } finally {
    Transaction::close();
  }

  return ($array_json);
}


function personalizarCotas($json_post)
{

  $json_post_encoded["dados"] = json_decode($json_post, true);
  $json_post_encoded["dados"]["data_inclusao"] = date('Y-m-d H:i:s');

  $validacao = true;
  $erros = [];

  // validações antes de cadastrar cotas
  Transaction::open('database');
  $db = Transaction::get();

  if (isset($json_post_encoded["dados"]["modulo"])) {
    $res = $db->query("select count(id_limites_cotas) as qtd  from solicitacao_limites_cotas where modulo = '{$json_post_encoded["dados"]["modulo"]}' and ambiente='{$json_post_encoded["dados"]["ambiente"]}' ", PDO::FETCH_ASSOC)->fetch();

    if ($res['qtd'] > 0) {
      $validacao = false;
      array_push($erros, "Limites e cotas já está cadastrada para esse modulo e ambiente");
    }
  }

  try {
    if ($validacao) {
      $criteria_servidores = new Criteria();
      $servidor = Cota::all($criteria_servidores);

      $reg = $db->query("select * from limites_cotas where ambiente = '{$json_post_encoded["dados"]["ambiente"]}' and classe = {$json_post_encoded["dados"]["classe"]} and tipo = '{$json_post_encoded["dados"]["plataforma"]}'", PDO::FETCH_ASSOC)->fetch();

      $servidor = new Cota();
      $servidor->modulo = $json_post_encoded["dados"]["modulo"];
      $servidor->ambiente = $json_post_encoded["dados"]["ambiente"];
      $servidor->id_limites_cotas = $reg["id_limites_cotas"];
      $servidor->memoria = $json_post_encoded["dados"]["memoria"];
      $servidor->cpu = $json_post_encoded["dados"]["cpu"];
      $servidor->data_inclusao = $json_post_encoded["dados"]["data_inclusao"];
      $servidor->instancia = $json_post_encoded["dados"]["instancia"];
      $servidor->plataforma = $json_post_encoded["dados"]["plataforma"];
      $servidor->status = "ativado";
      $servidor->store();

      $json_post_encoded["retorno"]["status"] = "sucesso";
      $json_post_encoded["retorno"]["mensagem"] = "cadastro realizado com sucesso!";
      http_response_code(201);
    } else {
      $json_post_encoded["retorno"]["status"] = "erro";
      $json_post_encoded["retorno"]["erros"] = $erros;
    }
  } catch (Exception $e) {
    $json_post_encoded["retorno"]["status"] = "erro";
    $json_post_encoded["retorno"]["mensagem"] = "Erro salvar o item. Descrição: {$e->getMessage()}";
  } finally {
    Transaction::close();
  }

  return ($json_post_encoded);
}

function cadastrarUsuario($json)
{
  $dados = $json;
  $dt = date('Y-m-d H:i:s');
  Transaction::open('database');
  $db = Transaction::get();
  if($dados['status'] == true){
    $u = explode(' ', $dados['nome']);
    $sql = "insert into usuarios (matricula, nome, sobrenome, data_inclusao, id_perfil) 
    select '{$dados['matricula']}', '{$u[0]}', '{$u[1]}', '{$dt}', 1
    where not exists (select 1 from usuarios where matricula = '{$dados['matricula']}')";
    $db->exec($sql);
    Transaction::close();
  
  }else{

    Transaction::close();

  }
}

function alterarUsuario($json)
{
  $dados = json_decode($json, true);
  $dt = date('Y-m-d H:i:s');
  Transaction::open('database');
  $db = Transaction::get();
  $sql = "update usuarios set id_perfil = {$dados->tipo} where matricula = '{$dados->id}'";
  $db->exec($sql);
  Transaction::close();
}



function solicitarWOIsilon($json)
{
  try {
    Transaction::open('database');
    $db = Transaction::get();
    $wo = new WO("prd");

    //formatando dados para a WO
    $array_json = json_decode($json, true);
    $array_json["data_solicitacao"] = date('Y-m-d H:i:s');
    $objeto_porta = strtoupper("\"{$array_json["sistema"]}_{$array_json["ambiente"]}\"");
    $objeto_destino = strtoupper("\"{$array_json["sistema"]}_{$array_json["ambiente"]}_backend\"");
    $ip = "";
    $porta = "";
    foreach ($array_json['backends'] as $bck) {
      $ip .= "{$bck['ip']}, ";
      $porta .= "{$bck['porta']}, ";
    }
    $dtE = date("Y-m-d") . "T19:00:00-03:00";
    $dtF = date("Y-m-d", strtotime('+1 day')) . "T19:00:00-03:00";
    $descricaowo = "Para criação de nova área no ISILON: \n
      ******************************* \n 
      Atendimento NFS ESTEIRAS ÁGEIS \n 
      Sistema: XXXXX \n 
      Tamanho: XX GB \n 
      Ambiente: XXX (DES/TQS/HMP/PRD)";

    //GERANDO WO
    //$wo->token = $wo->getToken("USR_CETADPOR1", "CETADPOR1");
    $wo->token = $wo->getToken("USR_CETADAUT2", "CETADAUT2");
    $req = $wo->getREQ();

    $wo->setQuestionario($req, $dtE, $dtF, $descricaowo);
    $wo->processarREQ($req);
    $busca =  $wo->buscarREQ($req);
    sleep(10);

    $numwo = $wo->buscarNumWO($busca->entries[0]->values->GSC_chrNumeroRequisicao);

    //RETORNANDO WO  e salvado no banco de dados
    $retorno = [
      "requisicao" => $busca->entries[0]->values->GSC_chrNumeroRequisicao,
      "wo" => $numwo->entries[0]->values->{'Work Order ID'}
    ];

    //inserir as ids de WO e REQUISIÇÃO no banco de dados
    $statement = $db->prepare("INSERT INTO solicitacoes_id (id_mudanca, id_req, data_inclusao) values (:id_mudanca, :id_req, :inclusao)");
    $statement->bindValue(":id_mudanca", $retorno['wo']);
    $statement->bindValue(":id_req", $retorno['requisicao']);
    $statement->bindValue(":inclusao", $array_json["data_solicitacao"]);
    $statement->execute();
    $res = $db->query("select max(id) as id from solicitacoes_id", PDO::FETCH_ASSOC)->fetch();

    //atualizar backends 
    $statement = $db->prepare("update solicitacoes_backends  SET solicitacoes_id = :sol_id FROM solicitacoes_tipo_backends stb
      where stb.id = solicitacoes_backends.id_solicitacoes_tipo_backends and stb.id_solicitacao =:id and stb.tipo='adicional' and stb.status='relacionado' ");
    $statement->bindValue(":sol_id", $res['id']);
    $statement->bindValue(":id",  $array_json['id']);
    $statement->execute();

    //atualiza o tipo de backends da solicitação
    $statement = $db->prepare("UPDATE solicitacoes_tipo_backends SET solicitacoes_id=:sol_id WHERE id_solicitacao=:id and tipo='adicional' and status='relacionado' and solicitacoes_id is null");
    $statement->bindValue(":id", $array_json['id']);
    $statement->bindValue(":sol_id", $res['id']);
    $statement->execute();

    return "enviado com sucesso";
  } catch (Exception $e) {
    $array = [];
    $array['erro'] = "erro execucao da query";
    Transaction::close();
    return $array;
  } finally {
    Transaction::close();
  }
}




function testarRegra($json)
{
  try {
    Transaction::open('database');
    $db     = Transaction::get();
    $dados  = json_decode($json);
    $api    = "http://awx-infrasimples.produtos.caixa";
    $curl   = curl_init();

    $sql = "select id, id_regras from solicitacoes_id where id_regras not in (select solicitacao_id from teste_regra)";
    $regras = $db->query($sql, PDO::FETCH_ASSOC)->fetchall();

    foreach ($regras as $r) {
      $reg = infoRegra(array('id_regra' => $r['id_regras'], 'plataforma' => 'vm'));
      if (isset($reg['servidores']))
        foreach ($reg['servidores'] as $servidor) {
          $servidor = json_decode($servidor['servidores_json']);
          foreach ($reg['backends'] as $backend) {

            $regra = array('extra_vars' => array(
              'origem' => array($servidor[0]->ip),
              'dest' => $backend['ip'],
              'ports' => array((int)$backend['porta'])
            ));
            $regra_json = json_encode($regra);

            curl_setopt_array($curl, array(
              CURLOPT_URL => "{$api}/api/v2/job_templates/56/launch/",
              CURLOPT_RETURNTRANSFER => true,
              CURLOPT_ENCODING => "",
              CURLOPT_MAXREDIRS => 10,
              CURLOPT_TIMEOUT => 30,
              CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
              CURLOPT_CUSTOMREQUEST => "POST",
              CURLOPT_POSTFIELDS => $regra_json,
              CURLOPT_HTTPHEADER => array(
                "Authorization: Basic YWRtaW46YWRtaW4=",
                "Content-Type: application/json",
                "cache-control: no-cache"
              ),
            ));

            $response = curl_exec($curl);
            $obj = json_decode($response);
            $dt_teste = date('Y-m-d H:i:s');
            $sql = "INSERT INTO teste_regra (origem, destino, porta, data_teste, solicitacao_id, job) values ('{$servidor[0]->ip}','{$backend['ip']}', '{$backend['porta']}', '{$dt_teste}', {$r['id_regras']}, {$obj->job})";
            $db->exec($sql);
          }
        }
    }
  } catch (Exception $e) {
    $array = [];
    $array['erro'] = "erro execucao da query";
    Transaction::close();
    return $array;
  } finally {
    Transaction::close();
  }
}

function verificarStatusTesteRegra($json)
{
  try {
    Transaction::open('database');
    $db     = Transaction::get();
    $api    = "http://awx-infrasimples.produtos.caixa";
    $curl   = curl_init();
    $res = $db->query("select tr.*, sid.id_mudanca from teste_regra tr 
      inner join solicitacoes_id as sid on tr.solicitacao_id = sid.id_regras where tr.status is null", PDO::FETCH_ASSOC)->fetchall();
    $task = new Task("prd");
    $task->token = $task->getToken("USR_CETADPOR1", "CETADPOR1");

    foreach ($res as $r) {
      curl_setopt_array($curl, array(
        CURLOPT_URL => "{$api}/api/v2/jobs/{$r['job']}/",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "GET",
        CURLOPT_HTTPHEADER => array(
          "Authorization: Basic YWRtaW46YWRtaW4=",
          "Content-Type: application/json"
        ),
      ));

      $response2 = curl_exec($curl);
      $obj2 = json_decode($response2);

      $sql = "UPDATE teste_regra SET status = '{$obj2->status}' where job = {$r['job']}";
      $db->exec($sql);

      //edição da tarefa para gravar os dados do teste de regra no GSC
      $datateste = date("d/m/Y H:i:s", strtotime($r['data_teste']));
      $nota = "Teste de regra realizado as {$datateste} origem: {$r['origem']} destino: {$r['destino']} porta:  {$r['porta']} retornando o status de {$obj2->status}";
      $tarefa = $task->buscarTask($r['id_mudanca']);
      if (isset($tarefa->entries[0]->values->{'Task ID'})) {
        $idtask = $tarefa->entries[0]->values->{'Task ID'};
        $task->criarLogTask($idtask, $nota);
        $task->andamentoTask($idtask);
        $task->fecharTask($idtask);
      }
    }
  } catch (Exception $e) {
    $array = [];
    $array['erro'] = "erro execucao da query";
    Transaction::close();
    return $array;
  } finally {
    Transaction::close();
  }
}

function solicitarFQDN($json_post)
{
  $json_post_encoded["dados"] = json_decode($json_post, true);
  $json_post_encoded["dados"]["data_cadastro"] = date('Y-m-d H:i:s');

  try {
    Transaction::open('database');
    $db     = Transaction::get();
    $statement = $db->prepare("INSERT INTO solicitacao_fqdn (sistema, fqdn, status, data_cadastro, ip_real) 
      values (:sistema, :fqdn, :status, :dtcadastro, :ipreal)");

    $statement->bindValue(":sistema", $json_post_encoded["dados"]['sistema']);
    $statement->bindValue(":fqdn", $json_post_encoded["dados"]['fqdn']);
    $statement->bindValue(":status", 'requisitado');
    $statement->bindValue(":dtcadastro", $json_post_encoded["dados"]['data_cadastro']);
    $statement->bindValue(":ipreal", $json_post_encoded["dados"]['ipreal']);
    $statement->execute();
    $json_post_encoded["retorno"]["status"] = "sucesso";
    $json_post_encoded["retorno"]["mensagem"] = "FQDN Solicitado com sucesso";
  } catch (Exception $e) {
    $json_post_encoded["retorno"]["status"] = "erro";
    $json_post_encoded["retorno"]["mensagem"] = "Erro salvar o item. Descrição: {$e->getMessage()}";
  } finally {
    Transaction::close();
  }

  return ($json_post_encoded);
}

function alterarCotas($json)
{
  Transaction::open('database');
  $db     = Transaction::get();
  $json_post_encoded["dados"] = json_decode($json, true);
  $sql = "UPDATE solicitacoes_infra SET id_limites_cotas = {$json_post_encoded['dados']['id_limites_cotas']} id = {$json_post_encoded['dados']['id']}";
  $db->exec($sql);
}

function migracaoInfra()
{
  try {
    Transaction::open('database');
    $db     = Transaction::get();

    $resServ = $db->query("select sistema from servidores", PDO::FETCH_ASSOC)->fetchall();
    $dt = date('Y-m-d H:i:s');
    $sistema = array();

    foreach ($resServ as $r) {
      $s = explode('-', $r['sistema']);
      if (!in_array($s[0], $sistema))
        array_push($sistema, $s[0]);
    }

    foreach ($sistema as $s) {
      $sql = "insert into sistemas (sigla, data_inclusao, status) values ('{$s}', '{$dt}', 'ativado')";
      $db->exec($sql);
    }

    $resSist = $db->query("select id, sigla from sistemas", PDO::FETCH_ASSOC)->fetchall();

    foreach ($resSist as $r) {
      $sql = "UPDATE solicitacoes_infra SET id_sistema = {$r['id']} where modulo ilike '%{$r['sigla']}%'";
      $db->exec($sql);
    }
  } catch (Exception $e) {
    var_dump($e->getMessage());
  } finally {
    Transaction::close();
  }
}

function migracaoCotas()
{
  try {
    Transaction::open('database');
    $db     = Transaction::get();

    $resSol = $db->query("select id, modulo, ambiente, 
      (select plataforma from servidores where trim(lower(si.modulo)) = trim(lower(sistema)) and si.ambiente = ambiente and si.status = 'ativado' limit 1) plataforma 
      from solicitacoes_infra si where status = 'ativado'", PDO::FETCH_ASSOC)->fetchall();
    $dt = date('Y-m-d H:i:s');
    $sistema = array();

    foreach ($resSol as $r) {
      $resCota = $db->query("select id_limites_cotas from limites_cotas where ambiente = '{$r['ambiente']}' and tipo = '{$r['plataforma']}'", PDO::FETCH_ASSOC)->fetch();

      if (isset($resCota['id_limites_cotas'])) {
        $sql = "UPDATE solicitacoes_infra SET id_limites_cotas = {$resCota['id_limites_cotas']} where id = {$r['id']}";
        $db->exec($sql);
      }
    }
  } catch (Exception $e) {
    var_dump($e->getMessage());
  } finally {
    Transaction::close();
  }
}

function teste()
{
  try {
    Transaction::open('database');
    $db     = Transaction::get();

    $resSist = $db->query("select s.solicitacoes_id, sid.id_mudanca, sid.id_req from servidores s
      inner join solicitacoes_id sid on sid.id = s.solicitacoes_id", PDO::FETCH_ASSOC)->fetchall();

    foreach ($resSist as $r) {
      if (isset($r['id_req']))
        $tipo = 'adicional';
      else
        $tipo = 'novo';

      $sql = "UPDATE servidores SET tipo = '{$tipo}' where solicitacoes_id = {$r['solicitacoes_id']}";
      $db->exec($sql);
    }

    $resServ = $db->query("select id, sistema, ambiente from servidores where tipo is null and status = 'ativado'", PDO::FETCH_ASSOC)->fetchall();

    foreach ($resServ as $s) {
      $serv = $db->query("select count(solicitacoes_id) as qtd from servidores where sistema = '{$s['sistema']}' and ambiente = '{$s['ambiente']}' and solicitacoes_id is not null and status = 'ativado' and tipo = 'novo'", PDO::FETCH_ASSOC)->fetch();
      $tipo = '';
      if ($serv['qtd'] > 0)
        $tipo = 'adicional';
      else
        $tipo = 'novo';

      $db->exec("UPDATE servidores SET tipo = '{$tipo}' where id = {$s['id']}");
    }
  } catch (Exception $e) {
    var_dump($e->getMessage());
  } finally {
    Transaction::close();
  }
}

function migracaoSolicitacao()
{
  try {
    Transaction::open('database');
    $db     = Transaction::get();

    $resServ = $db->query(
      "select distinct id, modulo, ambiente from solicitacoes_infra where status = 'ativado' and id >= 644 ",
      PDO::FETCH_ASSOC
    )->fetchall();

    $dt = date('Y-m-d H:i:s');

    foreach ($resServ as $r) {
      $resBck = $db->query("select stb.id_tipo_backend, stb.tipo from solicitacoes_infra si 
          inner join solicitacoes_tipo_backends stb on si.id  = stb.id_solicitacao
          where si.status = 'ativado' and si.modulo = '{$r['modulo']}' and si.ambiente = 'des'", PDO::FETCH_ASSOC)->fetchall();
      if (count($resBck) > 0) {
        echo $r['modulo'];
        foreach ($resBck as $b) {
          relacionarSolicitacaoTipoBackend($r['id'], $b['id_tipo_backend'], $dt, $r['ambiente'], $b['tipo']);
        }
      }
    }
  } catch (Exception $e) {
    var_dump($e->getMessage());
  } finally {
    Transaction::close();
  }
}

function alterarClasse($json)
{
  try {
    Transaction::open('database');
    $db     = Transaction::get();
    $json_post_encoded = json_decode($json, true);
    if ($json_post_encoded['personalizado'])
      $campo = "id_limites_cotas_personalizado = {$json_post_encoded['id_cotas']}, id_limites_cotas = null";
    else
      $campo = "id_limites_cotas = {$json_post_encoded['id_cotas']}, id_limites_cotas_personalizado = null";

    if (isset($json_post_encoded['sistema']))
      $sql = "UPDATE sistemas SET {$campo} where id = {$json_post_encoded['id']}";
    else
      $sql = "UPDATE solicitacoes_infra SET {$campo} where id = {$json_post_encoded['id']}";
    $db->exec($sql);
  } catch (Exception $e) {
    var_dump($e->getMessage());
  } finally {
    Transaction::close();
  }
}

function removerCota($json)
{
  $arrayJson = json_decode($json, true);

  $id = $arrayJson['id'];

  try {
    Transaction::open('database');
    $db = Transaction::get();
    $db->exec("delete from solicitacao_limites_cotas where id_solicitacao_limites_cotas = {$id}");
    $mensagem = "cota excluida com sucesso";
  } catch (Exception $e) {
    $mensagem = "Ao excluir a cota: Descricao: {$e->getMessage()}";
  } finally {
    Transaction::close();
  }

  return ($mensagem);
}

//pesquisar sistema 

function pesquisarSistema($json)
{
  $json_post = json_decode($json, true);



  $sistema = $json_post['input'];

  Transaction::open('database');
  $db = Transaction::get();

  $sql = "select * from sistemas where sigla = '{$sistema}'";
  $res = $db->query($sql, PDO::FETCH_ASSOC)->fetch();
  try {
    if (isset($res['sigla'])) {
      $result = "ERROR";
      Transaction::close();
      return  $result;
    } else if (!isset($res['sigla'])) {
      $result = "OK";
      Transaction::close();
      return  $result;
    }
  } finally {
    Transaction::close();
  }
}

// listar comunidades pelo banco 

function ListaComunidades()
{

  Transaction::open('database');
  $db = Transaction::get();

  $sql = "select * from tb_comunidades";
  return $db->query($sql, PDO::FETCH_ASSOC)->fetchAll();
}



//cadastrar formulario pergunta 1 /2/ 3

function cadastrarFormulario($json)
{


  $json_post = json_decode($json, true);


  if (isset($json_post['inputNovoSistema'])) {
    $sistema = strtolower($json_post['inputNovoSistema']);
    $tipoquestion = 'NOVO CRIADO SISTEMA';
  } elseif (isset($json_post['inputMigrar'])) {
    $sistema = strtolower($json_post['inputMigrar']);
    $tipoquestion = 'SISTEMA JÁ EXISTENTE';
  } elseif (isset($json_post['inputLegado'])) {
    $sistema = strtolower($json_post['inputLegado']);
    $tipoquestion = 'SISTEMA MIGRADO';
  }

  $matricula = $json_post['matricula'];
  $dt = date('Y-m-d H:i:s');

  Transaction::open('database');
  $db = Transaction::get();

  $usuario = "select * from usuarios where matricula = '{$matricula}'";
  $res = $db->query($usuario, PDO::FETCH_ASSOC)->fetch();


  $sql2 = "select * from sistemas where sigla = '{$sistema}'";
  $consultaSigla = $db->query($sql2, PDO::FETCH_ASSOC)->fetch();

  if ($consultaSigla == false) {
    try {
      $result = $db->exec("INSERT INTO sistemas (data_inclusao, sigla, status) VALUES
        ('{$dt}',
         '{$sistema}',
          'ativado')");
    } finally {
      Transaction::close();
    }
  }


  $sql2 = "select * from sistemas where sigla = '{$sistema}'";
  $sigla = $db->query($sql2, PDO::FETCH_ASSOC)->fetch();



  $modulosEspecificos = ''; // Inicialize a variável vazia
  $moduloIndex = 0; // Inicialize o índice do módulo

  foreach ($json_post as $key => $value) {
    if ($key === "regras") {
      // Tratando o array "regras" que é aninhado
      foreach ($value as $index => $rule) {
        // Verificar o valor de autenticadorModulo
        $autenticadorModulo = $rule['autenticadorModulo'];

        // Incrementar o índice do módulo
        $moduloIndex++;

        // Exibir o título do módulo
        $modulosEspecificos .= "Módulo: " . $moduloIndex  . PHP_EOL;

        // Continuar exibindo as informações de modulo, ambiente e nomeSistema
        $modulosEspecificos .= "NOME DO MÓDULO : " . $rule["modulo"] . PHP_EOL;
        $modulosEspecificos .= "TIPO : " . $rule["ambiente"] . PHP_EOL;
        $modulosEspecificos .= "TECNOLOGIA : " . $rule["sistema"] . PHP_EOL;
        $modulosEspecificos .= "NOME DA TECNOLOGIA: " . $rule["nomeSistema"] . PHP_EOL;

        // Verificar se autenticadorModulo é 'LDAP'
        if ($autenticadorModulo === 'LDAP') {
          // Verificar se autenticadorModulo é 'JAAS_SIM' ou 'JAAS_NAO'
          if ($rule['autenticadorJass'] === 'JAAS_SIM') {
            $autenticadoresJass = "Autenticador : " . $autenticadorModulo . " / COM autenticador JAAS Cadastrado pelo usuário / IP: " . $rule["ip"] . "/ Porta : " . $rule["porta"];
            $modulosEspecificos .= $autenticadoresJass . PHP_EOL;
          } elseif ($rule['autenticadorJass'] === 'JAAS_NAO') {
            $autenticadoresNoJass = "Autenticador : " . $autenticadorModulo . " / SEM autenticador JAAS Cadastrado pelo usuário / Ip: " . $rule["ip"] . "/ Porta : " . $rule["porta"];
            $modulosEspecificos .= $autenticadoresNoJass . PHP_EOL;
          }
        }

        // Verificar a existência do banco de dados
        $bancoDados = isset($rule['bancoDados']) ? $rule['bancoDados'] : null;
        if ($bancoDados !== null && $bancoDados !== 'DB_NAO' && $bancoDados !== '') {
          // Tratar as configurações do banco de dados se existirem
          if (isset($rule['configuracaoBD']) && is_array($rule['configuracaoBD'])) {
            $modulosEspecificos .= "**Configurações do Banco de Dados:" . PHP_EOL;
            foreach ($rule['configuracaoBD'] as $dbKey => $dbValue) {
              // Verificar se $dbValue é um array e, se for, convertê-lo em uma string
              if (is_array($dbValue)) {
                $dbValue = implode(", ", $dbValue);
              }
              if ($dbValue !== null) {
                $modulosEspecificos .= $dbKey . ": " . $dbValue . PHP_EOL;
              } else {
                $modulosEspecificos .= $dbKey . ": Não informado " . PHP_EOL;
              }
            }
          }
        } else {
          $modulosEspecificos .= "Banco de Dados: Não cadastrado ou não se aplica a este Módulo " . PHP_EOL;
        }

        // Tratar as configurações de SSO apenas se autenticadorModulo for igual a 'SSO'
        if ($autenticadorModulo === 'SSO') {
          // Tratar as configurações de SSO se existirem
          if (isset($rule['configuracaoSSO']) && is_array($rule['configuracaoSSO'])) {
            $modulosEspecificos .= "**Configurações SSO: " . PHP_EOL;
            foreach ($rule['configuracaoSSO'] as $ssoKey => $ssoValue) {
              // Verificar se $ssoValue é um array e, se for, convertê-lo em uma string
              if (is_array($ssoValue)) {
                $ssoValue = implode(", ", $ssoValue);
              }
              if ($ssoValue !== null) {
                $modulosEspecificos .= $ssoKey . ": " . $ssoValue . PHP_EOL;
              } else {
                $modulosEspecificos .= $ssoKey . ": Não informado" . PHP_EOL;
              }
            }
          }
        }

        $modulosEspecificos .= "*******************************************************************************************************" . PHP_EOL;
      }
    }
  }


  $taskDescription = "prd";

  if ($taskDescription == "prd") {

    $descricaoQuestions = "
      Criação de Ambientes para os Sistemas Centralizados: \n
MATRÍCULA DO SOLICITANTE : " . $json_post['matricula'] . " \n
Se foi feito upload o(s) arquivo(s) encontra(m)-se no endereço de Rede \\prdsmbctc.ctc.caixa\INFRADEVOPS
Para encontrar o arquivo, Procure a Pasta com nome do SISTEMA CRIADO/SUA MATRICULA CAIXA/ARQUIVO(s) SALVO(s)\n 
Exemplo: \INFRADEVOPS\silce\p67899\NOME_DO_SEU_ARQUIVO.pdf\n 
*******************************************************************************************************
TIPO DE QUESTÃO  : " . $tipoquestion . " 
NOME DO SISTEMA  : $sistema
*******************************************************************************************************
LISTA DE MÓDULOS :
$modulosEspecificos\n";
  }



  if ($taskDescription == "hmp") {



    $descricaoQuestions = "
      Criação de Ambientes para os Sistemas Centralizados: \n      
MATRÍCULA DO SOLICITANTE : " . $json_post['matricula'] . " \n
Se foi feito upload o(s) arquivo(s) encontra(m)-se no endereço de Rede \\prdsmbctc.ctc.caixa\INFRADEVOPS
Para encontrar o arquivo, Procure a Pasta com nome do SISTEMA CRIADO/SUA MATRICULA CAIXA/ARQUIVO(s) SALVO(s)\n 
Exemplo: \INFRADEVOPS\silce\p67899\NOME_DO_SEU_ARQUIVO.pdf\n 
*******************************************************************************************************
TIPO DE QUESTÃO  : " . $tipoquestion . " 
NOME DO SISTEMA  : $sistema
*******************************************************************************************************
LISTA DE MÓDULOS :
$modulosEspecificos\n";
  }


  // $task = new Questions("prd"); produção
  $task = new Questions("prd");
  $task->token = $task->getToken("USR_CETADAUT2", "CETADAUT2");

  if ($task->token == false) {
    $retorno = [
      "title" => 'ERRO_API',
      "mensagem" => 'Erro na comunicação com a API do GSC'
    ];
    $result = $retorno;
    return  $result;
  }

  $task->req = $task->criarCapaREQ();

  if (isset($task->req['0']->messageType) == 'ERROR') {
    $retorno = [
      "title" => 'ERRO_API',
      "mensagem" => $task->req['0']->messageText
    ];
    return  $retorno;
  }

  $criarQuest = $task->criarQuestionario1($json_post, $task->req, $descricaoQuestions);

  if (isset($criarQuest['0']->messageType) == 'ERROR') {
    $retorno = [
      "title" => 'ERRO_API',
      "mensagem" => $task->req['0']->messageText
    ];
    return  $retorno;
  }
  $task->AtualizandoReq($task->req);
  $busca =  $task->buscarREQ($task->req);

  // print_r($busca->entries[0]->values->GSC_chrNumeroRequisicao);
  // $numwo = $task->buscarREQ(json_decode($busca->entries[0]->values->GSC_chrNumeroRequisicao));

  //RETORNANDO REQ  
  $retorno = [
    "title" => 'OK',
    "requisicao" => $busca->entries[0]->values->GSC_chrNumeroRequisicao,
    "mensagem" => $busca->entries[0]->values->GSC_chrMensagem,
    "registroPai" => $busca->entries[0]->values->GSC_chrIDRegistro
  ];


  try {

    foreach ($json_post['regras'] as $rule) {
      // Insira informações gerais dos módulos na tabela_modulos
      $result = $db->exec("INSERT INTO tb_modulos(nome_modulo, type_question, sistema_id , matricula_solicitante ,tipo_modulo,tecnologia ,nome_tecnologia, comunidade,fws,data_criacao, status)
        VALUES
   ('{$rule['modulo']}',
    '{$tipoquestion}',
    '{$sigla['id']}',
    '{$json_post['matricula']}',
    '{$rule['ambiente']}',
    '{$rule['sistema']}',
    '{$rule['nomeSistema']}',
    '{$json_post['api']}',
    '{$json_post['plataformaVM']}',
    '{$dt}',
      'ativado')");

      // Recupere o ID do módulo inserido
      $moduloId = $db->lastInsertId();

      // Verifique o tipo de autenticador (JAAS, não JAAS ou SSO)
      if ($rule['autenticadorModulo'] === 'LDAP') {
        if ($rule['autenticadorJass'] === 'JAAS_SIM') {
          $tipoIdJaasSim = obterTipoId('JAAS_SIM'); // Obtém o tipo_id correspondente a 'JAAS_SIM' do banco de dados
          // Insira informações de autenticadores JAAS na tabela_autenticadores
          $stmt = $db->prepare("INSERT INTO tb_tabela_autenticadores (modulo_id, tipo_id, ip, porta) VALUES (:modulo_id, :tipo_id, :ip, :porta)");
          $stmt->bindParam(':modulo_id', $moduloId);
          $stmt->bindParam(':tipo_id', $tipoIdJaasSim);
          $stmt->bindParam(':ip', $rule['ip']);
          $stmt->bindParam(':porta', $rule['porta']);
          $stmt->execute();
        } elseif ($rule['autenticadorJass'] === 'JAAS_NAO') {
          $tipoIdJaasNao = obterTipoId('JAAS_NAO'); // Obtém o tipo_id correspondente a 'JAAS_NAO' do banco de dados
          // Insira informações de autenticadores não JAAS na tabela_autenticadores
          $stmt = $db->prepare("INSERT INTO tb_tabela_autenticadores (modulo_id, tipo_id, ip, porta) VALUES (:modulo_id, :tipo_id, :ip, :porta)");
          $stmt->bindParam(':modulo_id', $moduloId);
          $stmt->bindParam(':tipo_id', $tipoIdJaasNao);
          $stmt->bindParam(':ip', $rule['ip']);
          $stmt->bindParam(':porta', $rule['porta']);
          $stmt->execute();
        }
      } elseif ($rule['autenticadorModulo'] === 'SSO') {
        $tipoIdSSO = obterTipoId('SSO'); // Obtém o tipo_id correspondente a 'SSO' do banco de dados
        // Insira informações de autenticadores SSO na tabela_autenticadores
        $stmt = $db->prepare("INSERT INTO tb_tabela_autenticadores (modulo_id, tipo_id, ip, porta, informacoes_sso) VALUES (:modulo_id, :tipo_id, :ip, :porta, :informacoes_sso)");
        $stmt->bindParam(':modulo_id', $moduloId);
        $stmt->bindParam(':tipo_id', $tipoIdSSO);
        $stmt->bindParam(':ip', $rule['ip']);
        $stmt->bindParam(':porta', $rule['porta']);

        // Defina as informações específicas do SSO como um JSON
        $ssoInfo = json_encode([
          'ipSSO' => $rule['configuracaoSSO']['ipSSO'],
          'portaSSO' => $rule['configuracaoSSO']['portaSSO'],
          'secureDeployment' => $rule['configuracaoSSO']['secureDeployment'],
          'realm' => $rule['configuracaoSSO']['realm'],
          'resource' => $rule['configuracaoSSO']['resource'],
          'sslRequired' => $rule['configuracaoSSO']['sslRequired'],
          'bearerOnly' => $rule['configuracaoSSO']['bearerOnly'],
          'credential' => $rule['configuracaoSSO']['credential'],
        ]);
        $stmt->bindParam(':informacoes_sso', $ssoInfo, PDO::PARAM_STR);
        $stmt->execute();
      }

      // Verifique a existência de configurações de banco de dados
      $bancoDados = isset($rule['bancoDados']) ? $rule['bancoDados'] : null;
      if ($bancoDados !== null && $bancoDados !== 'DB_NAO') {
        // Insira informações de bancos de dados na tabela_bancos_de_dados
        $stmt = $db->prepare("INSERT INTO tb_tabela_banco_de_dados (modulo_id, banco_dados, usuario, porta, host, instancia, StringDB) VALUES (:modulo_id,:banco_dados, :usuario, :porta, :host, :instancia, :StringDB)");
        $stmt->bindParam(':modulo_id', $moduloId);
        $stmt->bindParam(':banco_dados', $rule['configuracaoBD']['BancoDados']);
        $stmt->bindParam(':usuario', $rule['configuracaoBD']['usuarioDB']);
        $stmt->bindParam(':porta', $rule['configuracaoBD']['PortaDB']);
        $stmt->bindParam(':host', $rule['configuracaoBD']['HostNameDB']);
        $stmt->bindParam(':instancia', $rule['configuracaoBD']['InstanciaDB']);
        $stmt->bindParam(':StringDB', $rule['configuracaoBD']['StringDB']);
        $stmt->execute();
      }
    }

    $tipo = 'QUESTIONARIO';

    $statement = $db->prepare("INSERT INTO tb_requisicao (requisicao, mensagem, sistema_id, registropai, data_criacao, tipo_requisicao) values (:requisicao, :mensagem, :sistema_id, :registropai, :data_criacao, :tipo_requisicao)");
    $statement->bindValue(":requisicao", $retorno['requisicao']);
    $statement->bindValue(":requisicao", $retorno['requisicao']);
    $statement->bindValue(":mensagem", $retorno['mensagem']);
    $statement->bindValue(":sistema_id", $sigla['id']);
    $statement->bindValue(":tipo_requisicao", $tipo);
    $statement->bindValue(":registropai", $retorno['registroPai']);
    $statement->bindValue(":data_criacao", $dt);
    $statement->execute();

    return  $retorno;

  } catch (\Exception $e) {
    var_dump($e->getMessage());
    die();
  } finally {
    Transaction::close();
    return  $retorno;
  }
}

function obterTipoId($tipoNome)
{
  Transaction::open('database');
  $db = Transaction::get();
  $stmt = $db->prepare("SELECT id FROM tb_tipos_autenticadores WHERE nome = :nome");
  $stmt->bindParam(':nome', $tipoNome);
  $stmt->execute();
  return $stmt->fetchColumn();
}


//pesquisar sistema existente cadastrarModulos
//PERGUNTA 3 , VERIFICAR MODULOS EXISTENTES
function pesquisarSistemaExistente($json)
{
  $json_post = json_decode($json, true);
  $sistema = strtolower($json_post['input']);
  Transaction::open('database');
  $db = Transaction::get();

  $sql = "select * from sistemas where sigla = '{$sistema}'";
  $res = $db->query($sql, PDO::FETCH_ASSOC)->fetch();


  try {
    if (isset($res['sigla'])) {

      $sqlMod = "select * from tb_modulos tbm
       join sistemas s on s.id = tbm.sistema_id
      where s.sigla = '{$res['sigla']}'";
      $res1 = $db->query($sqlMod, PDO::FETCH_ASSOC)->fetchAll();

      if (isset($res1)) {
        $response = [$res1, $resposta = 'OK'];
        Transaction::close();
        return  $response;
      } else {
        $response = [$res1, $resposta = 'ERROR_MODULOS'];
        Transaction::close();
        return  $response;
      }
    } else if (!isset($res['sigla'])) {
      $result = "ERRO";
      Transaction::close();
      return  $result;
    }
  } finally {
    Transaction::close();
  }
}


function listarModulosQuestion($json)
{


  $json_post = json_decode($json, true);


  $sistema = strtolower($json_post["nome_sistema"]);
  Transaction::open('database');
  $db = Transaction::get();

  $sql = "select * from sistemas where sigla = '{$sistema}'";
  $res = $db->query($sql, PDO::FETCH_ASSOC)->fetch();


  try {
    if (isset($res['sigla'])) {

      $sqlMod = "select * from tb_modulos tbm
       join sistemas s on s.id = tbm.sistema_id
      where s.sigla = '{$res['sigla']}'";
      $res1 = $db->query($sqlMod, PDO::FETCH_ASSOC)->fetchAll();

      if (isset($res1)) {
        $response = [$res1, $resposta = 'OK'];
        Transaction::close();
        return  $response;
      } else {
        $response = [$res1, $resposta = 'ERROR_MODULOS'];
        Transaction::close();
        return  $response;
      }
    } else if (!isset($res['sigla'])) {
      $result = "ERRO";
      Transaction::close();
      return  $result;
    }
  } finally {
    Transaction::close();
  }
}

function uploadFileToReq($file)
{


  $matricula = $_POST['matricula'];
  $sistema = $_POST['sistema'];
  $fileCount = count($_FILES['arquivos']['name']);

  for ($i = 0; $i < $fileCount; $i++) {

    $fileNametemp =  $_FILES['arquivos']['tmp_name'][$i];
    $move = $_FILES['arquivos']['name'][$i];


    $upload_dir = dirname(__DIR__) . '/';

    $new_folden = 'arquivos';

    $novo_arquivo_path = $upload_dir . $new_folden;

    $fileName = $novo_arquivo_path . '/' . $sistema .  '/' . $matricula;

    if (!file_exists($fileName)) {

      mkdir($fileName, 0777, true);
    }


    try {
      if (is_writable($fileName) && move_uploaded_file($fileNametemp, $fileName . '/' . $move)) {

        $retorno = [
          "retorno" => 'OK',
          "mensagem" => 'Arquivo salvo e enviado com sucesso'
        ];
      } else {
        $retorno = [
          "retorno" => 'ERROR',
          "mensagem" => 'Ocorreu um erro ao enviar o Arquivo'
        ];
      }
    } finally {
      Transaction::close();
    }
  }

  return  $retorno;
}
function statusServidores($json_post)
{

  $json_post_encoded = json_decode($json_post, true);
  $json_post_encoded["dados"]["data_atualizacao"] = date('Y-m-d H:i:s');


  try {
    Transaction::open('database');
    $db = Transaction::get();

    $campos = [];

    if (isset($json_post_encoded['dados']['status']))
      array_push($campos, "status = '{$json_post_encoded['dados']['status']}'");
    if (isset($json_post_encoded['consulta']['sistema']))
      array_push($campos, "sistema = '{$json_post_encoded['consulta']['sistema']}'");
    if (isset($json_post_encoded['consulta']['ambiente']))
      array_push($campos, "ambiente = '{$json_post_encoded['consulta']['ambiente']}'");

    $dados = implode(",", $campos) . ", data_atualizacao = '{$json_post_encoded["dados"]["data_atualizacao"]}'";

    $consulta = "sistema = '{$json_post_encoded['consulta']['sistema']}' and 
      ambiente = '{$json_post_encoded['consulta']['ambiente']}'";

    $sql = "UPDATE servidores SET $dados WHERE $consulta";

    $db->exec($sql);

    $json_post_encoded["retorno"]["status"] = "sucesso";
    $json_post_encoded["retorno"]["mensagem"] = "cadastro realizado com sucesso!";
    http_response_code(201);
  } catch (Exception $e) {
    $json_post_encoded["retorno"]["status"] = "erro";
    $json_post_encoded["retorno"]["mensagem"] = "Erro ao salvar o item. Descrição: {$e->getMessage()}";
  } finally {
    Transaction::close();
  }

  return ($json_post_encoded);
}



function cadastrarUrl($json_post)
{
  $json_post_encoded = json_decode($json_post, true);

  try {
    Transaction::open('database');
    $db = Transaction::get();

    if (gettype($json_post_encoded['url_publicada']) == 'array')
      $url_publ = implode(",", $json_post_encoded['url_publicada']);
    else
      $url_publ = $json_post_encoded['url_publicada'];

    $sql = "UPDATE solicitacoes_infra SET url_publicada = '{$url_publ}', url_projeto = '{$json_post_encoded['url_projeto']}' 
    WHERE modulo = '{$json_post_encoded['modulo']}' and  ambiente = '{$json_post_encoded['ambiente']}' and status = 'ativado'";
    echo $sql;
    $db->exec($sql);

    $json_post_encoded["retorno"]["status"] = "sucesso";
    $json_post_encoded["retorno"]["mensagem"] = "cadastro realizado com sucesso!";
    http_response_code(201);
  } catch (Exception $e) {
    $json_post_encoded["retorno"]["status"] = "erro";
    $json_post_encoded["retorno"]["mensagem"] = "Erro ao salvar o item. Descrição: {$e->getMessage()}";
  } finally {
    Transaction::close();
  }

  return ($json_post_encoded);
}

function cadastrarContato($json_post)
{
  $json_post_encoded = json_decode($json_post, true);
  $datahora = date('Y-m-d H:i:s');

  try {
    Transaction::open('database');
    $db = Transaction::get();

    $sql = "INSERT INTO contato (matricula, tipo, texto, data_hora) values ('{$json_post_encoded['matricula']}', '{$json_post_encoded['tipo']}', '{$json_post_encoded['texto']}', '{$datahora}')";

    $db->exec($sql);

    $json_post_encoded["retorno"]["status"] = "sucesso";
    $json_post_encoded["retorno"]["mensagem"] = "cadastro realizado com sucesso!";
    http_response_code(201);
  } catch (Exception $e) {
    $json_post_encoded["retorno"]["status"] = "erro";
    $json_post_encoded["retorno"]["mensagem"] = "Erro ao salvar o item. Descrição: {$e->getMessage()}";
  } finally {
    Transaction::close();
  }

  return ($json_post_encoded);
}

function DadosAutenticadoresQuestions($parametros)
{

  $json_post_encoded = json_decode($parametros, true);

  try {
    Transaction::open('database');
    $db = Transaction::get();

    $sql = "SELECT b.id, tb.id as id_tipo, tb.tipo, b.nome, b.ip, b.porta from backends b
    join tipo_backend tb on b.tipo = tb.id
    where b.status = 'ativado' and tb.tipo ='{$json_post_encoded['Autenticador']}' and b.ambiente = '{$json_post_encoded['AutenticadorAmbiente']}' and ip is not null
    order by b.nome";


    $statement = $db->prepare($sql);
    $statement->execute();
    $registros = $statement->rowCount();
    $arrayRetorno = array();
    $arrayRetorno["registros"] = $registros;

    if ($registros == 0) {
      $array['info'] = "não foram encontrados resultados.";
      return $array;
      die;
    }

    foreach ($statement as $row) {
      $arraySistemas[] = array(
        'id' => $row['id'],
        'id_tipo' => $row['id_tipo'],
        'nome' => $row['nome'],
        'porta' => $row['porta'],
        'ip' => $row['ip'],
        'tipo' => $row['tipo']
      );
    }

    $arrayRetorno["dados"] = $arraySistemas;

    return $arrayRetorno;
  } catch (Exception $e) {
    $array = [];
    $array['erro'] = "erro execucao da query";
    Transaction::close();
    return $array;
  } finally {
    Transaction::close();
  }
}

function DadosRelacionalQuestions($parametros)
{

  $json_post_encoded = json_decode($parametros, true);

  try {
    Transaction::open('database');
    $db = Transaction::get();


    $sql1 = "select id from tipo_backend where status = 'ativado' and caract = 'BANCO' and tipo = '{$json_post_encoded['BancoDadosUsuario']}'";

    $stmt = $db->prepare($sql1);
    $stmt->execute();
    $id = $stmt->fetchColumn();


    $sql = "SELECT b.id, tb.id as id_tipo, tb.tipo, b.nome, b.ip, b.porta from backends b
    join tipo_backend tb on b.tipo = tb.id
    where b.status = 'ativado' and b.tipo in ({$id}) and b.ambiente = '{$json_post_encoded['BancoAmbiente']}' and ip is not null
    order by b.nome";

    $statement = $db->prepare($sql);
    $statement->execute();
    $registros = $statement->rowCount();
    $arrayRetorno = array();
    $arrayRetorno["registros"] = $registros;

    if ($registros == 0) {
      $array['info'] = "não foram encontrados resultados.";
      return $array;
      die();
    }

    foreach ($statement as $row) {
      $arraySistemas[] = array(
        'id' => $row['id'],
        'id_tipo' => $row['id_tipo'],
        'nome' => $row['nome'],
        'porta' => $row['porta'],
        'ip' => $row['ip'],
        'tipo' => $row['tipo']
      );
    }

    $arrayRetorno["dados"] = $arraySistemas;

    return $arrayRetorno;
  } catch (Exception $e) {
    $array = [];
    $array['erro'] = "erro execucao da query";
    Transaction::close();
    return $array;
  } finally {
    Transaction::close();
  }
}

function relacionarBackendAntigo($json) {

  $arrayJson = json_decode($json, true);

  foreach ($arrayJson["backends"] as $backend  ){

    try {
      Transaction::open('database');
      $db = Transaction::get();

      foreach ($backend as $bck) {

        $criteria = new Criteria();
        $criteria->add(new Filter('id', '=',$bck['id_solicitacao_tipo_backend']));
        $solicitacoes_backends_criteria = SolicitacoesTipoBackends::all($criteria);

        $registro = $solicitacoes_backends_criteria[0];
        $registro->status = "relacionado";
        $registro->data_atualizacao = date('Y-m-d H:i:s');
        $registro->store();

        $db->exec("insert into solicitacoes_backends (id_solicitacoes_tipo_backends, id_backend) values ({$bck['id_solicitacao_tipo_backend']},{$bck['id']})");

        if ($bck["tipo"] == 'NFS') {
          $db->exec("insert into point (endpoint, mountpoint, id_backend, id_solicitacao) values ('{$bck['endpoint']}','{$bck['mountpoint']}',{$bck['id']}, {$bck['id_solicitacao_tipo_backend']})");
        }

      }

      $mensagem = "Relacionamento realizado.";
      http_response_code(201);

    } catch (Exception $e) {
      $mensagem = "Ao relacionar backend. Descricao: {$e->getMessage()}";
    } finally {
      Transaction::close();
    }
  }
  return($mensagem);
}

function cadastrarNuvemVM($json){

  $arrayJson = json_decode($json, true);
  $matricula = $arrayJson['matricula'];

  Transaction::open('database');
  $db = Transaction::get();
  $dt = date('Y-m-d H:i:s');

  if($arrayJson['tamanhoExtra'] != null){

    $tamanho = $arrayJson['tamanhoExtra'];
  } else{
    $tamanho = 'Não Necessita de Espaço Adicional';
  }

  if($arrayJson['camada'] == 'APL'){

    $camada = 'APLICAÇÃO';
  } else{
    $camada = 'DADOS';
  }

  if($arrayJson['ambiente'] == 'DE'){
    $ambiente = 'DESENVOLVIMENTO';
    $ambienteAbrv = 'DES';
  } else if ($arrayJson['ambiente'] == 'TQ'){
    $ambiente = 'TESTE';
    $ambienteAbrv = 'TQS';
  }
  else if ($arrayJson['ambiente'] == 'HG'){
    $ambiente = 'HOMOLOGAÇÃO';
    $ambienteAbrv = 'HMG';
  }
  else if ($arrayJson['ambiente'] == 'PR'){
    $ambiente = 'PRODUÇÃO';
    $ambienteAbrv = 'PRD';
  }

  if ($arrayJson['descriptionRede'] == null){
    $descricaoSubnet = 'Não informado';
  }else{
    $descricaoSubnet = $arrayJson['descriptionRede'];
  }

  if($arrayJson['descriptionAdd'] == null){
    $descriptionAdd = 'Não informado';
  }else{
    $descriptionAdd = $arrayJson['descriptionAdd'];
  }



  $descricao = "Solicitação Enviada Via portal Infrafácil Para Criação de VM - Cloud\n
CESTI35 - Suporte a Nuvem Pública
MATRÍCULA DO SOLICITANTE: " . $matricula . " \n
*******************************************************************************************************
Nome(s) VM: " . $arrayJson['nomeVm'] . "
Quantidade(s) VM: " . $arrayJson['quantidade'] . "
Nome do Projeto: " . $arrayJson['nomeProjeto'] . "  
Resource Group: " . $arrayJson['ResourceGroup'] . "
Subscription: " . $arrayJson['Subscription'] . " 
VNET: " . $arrayJson['rede'] . " 
Subnet: " . $descricaoSubnet . "
*******************************************************************************************************
Sistema Operacional : " . $arrayJson['selectOptionSO'] .'-'.$arrayJson['SO'] . '/' .  $arrayJson['servidor'] ." 
Capacidade: " . $arrayJson['capacidade'] . " 
Tipo de Disco: " . $arrayJson['disco'] . "
Tamanho Extra: " . $tamanho . "
Observações Adicionais: " . $descriptionAdd . "
";

  $objNuvem = new nuvempublica();
  $response = $objNuvem->criarRequisicaoNuvem($descricao , $ambienteAbrv);

  if($response['title'] == 'OK'){

    try {
      // Insira informações gerais dos módulos na tabela_modulos
      $db->exec("INSERT INTO tb_nuvem_publica(nome_vm, nome_projeto, camada , ambiente ,resource_Group,subscription ,rede, desc_rede,so,capacidade, disco, tamanho, info_add, data_criacao, status)
      VALUES
 ('{$arrayJson['nomeVm']}',
  '{$arrayJson['nomeProjeto']}',
  '{$camada}',
  '{$ambienteAbrv}',
  '{$arrayJson['ResourceGroup']}',
  '{$arrayJson['Subscription']}',
  '{$arrayJson['rede']}',
  '{$descricaoSubnet}',
  '{" . $arrayJson['selectOptionSO'] .'-'.$arrayJson['SO'] . '/' .  $arrayJson['servidor'] ."}',
  '{$arrayJson['capacidade']}',
  '{$arrayJson['disco']}',
  '{$tamanho}',
  '{$descriptionAdd}',
  '{$dt}',
    'ativado')");

      $tb_nuvem_publica_Id = $db->lastInsertId();
      $tipo = 'NUVEM_PUBLICA';

      $statement = $db->prepare("INSERT INTO tb_requisicao (requisicao, mensagem, sistema_id, registropai, data_criacao, tipo_requisicao) values (:requisicao, :mensagem, :sistema_id, :registropai, :data_criacao, :tipo_requisicao)");
      $statement->bindValue(":requisicao", $response['requisicao']);
      $statement->bindValue(":mensagem", $response['mensagem']);
      $statement->bindValue(":sistema_id", $tb_nuvem_publica_Id);
      $statement->bindValue(":registropai", $response['registroPai']);
      $statement->bindValue(":data_criacao", $dt);
      $statement->bindValue(":tipo_requisicao",$tipo );
      $statement->execute();

      return  $response;

    } catch (\Exception $e) {
      var_dump($e->getMessage());
      die();
    } finally {
      Transaction::close();
      return  $response;
    }

  } else {
    return  $response;
  }


}

function cadastrarBancoDados($json)
{
  $json = json_decode($json);

  // Envia req
  $objDB = new bancodados();
  $response = $objDB->criarReqBancoDados($json);

  if ($response['title'] == "OK") {
    try {
      Transaction::open('database');
      $db = Transaction::get();

      // Início da query para salvar na tabela banco_dados
      $environmentList = [
        'Desenvolvimento (DES)' => 'des',
        'Testes (TQS)' => 'tqs',
        'Homologação (HMP)' => 'hmp',
        'Produção (PRD)' => 'prd',
      ];

      date_default_timezone_set('America/Sao_Paulo');
      $date = date('Y-m-d H:i:s');

      $obs = $json->details
        . ' - Área de sustentação do serviço: ' . $json->areaSust
        . ' - Disponibilidade: ' . $json->availability
        . ($json->obs != null ? ' - ' . $json->obs : '');

      $sql = "INSERT INTO banco_dados values 
              (
                default
                , '{$json->system}'
                , '{$environmentList[$json->environment]}'
                , '{$json->name}'
                , '{$json->unDemandante}'
                , '{$json->areaSust}'
                , '{$json->sgbd}'
                , '{$json->charset}'
                , '{$json->availability}'
                , '{$json->tam}GB'
                , '{$json->txCres}{$json->uni}/{$json->periodCres}'
                , '{$obs}'
                , '{$json->phone}'
                , '{$json->mail}'
                , '{$date}'
              )";

      $db->exec($sql);
      // Fim da query para salvar na tabela banco_dados

      // Início da query para salvar na tabela tb_requisicao
      $idDB = $db->lastInsertId();

      $statement = $db->prepare("INSERT INTO tb_requisicao (requisicao, mensagem, sistema_id, registropai, data_criacao, tipo_requisicao) values (:requisicao, :mensagem, :sistema_id, :registropai, :data_criacao, :tipo_requisicao)");
      $statement->bindValue(":requisicao", $response['requisicao']);
      $statement->bindValue(":mensagem", $response['mensagem']);
      $statement->bindValue(":sistema_id", $idDB);
      $statement->bindValue(":registropai", $response['registroPai']);
      $statement->bindValue(":data_criacao", $date);
      $statement->bindValue(":tipo_requisicao", "BANCO_DADOS");
      $statement->execute();
      // Fim da query para salvar na tabela tb_requisicao

      $response['dbResult'] = true;
    } catch (\Exception $e) {
      $response['dbResult'] = false;
      $response['errorDbResult'] = $e->getMessage();
    } finally {
      Transaction::close();
    }
  }

  return $response;
}




function cadastrarRouter($json_post)
{
  $json_post_encoded = json_decode($json_post, true);

  try {
    Transaction::open('database');
    $db = Transaction::get();

    $cluster = strtolower($json_post_encoded['cluster']);
    $nome = strtolower($json_post_encoded['nome']);
    $tipo = strtolower($json_post_encoded['tipo']);
    $ambiente = strtolower($json_post_encoded['ambiente']);
    $sql = "INSERT INTO routers (nome, cluster, tipo, ambiente, porta) values ('{$nome}', '{$cluster}', '{$tipo}', '{$ambiente}', '{$json_post_encoded['porta']}')";

    $db->exec($sql);
    $id = Transaction::getLastInsertId('routers_id_router_seq');
    foreach ($json_post_encoded['ips'] as $key => $value) {
      $sql = "INSERT INTO router_ips (ip, id_router) values ('{$value}',$id)";
      $db->exec($sql);
    }

    $response["retorno"]["status"] = "sucesso";
    $response["retorno"]["mensagem"] = "cadastro realizado com sucesso!";
    http_response_code(201);
  } catch (Exception $e) {
    $response["retorno"]["status"] = "erro";
    $response["retorno"]["mensagem"] = "Erro ao salvar o item. Descrição: {$e->getMessage()}";
  } finally {
    Transaction::close();
  }

  return ($response);
}

function alterarRouter($json_post)
{
  $json_post_encoded = json_decode($json_post, true);

  try {
    Transaction::open('database');
    $db = Transaction::get();
    $cluster = strtolower($json_post_encoded['cluster']);
    $nome = strtolower($json_post_encoded['nome']);
    $tipo = strtolower($json_post_encoded['tipo']);
    $ambiente = strtolower($json_post_encoded['ambiente']);

    $sql = "UPDATE routers set nome ='{$nome}', 
    cluster ='{$cluster}', 
    tipo = '{$tipo}', 
    ambiente = '{$ambiente}', 
    porta = '{$json_post_encoded['porta']}' where id_router = " . $json_post_encoded['id'];
    $db->exec($sql);

    $sql = "DELETE FROM router_ips where id_router = " . $json_post_encoded['id'];
    $db->exec($sql);
    foreach ($json_post_encoded['ips'] as $key => $value) {
      $sql = "INSERT INTO router_ips (ip, id_router) values ('{$value}',{$json_post_encoded['id']})";
      $db->exec($sql);
    }

    $response["retorno"]["status"] = "sucesso";
    $response["retorno"]["mensagem"] = "cadastro atualizado com sucesso!";
    http_response_code(201);
  } catch (Exception $e) {
    $response["retorno"]["status"] = "erro";
    $response["retorno"]["mensagem"] = "Erro ao salvar o item. Descrição: {$e->getMessage()}";
  } finally {
    Transaction::close();
  }

  return ($response);
}

function removerRouter($json)
{

  $arrayJson = json_decode($json, true);
  try {
    Transaction::open('database');
    $db = Transaction::get();
    $db->exec("delete from routers where id_router = {$arrayJson['id']}");
    $response["retorno"]["status"] = "sucesso";
    $response["retorno"]["mensagem"] = "cadastro excluído com sucesso!";
  } catch (Exception $e) {
    $response["retorno"]["status"] = "erro";
    $response["retorno"]["mensagem"] = "Erro ao salvar o item. Descrição: {$e->getMessage()}";
  } finally {
    Transaction::close();
  }

  return ($response);
}

function vipApiRequisicao($json)
{
  Transaction::open('database');
  $db = Transaction::get();
  $retorno = [];
  try {
    $json_post = json_decode($json, true);

    $sql = "SELECT servidores_json, plataforma,site,terraform
  FROM public.servidores where sistema = '{$json_post['sistema']}' and ambiente = '{$json_post['ambiente']}'";
    $res = $db->query($sql, PDO::FETCH_ASSOC)->fetchAll();

    //testar
    $ips = array();
    $plataforma = "";
    $site = "";
    $portas = "443, 80";
    $terraform = false;
    foreach ($res as $item) {
      $servidor = json_decode($item['servidores_json']);
      $ips[] = $servidor[0]->ip;
      $plataforma = $item['plataforma'];
      $site = $item['site'];
      $terraform = $item['terraform'];
    }
    if ($plataforma == "container" || (!$terraform)) {
      //recupera os ips dos cluster
      $ips = array();
      $sql = "  select ip.ip, r.porta from router_ips ip inner join routers r on r.id_router = ip.id_router 
    where r.cluster = '{$site}' and LOWER(r.ambiente) = '{$json_post['ambiente']}' ";
      $rsips = $db->query($sql, PDO::FETCH_ASSOC)->fetchAll();
      foreach ($rsips as $item) {
        $ips[] = $item["ip"];
        $portas = $item['porta'];
      }
      $iplist = implode("/", $ips);
    } else {
      $iplist = implode("/", $ips);
    }

    $vipIp = $json_post['dados']["Gerar"]['0'];
    $objVip = new Vip();
    $retorno = $objVip->criarRequisicaoVip($iplist, $portas, $json_post);
    
    if ($retorno['title'] != 'OK') {
      Transaction::rollback();
      return;
    }

    //atualisa o vip com os dados da requisição
    $sql = "UPDATE vip SET requisicao = '{$retorno['requisicao']}', 
     mensagem_gsc = '{$retorno['mensagem']}'
      where ip = '{$vipIp}'";

    $db->exec($sql);

//     // criar requisição de dns
    $retornoDNS = $objVip->criarRequisicaoDNS($json_post);
    if ($retornoDNS['title'] != 'OK') {
      //cancelando a requisicao anterior pois deu erro na de dns
      Transaction::rollback();
      $objVip->cancelaRequisicao($retorno['requisicao']);
      $retorno = $retornoDNS;
      return;
    }

    //atualisa o vip com os dados da requisição
    $sql = "UPDATE vip SET requisicao_dns = '{$retornoDNS['requisicao']}', 
mensagem_dns_gsc = '{$retornoDNS['mensagem']}'
 where ip = '{$vipIp}'";

    $db->exec($sql);

    $retorno["requisicaoDNS"] = $retornoDNS['requisicao'];
    $retorno["mensagemDNS"] = $retornoDNS['mensagem'];
    $retorno["registroPaiDNS"] = $retornoDNS['registroPai'];

    //AQUI EVNIAR PARA A ROTA OKD EM CASO DE CONTAINER
    if ($plataforma == 'container') {
      //envia por api do akd aqui. 
      $cli = new DNSClient(dns_endpoint);
      $array = explode("-",$json_post['sistema']);
      $retOKD = $cli->registraRotaOKD($array[0]."-".strtolower($json_post['ambiente']),$json_post['sistema']."-".strtolower($json_post['ambiente']),$json_post["registros"]["fqdn"],$site);
      if(isset($retOKD->error)){
        $retorno["mensagemRotaOKD"] = $retOKD->error;
      }else{
        $retorno["mensagemRotaOKD"] = "Rota OKD Criada com sucesso!";
      }
    }else{
      $retorno["mensagemRotaOKD"] = "";
    }
  } catch (\Exception $e) {
    Transaction::rollback();
    $retorno = [
      "title" => 'ERRO',
      "mensagem" => $e->getMessage()
    ];
  } finally {
    Transaction::close();
    return  $retorno;
  }
}
function consultarSistemaRedeIP($json)
{

  $json_post_encoded = json_decode($json, true);
  $sistema = $json_post_encoded['sistema'];
  $ambiente = $json_post_encoded['ambiente'];
  try {
    Transaction::open('database');
    $db = Transaction::get();

    $vip = "SELECT mensagem_gsc , requisicao
    FROM vip where sistema = '{$sistema}' and tipo = '{$ambiente}'and mensagem_gsc notnull and requisicao notnull";
    $res1 = $db->query($vip, PDO::FETCH_ASSOC)->fetch();


    if ($res1 != false) {
      $retorno = [
        "title" => 'ERRO_VIP',
        "text" => 'Já existe uma Solicitação de  Vip para este sistema , Segue o número da Requisição : ' . $res1["requisicao"]
      ];

      return $retorno;
    }


    $sql = "SELECT servidores_json , ambiente , site, plataforma, terraform
    FROM servidores where sistema = '{$sistema}' and ambiente = '{$ambiente}'";
    $res = $db->query($sql, PDO::FETCH_ASSOC)->fetch();
  } catch (Exception $e) {
    $retorno = [
      "title" => 'ERRO_INTERNO',
      "text" => "Erro ao listar informações. Descrição: {$e->getMessage()}"
    ];
    return $retorno;   
  }

  if ($res == false) {
    $retorno = [
      "title" => 'ERRO_VIP',
      "text" => 'Não foi encontrado sistema ativado com um IP válido para realizar a solicitação de VIP'
    ];

    return $retorno;
  }

  if ($res['plataforma'] == 'vm' && !$res['terraform']) {
    $retorno = [
      "title" => 'ERRO_VM_NOT_TERRAFORM',
      "text" => 'Essa solicitação não pode ser realizada para esse modulo. Para configurar o VIP siga o processo tradicional através do serviços.caixa.'
    ];

    return $retorno;
  }



  $ip = json_decode($res["servidores_json"], true);

  $json = $ip[0]['ip'];

  $post = json_encode(array(
    "ip" => $json

  ));

  $endpoint = endpoint_regrasbr . '/ConsultarRede';
  // $dt_cadastro = date('Y-m-d H:i:s');
  $curl = curl_init($endpoint);

  curl_setopt_array($curl, array(
    CURLOPT_URL => $endpoint,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => '',
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 0,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => 'POST',
    CURLOPT_POSTFIELDS => $post,
    CURLOPT_HTTPHEADER => array('Content-Type: application/json')
  ));

  //Execute the request
  $result = curl_exec($curl);
  $retorno = preg_replace('/[\x00-\x1F\x80-\xFF]/', '', $result);


  $resultado = json_decode($retorno, true);

  // $resultado["data"]["Classificacao"][0]["Vertical"] = NULL;
  // $resultado["data"]["Classificacao"][0]["AmbientePRD"] = NULL;

  if ($resultado["success"] == "false") {
    $retorno = [
      "title" => 'ERRO',
      "text" => $resultado["data"]
    ];
    return $retorno;
  }

  if (
    isset($resultado["success"]) == "true" && $resultado["data"]["Classificacao"][0]["Vertical"] != NULL
    && $resultado["data"]["Classificacao"][0]["AmbientePRD"] != NULL
    && $resultado["data"]["Classificacao"][0]["Camada"] != NULL
    && $resultado["data"]["Classificacao"][0]["Site"] != NULL
    && $resultado["data"]["Classificacao"][0]["Unidade"] != NULL
  ) {
    $retorno = [
      "title" => 'OK',
      "vertical" => $resultado["data"]["Classificacao"][0]["Vertical"],
      "ambiente" => $resultado["data"]["Classificacao"][0]["AmbientePRD"],
      "camada" => $resultado["data"]["Classificacao"][0]["Camada"],
      "site" => $resultado["data"]["Classificacao"][0]["Site"],
      "unidade" => $resultado["data"]["Classificacao"][0]["Unidade"],
      "ip" => $json
    ];
    return $retorno;
  }
  if (isset($resultado["success"]) == "true" && $resultado["data"]["Classificacao"][0]["Vertical"] == NULL) {
    $retorno = [
      "title" => 'ERRO',
      "text" => 'Não é possível Solicitar o VIP, pois a Vertical do IP : ' . $json  . " não existe ou não foi encontrada"
    ];
    return $retorno;
  }
  if (isset($resultado["success"]) == "true" && $resultado["data"]["Classificacao"][0]["AmbientePRD"] == NULL) {
    $retorno = [
      "title" => 'ERRO',
      "text" => 'Não é possível Solicitar o VIP, pois o Ambiente do IP : ' . $json  . " não existe ou não foi encontrado"
    ];
    return $retorno;
  }
}
