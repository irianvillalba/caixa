<?php

class Controla {
    
    public $json;
    
    public function __construct($json) {
        $this->json = $json; 
    }
    
    
    
}


/*
    EXECUCAO DA CLASSE    
 */
    
$array_json = [];
$array_json['sistema'] = 'siabc';

$array_json['vip'] = "10.122.45.67";

$array_json['servidores']["srjdeaprlx001"] = "10.120.16.01";
$array_json['servidores']["srjdeaprlx002"] = "10.120.16.02";


$json = json_encode($array_json, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);

print $json;
print "\n\n";

foreach ( $array_json['servidores'] as $nome => $ip ) {
    print "{$nome} => {$ip}\n";
}




