<?php

function editarServidor($json_post)
{

  $json_post_encoded = json_decode($json_post, true);
  $json_post_encoded["dados"]["data_atualizacao"] = date('Y-m-d H:i:s');
  //$json_post_encoded["dados"]["status"] = "ativado";

  try {
    Transaction::open('database');
    $db = Transaction::get();

    $campos = [];

    if (isset($json_post_encoded['dados']['versao']))
      array_push($campos, "versao = '{$json_post_encoded['dados']['versao']}'");
    if (isset($json_post_encoded['dados']['site']))
      array_push($campos, "site = '{$json_post_encoded['dados']['site']}'");
    if (isset($json_post_encoded['dados']['status']))
      array_push($campos, "status = '{$json_post_encoded['dados']['status']}'");
    if (isset($json_post_encoded['dados']['sistema']))
      array_push($campos, "sistema = '{$json_post_encoded['dados']['sistema']}'");
    if (isset($json_post_encoded['dados']['ambiente']))
      array_push($campos, "ambiente = '{$json_post_encoded['dados']['ambiente']}'");
    if (isset($json_post_encoded['dados']['plataforma']))
      array_push($campos, "plataforma = '{$json_post_encoded['dados']['plataforma']}'");
    if (isset($json_post_encoded['dados']['versao_plataforma']))
      array_push($campos, "versao_plataforma = '{$json_post_encoded['dados']['versao_plataforma']}'");
    if (isset($json_post_encoded['dados']['servidores_json']))
      array_push($campos, "servidores_json = '{$json_post_encoded['dados']['servidores_json']}'");
    if (isset($json_post_encoded['dados']['produto']))
      array_push($campos, "produto = '{$json_post_encoded['dados']['produto']}'");
    if (isset($json_post_encoded['dados']['ipbackup']))
      array_push($campos, "ipbackup = '{$json_post_encoded['dados']['ipbackup']}'");
    if (isset($json_post_encoded['dados']['terraform']))
      array_push($campos, "terraform = '{$json_post_encoded['dados']['terraform']}'");          
    if (isset($json_post_encoded['dados']['jboss_apache_status']))
      array_push($campos, "jboss_apache_status = '{$json_post_encoded['dados']['jboss_apache_status']}'");
      if (isset($json_post_encoded['dados']['nome_imagem']))
      array_push($campos, "nome_imagem = '{$json_post_encoded['dados']['nome_imagem']}'");
    if (isset($json_post_encoded['dados']['versao_imagem']))
      array_push($campos, "versao_imagem = '{$json_post_encoded['dados']['versao_imagem']}'");

    $dados = implode(",", $campos) . ", data_atualizacao = '{$json_post_encoded["dados"]["data_atualizacao"]}'";

    if (isset($json_post_encoded['consulta']['id']))
      $consulta = "id ={$json_post_encoded['consulta']['id']}";
    else
      $consulta = "sistema = '{$json_post_encoded['consulta']['sistema']}' and 
        ambiente = '{$json_post_encoded['consulta']['ambiente']}' and
        servidores_json ilike '%{$json_post_encoded['consulta']['hostname']}%'";

    $sql = "UPDATE servidores SET $dados WHERE $consulta";

    $db->exec($sql);

    $json_post_encoded["retorno"]["status"] = "sucesso";
    $json_post_encoded["retorno"]["mensagem"] = "cadastro realizado com sucesso!";
    http_response_code(201);
  } catch (Exception $e) {
    $json_post_encoded["retorno"]["status"] = "erro";
    $json_post_encoded["retorno"]["mensagem"] = "Erro ao salvar o item. Descrição: {$e->getMessage()}";
  } finally {
    Transaction::close();
  }

  return ($json_post_encoded);
}

function editarServidorPortal($json_post)
{

  $json_post_encoded = json_decode($json_post, true);
  $json_post_encoded["dados"]["data_atualizacao"] = date('Y-m-d H:i:s');
  //$json_post_encoded["dados"]["status"] = "ativado";

  try {
    Transaction::open('database');
    $db = Transaction::get();

    $campos = [];

    if (isset($json_post_encoded['dados']['versao']))
      array_push($campos, "versao = '{$json_post_encoded['dados']['versao']}'");
    if (isset($json_post_encoded['dados']['site']))
      array_push($campos, "site = '{$json_post_encoded['dados']['site']}'");
    if (isset($json_post_encoded['dados']['status']))
      array_push($campos, "status = '{$json_post_encoded['dados']['status']}'");
    if (isset($json_post_encoded['dados']['modulo']))
      array_push($campos, "sistema = '{$json_post_encoded['dados']['modulo']}'");
    if (isset($json_post_encoded['dados']['ambiente']))
      array_push($campos, "ambiente = '{$json_post_encoded['dados']['ambiente']}'");
    if (isset($json_post_encoded['dados']['plataforma']))
      array_push($campos, "plataforma = '{$json_post_encoded['dados']['plataforma']}'");
    if (isset($json_post_encoded['dados']['versao_plataforma']))
      array_push($campos, "versao_plataforma = '{$json_post_encoded['dados']['versao_plataforma']}'");
    if (isset($json_post_encoded['dados']['servidores'])) {
      $servidor = '[{"nome":"'.$json_post_encoded['dados']['servidores'][0]['nome'].'","ip":"'.$json_post_encoded['dados']['servidores'][0]['ip'].'"}]';
      array_push($campos, "servidores_json = '{$servidor}'");
    }
    if (isset($json_post_encoded['dados']['produto']))
      array_push($campos, "produto = '{$json_post_encoded['dados']['produto']}'");
    if (isset($json_post_encoded['dados']['ipbackup']))
      array_push($campos, "ipbackup = '{$json_post_encoded['dados']['ipbackup']}'");
    if (isset($json_post_encoded['dados']['terraform'])) {
      $tf = $json_post_encoded['dados']['terraform'] == true ? 1 : 0;
      array_push($campos, "terraform = '{$tf}'");
    }
    if (isset($json_post_encoded['dados']['jboss_apache_status']))
      array_push($campos, "jboss_apache_status = '{$json_post_encoded['dados']['jboss_apache_status']}'");
      if (isset($json_post_encoded['dados']['nome_imagem']))
      array_push($campos, "nome_imagem = '{$json_post_encoded['dados']['nome_imagem']}'");
    if (isset($json_post_encoded['dados']['versao_imagem']))
      array_push($campos, "versao_imagem = '{$json_post_encoded['dados']['versao_imagem']}'");

    $dados = implode(",", $campos) . ", data_atualizacao = '{$json_post_encoded["dados"]["data_atualizacao"]}'";

    if (isset($json_post_encoded['consulta']['id']))
      $consulta = "id ={$json_post_encoded['consulta']['id']}";
    else
      $consulta = "sistema = '{$json_post_encoded['consulta']['sistema']}' and 
        ambiente = '{$json_post_encoded['consulta']['ambiente']}' and
        servidores_json ilike '%{$json_post_encoded['consulta']['hostname']}%'";

    $sql = "UPDATE servidores SET $dados WHERE $consulta";

    $db->exec($sql);

    $json_post_encoded["retorno"]["status"] = "sucesso";
    $json_post_encoded["retorno"]["mensagem"] = "cadastro realizado com sucesso!";
    http_response_code(201);
  } catch (Exception $e) {
    $json_post_encoded["retorno"]["status"] = "erro";
    $json_post_encoded["retorno"]["mensagem"] = "Erro ao salvar o item. Descrição: {$e->getMessage()}";
  } finally {
    Transaction::close();
  }

  return ($json_post_encoded);
}

function removerServidores($json)
{

  $arrayJson = json_decode($json, true);

  $id = $arrayJson['id'];
  $nome = '';

  try {
    Transaction::open('database');
    $db = Transaction::get();
    $sql = "select * from servidores where id = {$id} and solicitacoes_id is null";
    $res = $db->query($sql, PDO::FETCH_ASSOC)->fetch();

    if (isset($res['sistema'])) {
      $db->exec("delete from servidores where id = {$id}");
      $mensagem = "servidor excluido com sucesso";
    } else {
      $mensagem = "servidor não pode ser excluido pois existe em solicitação de regra ";
    }
  } catch (Exception $e) {
    $mensagem = "Ao excluir o tipo: {$nome}. Descricao: {$e->getMessage()}";
  } finally {
    Transaction::close();
  }

  return ($mensagem);
}

function cadastrarServidores($json_post)
{
  $json_post_encoded["dados"] = json_decode($json_post, true);
  $json_post_encoded["dados"]["data_inclusao"] = date('Y-m-d H:i:s');
  if (isset($json_post_encoded["dados"]["servidores"]))
    $servidores = json_encode($json_post_encoded["dados"]["servidores"]);
  $validacao = true;
  $erros = [];
  Transaction::open('database');
  $db = Transaction::get();

  $s = explode('-', $json_post_encoded['dados']['sistema']);
  $resSistema = $db->query("select * from sistemas where sigla = '{$s[0]}' ", PDO::FETCH_ASSOC)->fetch();
  $id = 0;

  // validações antes de cadastrar servidores
  if (isset($json_post_encoded["dados"]["servidores"])) {
    $sql = "select count(id) as qtd  from servidores where servidores_json = '{$servidores}' and sistema='{$json_post_encoded["dados"]["sistema"]}' and ambiente ='{$json_post_encoded["dados"]["ambiente"]}' and status = 'ativado' ";
    $res = $db->query($sql, PDO::FETCH_ASSOC)->fetch();

    if ($res['qtd'] > 0) {
      $validacao = false;
      array_push($erros, "Servidor já está cadastrado para esse sistema e ambiente");
    }
  }

  if (!isset($json_post_encoded["dados"]["sistema"]) || $json_post_encoded["dados"]["sistema"] == '') {
    $validacao = false;
    array_push($erros, "Preencha o campo sistema");
  }

  if (!isset($json_post_encoded["dados"]["plataforma"]) || $json_post_encoded["dados"]["plataforma"] == '') {
    $validacao = false;
    array_push($erros, "Preencha o campo plataforma");
  }
  /*
    if (!isset($json_post_encoded["dados"]["site"]) || $json_post_encoded["dados"]["site"] == '') {
      $validacao = false;
      array_push($erros, "Preencha o campo site");
    }
*/
  if (!isset($json_post_encoded["dados"]["site"]))
    $json_post_encoded["dados"]["site"] = 'vazio';

  if (!isset($json_post_encoded["dados"]["ambiente"]) || $json_post_encoded["dados"]["ambiente"] == '') {
    $validacao = false;
    array_push($erros, "Preencha o campo ambiente");
  }

  if (!isset($json_post_encoded["dados"]["ipbackup"]))
    $json_post_encoded["dados"]["ipbackup"] = "";

  try {
    if ($validacao) {
      $criteria_servidores = new Criteria();
      $criteria_servidores->add(new Filter('sistema', '=', $json_post_encoded["dados"]["sistema"]));
      $criteria_servidores->add(new Filter('ambiente', '=', $json_post_encoded["dados"]["ambiente"]));
      $criteria_servidores->add(new Filter('status', '=', "ativado"));
      $servidor = Servidor::all($criteria_servidores);
      $origem = strtoupper("{$json_post_encoded["dados"]["sistema"]}_{$json_post_encoded["dados"]["ambiente"]}_{$json_post_encoded["dados"]["site"]}_SERVIDOR");
      $regra = $db->query("SELECT * from vw_regras_mudanca where sistema = '{$json_post_encoded["dados"]["sistema"]}' and ambiente = '{$json_post_encoded["dados"]["ambiente"]}'", PDO::FETCH_ASSOC)->fetch();

      if (isset($regra['id_regras']))
        $tipo = 'adicional';
      else
        $tipo = 'novo';

      $terraform = isset($json_post_encoded["dados"]['terraform'])?$json_post_encoded["dados"]['terraform']:false;
      /* if (!isset($regra['terraform']))
        $terraform = false;
      else
        $terraform = $regra['terraform']; */

      if (!isset($regra['cluster']))
        $cluster = 'nao_consta';
      else 
        $cluster = $regra['cluster'];

      if ((empty($servidor)) || ($servidor === NULL)) {
        $servidor = new Servidor();
        $servidor->sistema = $json_post_encoded["dados"]["sistema"];
        $servidor->ambiente = $json_post_encoded["dados"]["ambiente"];
        $servidor->plataforma = $json_post_encoded["dados"]["plataforma"];
        $servidor->produto = $json_post_encoded["dados"]["produto"];
        $servidor->versao_plataforma = $json_post_encoded["dados"]["versao"];
        $servidor->site = $json_post_encoded["dados"]["site"];
        $servidor->servidores_json = $servidores;
        $servidor->objeto_origem = $origem;
        $servidor->data_inclusao = $json_post_encoded["dados"]["data_inclusao"];
        $servidor->ipbackup = $json_post_encoded["dados"]["ipbackup"];
        $servidor->status = "ativado";        
        $servidor->tipo = $tipo;
        $servidor->cluster = $cluster;
        $servidor->terraform = $terraform;
        $servidor->jboss_apache_status = "ativado";
        $servidor->cpu = isset($json_post_encoded["dados"]['cpu'])? $json_post_encoded["dados"]['cpu'] : null;
        $servidor->memoria = isset($json_post_encoded["dados"]['memoria'])? $json_post_encoded["dados"]['memoria'] : null;
        $servidor->disco_opt = isset($json_post_encoded["dados"]['disco_opt'])? $json_post_encoded["dados"]['disco_opt'] : null;
        $servidor->disco_log = isset($json_post_encoded["dados"]['disco_log'])? $json_post_encoded["dados"]['disco_log'] : null;
        $servidor->nome_imagem = isset($json_post_encoded["dados"]['nome_imagem'])? $json_post_encoded["dados"]['nome_imagem'] : null;
        $servidor->versao_imagem = isset($json_post_encoded["dados"]['versao_imagem'])? $json_post_encoded["dados"]['versao_imagem'] : null;
        $servidor->store();

        // cadastro do sistema caso ainda não exista
        if (!isset($resSistema['sigla'])) {
          $sql = "insert into sistemas (data_inclusao, sigla, status) values ('{$json_post_encoded["dados"]["data_inclusao"]}', '{$s[0]}', 'ativado')";
          $db->exec($sql);
          $reg = $db->query("SELECT MAX(ID) id FROM sistemas", PDO::FETCH_ASSOC)->fetch();
          $id = $reg['id'];
        } else {
          $id = $resSistema['id'];
        }

        // cadastro da solicitação do módulo por ambiente caso não exista
        $regSol = $db->query("select modulo from solicitacoes_infra where modulo ilike '%{$json_post_encoded['dados']['sistema']}%' and ambiente = '{$json_post_encoded["dados"]["ambiente"]}' and status = 'ativado'", PDO::FETCH_ASSOC)->fetch();

        if (!isset($regSol['modulo'])) {
          $reg = $db->query("select * from limites_cotas where ambiente = '{$json_post_encoded["dados"]["ambiente"]}' and classe = 1 and tipo = '{$json_post_encoded["dados"]["plataforma"]}'", PDO::FETCH_ASSOC)->fetch();

          $prov = json_decode($json_post, true);
          $prov['solicitante'] = 'C000000';
          $prov['backends'] = [];
          $prov['plataforma'] = [];
          $prov['solicitacao_pai'] = '';
          $prov['evolui'] = 'sim';
          $prov['id_sistema'] = $id;
          $prov['id_cota'] = $reg["id_limites_cotas"];
          $prov['status'] = 'ativado';
          $sol = solicitarInfraestrutura(json_encode($prov));

          //backends
          $sqlBck = "select distinct stb.id_tipo_backend, tbck.tipo tipo_backend, stb.tipo from solicitacoes_infra si
            inner join solicitacoes_tipo_backends stb on stb.id_solicitacao = si.id
            inner join tipo_backend tbck on tbck.id = stb.id_tipo_backend
            where si.status = 'ativado' and si.modulo = '{$json_post_encoded['dados']['sistema']}' and si.ambiente = 'des'";

          $regBck = $db->query($sqlBck, PDO::FETCH_ASSOC)->fetchall();

          if (count($regBck) > 0) {
            $bck = '';
            foreach ($regBck as $r) {
              $db->exec("INSERT INTO solicitacoes_tipo_backends (id_solicitacao, id_tipo_backend, data_inclusao, tipo, status, ambiente) values ({$sol["retorno"]["id_solicitacao"]}, {$r['id_tipo_backend']}, '{$json_post_encoded["dados"]["data_inclusao"]}', '{$r['tipo']}', 'pendente', '{$json_post_encoded["dados"]["ambiente"]}')");
              $bck .= "\"{$r['tipo_backend']}\",";
            }
            $bck = substr($bck, 0, -1);
            $db->exec("UPDATE solicitacoes_infra set backends = '[{$bck}]' where id = {$sol["retorno"]["id_solicitacao"]}");
          }

          // plataforma
          $sqlPlat = "select sp.id_plataforma from solicitacoes_infra si
            inner join solicitacoes_plataforma sp on sp.id_solicitacao = si.id
            where si.modulo = '{$json_post_encoded['dados']['sistema']}' and si.ambiente = 'des' and si.status = 'ativado'";

          $regPlat = $db->query($sqlPlat, PDO::FETCH_ASSOC)->fetchall();

          if (count($regPlat) > 0){

            foreach ($regPlat as $r) {
              $db->exec("INSERT INTO solicitacoes_plataforma (id_plataforma, id_solicitacao) values ({$r['id_plataforma']}, {$sol["retorno"]["id_solicitacao"]})");
            }
          }
            
        }

        $json_post_encoded["retorno"]["status"] = "sucesso";
        $json_post_encoded["retorno"]["mensagem"] = "cadastro realizado com sucesso!";
        http_response_code(201);
      } else {

        $servidor = new Servidor();
        $servidor->sistema = $json_post_encoded["dados"]["sistema"];
        $servidor->ambiente = $json_post_encoded["dados"]["ambiente"];
        $servidor->plataforma = $json_post_encoded["dados"]["plataforma"];
        $servidor->produto = $json_post_encoded["dados"]["produto"];
        $servidor->versao_plataforma = $json_post_encoded["dados"]["versao"];
        $servidor->site = $json_post_encoded["dados"]["site"];
        $servidor->servidores_json = $servidores;
        $servidor->objeto_origem = $origem;
        $servidor->data_inclusao = $json_post_encoded["dados"]["data_inclusao"];
        $servidor->ipbackup = $json_post_encoded["dados"]["ipbackup"];
        $servidor->status = "ativado";
        $servidor->terraform = $terraform;
        $servidor->tipo = $tipo;
        $servidor->jboss_apache_status = "ativado";
        $servidor->cpu = isset($json_post_encoded["dados"]['cpu'])? $json_post_encoded["dados"]['cpu'] : null;
        $servidor->memoria = isset($json_post_encoded["dados"]['memoria'])? $json_post_encoded["dados"]['memoria'] : null;
        $servidor->disco_opt = isset($json_post_encoded["dados"]['disco_opt'])? $json_post_encoded["dados"]['disco_opt'] : null;
        $servidor->disco_log = isset($json_post_encoded["dados"]['disco_log'])? $json_post_encoded["dados"]['disco_log'] : null;
        $servidor->nome_imagem = isset($json_post_encoded["dados"]['nome_imagem'])? $json_post_encoded["dados"]['nome_imagem'] : null;
        $servidor->versao_imagem = isset($json_post_encoded["dados"]['versao_imagem'])? $json_post_encoded["dados"]['versao_imagem'] : null;
        $servidor->store();

        // cadastro do sistema caso ainda não exista
        if (!isset($resSistema['sigla'])) {
          $sql = "insert into sistemas (data_inclusao, sigla, status) values ('{$json_post_encoded["dados"]["data_inclusao"]}', '{$s[0]}', 'ativado')";
          $db->exec($sql);
          $reg = $db->query("SELECT MAX(ID) id FROM sistemas", PDO::FETCH_ASSOC)->fetch();
          $id = $reg['id'];
        } else {
          $id = $resSistema['id'];
        }

        // cadastro da solicitação do módulo por ambiente caso não exista
        $regSol = $db->query("select modulo from solicitacoes_infra where modulo ilike '%{$json_post_encoded['dados']['sistema']}%' and ambiente = '{$json_post_encoded["dados"]["ambiente"]}' and status = 'ativado'", PDO::FETCH_ASSOC)->fetch();

        if (!isset($regSol['modulo'])) {
          $reg = $db->query("select * from limites_cotas where ambiente = '{$json_post_encoded["dados"]["ambiente"]}' and classe = 1 and tipo = '{$json_post_encoded["dados"]["plataforma"]}'", PDO::FETCH_ASSOC)->fetch();

          $prov = json_decode($json_post, true);
          $prov['solicitante'] = 'C000000';
          $prov['backends'] = [];
          $prov['plataforma'] = [];
          $prov['solicitacao_pai'] = '';
          $prov['evolui'] = 'sim';
          $prov['id_sistema'] = $id;
          $prov['id_cota'] = $reg["id_limites_cotas"];
          $prov['status'] = 'ativado';
          $sol = solicitarInfraestrutura(json_encode($prov));

          //backends
          $sqlBck = "select distinct stb.id_tipo_backend, tbck.tipo tipo_backend, stb.tipo from solicitacoes_infra si
            inner join solicitacoes_tipo_backends stb on stb.id_solicitacao = si.id
            inner join tipo_backend tbck on tbck.id = stb.id_tipo_backend
            where si.status = 'ativado' and si.modulo = '{$json_post_encoded['dados']['sistema']}' and si.ambiente = 'des'";

          $regBck = $db->query($sqlBck, PDO::FETCH_ASSOC)->fetchall();

          if (count($regBck) > 0) {
            $bck = '';
            foreach ($regBck as $r) {
              $db->exec("INSERT INTO solicitacoes_tipo_backends (id_solicitacao, id_tipo_backend, data_inclusao, tipo, status, ambiente) values ({$sol["retorno"]["id_solicitacao"]}, {$r['id_tipo_backend']}, '{$json_post_encoded["dados"]["data_inclusao"]}', '{$r['tipo']}', 'pendente', '{$json_post_encoded["dados"]["ambiente"]}')");
              $bck .= "\"{$r['tipo_backend']}\",";
            }
            $bck = substr($bck, 0, -1);
            $db->exec("UPDATE solicitacoes_infra set backends = '[{$bck}]' where id = {$sol["retorno"]["id_solicitacao"]}");
          }

          // plataforma
          $sqlPlat = "select sp.id_plataforma from solicitacoes_infra si
            inner join solicitacoes_plataforma sp on sp.id_solicitacao = si.id
            where si.modulo = '{$json_post_encoded['dados']['sistema']}' and si.ambiente = 'des' and si.status = 'ativado'";

          $regPlat = $db->query($sqlPlat, PDO::FETCH_ASSOC)->fetchall();

          if (count($regPlat) > 0)
          foreach ($regPlat as $r) {
            $db->exec("INSERT INTO solicitacoes_plataforma (id_plataforma, id_solicitacao) values ({$r['id_plataforma']}, {$sol["retorno"]["id_solicitacao"]})");
          }
        }
        http_response_code(201);

        $json_post_encoded["retorno"]["status"] = "sucesso";
        $json_post_encoded["retorno"]["mensagem"] = "cadastro realizado com sucesso!";
      }
    } else {
      $json_post_encoded["retorno"]["status"] = "erro";
      $json_post_encoded["retorno"]["erros"] = $erros;
    }
  } catch (Exception $e) {
    $json_post_encoded["retorno"]["status"] = "erro";
    $json_post_encoded["retorno"]["mensagem"] = "Erro salvar o item. Descrição: {$e->getMessage()}";
  } finally {
    Transaction::close();
  }

  return ($json_post_encoded);
}

function solicitarWOServidor($json)
{
  try {
    Transaction::open('database');
    $db = Transaction::get();
    $wo = new WO("hmp");

    //formatando dados para a WO
    $array_json = json_decode($json, true);
    $array_json["data_solicitacao"] = date('Y-m-d H:i:s');

    /*$sql = "select objeto_origem from servidores where id = {$array_json['id']}";
      $origem = $db->query($sql, PDO::FETCH_ASSOC)->fetch();

      if (isset($origem['objeto_origem']))
        $objeto_origem = $origem['objeto_origem'];
      else*/

    $objeto_origem = strtoupper("\"{$array_json["sistema"]}_{$array_json["ambiente"]}_servidor\"");

    $ip = "";

    foreach ($array_json['servidores'] as $serv) {
      $ip .= "{$serv["servidores"][0]['ip']}, ";
    }

    $dtE = date("Y-m-d") . "T19:00:00-03:00";
    $dtF = date("Y-m-d", strtotime('+1 day')) . "T19:00:00-03:00";
    $descricaowo = "À\nCETAD/REDES\n\n1. Solicitamos incluir o IP: {$ip} 
      no objeto de firewall network: {$objeto_origem}.\n\nAt.te\n\nCETAD36";

    //GERANDO WO
    //$wo->token = $wo->getToken("USR_CETADPOR1", "CETADPOR1");
    $wo->token = $wo->getToken("USR_CETADAUT2", "CETADAUT2");
    $req = $wo->getREQ();

    $wo->setQuestionario($req, $dtE, $dtF, $descricaowo);
    $wo->processarREQ($req);
    $busca =  $wo->buscarREQ($req);
    sleep(10);

    $numwo = $wo->buscarNumWO($busca->entries[0]->values->GSC_chrNumeroRequisicao);

    //RETORNANDO WO  e salvado no banco de dados
    $retorno = [
      "requisicao" => $busca->entries[0]->values->GSC_chrNumeroRequisicao,
      "wo" => $numwo->entries[0]->values->{'Work Order ID'}
    ];

    //inserir as ids de WO e REQUISIÇÃO no banco de dados
    $statement = $db->prepare("INSERT INTO solicitacoes_id (id_mudanca, id_req, data_inclusao) values (:id_mudanca, :id_req, :inclusao)");
    $statement->bindValue(":id_mudanca", $retorno['wo']);
    $statement->bindValue(":id_req", $retorno['requisicao']);
    $statement->bindValue(":inclusao", $array_json["data_solicitacao"]);
    $statement->execute();
    $res = $db->query("select max(id) as id from solicitacoes_id", PDO::FETCH_ASSOC)->fetch();

    //atualizar servidor
    foreach ($array_json['servidores'] as $serv) {
      $statement = $db->prepare("update servidores  SET solicitacoes_id = :sol_id, tipo = 'adicional' where id = :id ");
      $statement->bindValue(":sol_id", $res['id']);
      $statement->bindValue(":id",  $serv['id']);
      $statement->execute();
    }


    return "enviado com sucesso";
  } catch (Exception $e) {
    $array = [];
    $array['erro'] = "erro execucao da query";
    Transaction::close();
    return $array;
  } finally {
    Transaction::close();
  }
}


function listarServidoresCadastrados($parametros) {
  try {
    Transaction::open('database');
    $db = Transaction::get();
    $arrayBindValue = [ ];
    $sql = "SELECT s.id, s.sistema, s.ambiente, s.plataforma, s.versao_plataforma, s.produto, s.servidores_json, 
    s.data_inclusao, s.solicitacoes_id, s.status, s.ipbackup, s.id_limites_cotas, s.site, s.jboss_apache_status, 
    s.cluster, s.terraform, s.cpu, s.memoria, s.disco_opt, s.disco_log, i.nome as nome_imagem, i.versao as versao_imagem, i.detalhamento as detalhe_imagem from servidores s
    left outer join imagens i on i.versao = s.versao_imagem and i.nome = s.nome_imagem
    where s.status <> '' "; 
    foreach ($parametros as $indice => $valor) {
      if ($indice != 'acao') {
        switch ($indice) {
          case 'id':
          case 'status':
          case 'id_regras':
          case 'site':
          case 'sistema':
          case 'ambiente':
          case 'plataforma':
          $sqlinicial[] = "s.{$indice} = :{$indice} ";
          break;     
        }

        $arrayBindValue[$indice] = $valor;
      }
    }
    
    if (count($parametros) > 1 ) {
      $sql = $sql . ' AND '. implode(" AND ", $sqlinicial);
    }

    $statement = $db->prepare($sql);
    foreach ($arrayBindValue as $indice => $valor) {
        $statement->bindValue ( ":{$indice}", $valor);
    }
    $statement->execute();
    $registros = $statement->rowCount();
    $arrayRetorno = array();
    
    if ($registros == 0) {
      $array['info'] = "não foram encontrados resultados.";
      return $array;
      die;
    }
    $qtd_apache = 0;
    $amb = "";

    foreach ($statement as $row ) {
      
      $arraySistemas[] = array (
      'id' => $row['id'],
      'status' => $row['status'],
      'sistema' => $row['sistema'],
      'ambiente' => $row['ambiente'],
      'plataforma' => $row['plataforma'],
      'produto' => $row['produto'],
      'site' => $row['site'],
      'ipbackup' => $row['ipbackup'],
      'versao_plataforma' => $row['versao_plataforma'],
      'solicitacoes_id' => $row['solicitacoes_id'],
      'servidores_json' => json_decode($row['servidores_json'], true),
      'inclusao' => $row['data_inclusao'],
      'jboss_apache_status' => $row['jboss_apache_status'],
      'cluster' => $row['cluster'],
      'terraform' => $row['terraform'],
      'cpu' => $row['cpu'],
      'memoria' => $row['memoria'],
      'disco_log' => $row['disco_log'],
      'disco_opt' => $row['disco_opt'],
      'nome_imagem' => $row['nome_imagem'],
      'versao_imagem' => $row['versao_imagem'],
      'detalhe_imagem' => $row['detalhe_imagem']
      );
      $amb = $row['ambiente'];
      if ($row['produto'] == 'apache')
        $qtd_apache++;
    }
  
    $arrayRetorno["registros"] = $registros;
    $arrayRetorno["dados"] = $arraySistemas;
    
    return $arrayRetorno;
    } catch ( Exception $e ) {
    $array = [];
    $array['erro'] = "erro execucao da query".$e->getMessage();
    Transaction::close ();
    return $array;
    } finally {
    Transaction::close ();
  }
}
function listarServidoresCadastradosSistema($parametros) {
  try {
    Transaction::open('database');
    $db = Transaction::get();
    $arrayBindValue = [ ];
    $sql = "SELECT s.id, s.sistema, s.ambiente, s.plataforma, s.versao_plataforma, s.produto, s.servidores_json, 
    s.data_inclusao, s.solicitacoes_id, s.status, s.ipbackup, s.id_limites_cotas, s.site, s.jboss_apache_status,
    s.terraform, s.cpu, s.memoria, s.disco_opt, s.disco_log, i.nome as nome_imagem, i.versao as versao_imagem, i.detalhamento as detalhe_imagem from servidores s
    left outer join imagens i on i.versao = s.versao_imagem and i.nome = s.nome_imagem  
    where s.status <> ''"; 
    $s = "";
    foreach ($parametros as $indice => $valor) {
      if ($indice != 'acao') {
        switch ($indice) {
          case 'id':
          case 'status':
          case 'id_regras':
          case 'ambiente':
          case 'plataforma':
          $sqlinicial[] = "s.{$indice} = :{$indice} ";
          break;     
        }

        $arrayBindValue[$indice] = $valor;
      }
    }

    if (array_key_exists('site', $parametros)) {
      $s = "s.site ilike any (array[{$parametros['site']}])";
      $sql .= " and $s";
      unset($parametros['site']);
      unset($arrayBindValue['site']);
    }

    if (array_key_exists('sistema', $parametros)) {
      $s = "s.sistema ilike '%{$parametros['sistema']}%'";
      $sql .= " and $s";
      unset($parametros['sistema']);
      unset($arrayBindValue['sistema']);
    }

    if (count($parametros) > 1 ) {
      $sql = $sql . ' AND '. implode(" AND ", $sqlinicial);
    }
    
    $sql = $sql . ' order by s.site, s.servidores_json';  

    $statement = $db->prepare($sql);
    foreach ($arrayBindValue as $indice => $valor) {
      $statement->bindValue ( ":{$indice}", $valor);
    }

    $statement->execute();
    $registros = $statement->rowCount();
    $arrayRetorno = array();
    
    if ($registros == 0) {
      $array['info'] = "não foram encontrados resultados.";
      return $array;
      die;
    }
    $qtd_apache = 0;
    $amb = "";

    foreach ($statement as $row ) {
      
      $arraySistemas[] = array (
      'id' => $row['id'],
      'status' => $row['status'],
      'sistema' => $row['sistema'],
      'ambiente' => $row['ambiente'],
      'plataforma' => $row['plataforma'],
      'produto' => $row['produto'],
      'site' => $row['site'],
      'ipbackup' => $row['ipbackup'],
      'versao_plataforma' => $row['versao_plataforma'],
      'solicitacoes_id' => $row['solicitacoes_id'],
      'servidores_json' => json_decode($row['servidores_json'], true),
      'inclusao' => $row['data_inclusao'],
      'jboss_apache_status' => $row['jboss_apache_status'],
      'terraform' => $row['terraform'],
      'cpu' => $row['cpu'],
      'memoria' => $row['memoria'],
      'disco_log' => $row['disco_log'],
      'disco_opt' => $row['disco_opt'],
      'nome_imagem' => $row['nome_imagem'],
      'versao_imagem' => $row['versao_imagem'],
      'detalhe_imagem' => $row['detalhe_imagem']
      );
      if ($row['produto'] == 'apache')
        $qtd_apache++;
    }
  
    $arrayRetorno["registros"] = $registros;
    $arrayRetorno["dados"] = $arraySistemas;
    
    return $arrayRetorno;
    } catch ( Exception $e ) {
    $array = [];
    $array['erro'] = "erro execucao da query";
    Transaction::close ();
    return $array;
    } finally {
    Transaction::close ();
  }
}

  function listarServidorAdicionalModulo($parametros) {
    try {
      Transaction::open('database');
      $db = Transaction::get();
      $arrayBindValue = [ ];
      $sql = "select id, sistema, servidores_json, ambiente, tipo from servidores where solicitacoes_id is null and status = 'ativado' and tipo = 'adicional' and ";
      
      foreach ($parametros as $indice => $valor) {
        if ($indice != 'acao') {
          $sqlinicial[] = " {$indice} = :{$indice} ";
          $arrayBindValue[$indice] = $valor;
        }
      }
      
      if (count($parametros) > 1 ) {
        $sql = $sql . implode(" AND ", $sqlinicial);
      }
      
      $statement = $db->prepare($sql);
      foreach ($arrayBindValue as $indice => $valor) {
        $statement->bindValue ( ":{$indice}", $valor );
      }
      
      $statement->execute();
      $registros = $statement->rowCount();
      $arrayResultado = array();
      $arrayResultado["registros"] = $registros;
      
      if ($registros == 0) {
        $array['info'] = "não foram encontrados resultados.";
        return $array;
        die;
      }
      
      foreach ($statement as $row ) {
        
        $arrayRetorno[] = array (
        'sistema' => $row['sistema'],
        'id' => $row['id'],
        'servidores' => json_decode($row['servidores_json']),
        'ambiente' => $row['ambiente'],
        'tipo' => $row['tipo']
        );
      }
      
      $arrayResultado["dados"] = $arrayRetorno;
      
      return $arrayResultado;
      } catch ( Exception $e ) {
        $array = [];
        $array['erro'] = "erro execucao da query";
        Transaction::close();
        return $array;
      } finally {
        Transaction::close();
      }    
  }

  function listarServidorAdicional($parametros) {
    try {
      Transaction::open('database');
      $db = Transaction::get();
      $arrayBindValue = [ ];
      $sql = "SELECT * from vw_servidor_adicional";
      
      foreach ($parametros as $indice => $valor) {
        if ($indice != 'acao') {
          $sqlinicial[] = "{$indice} = :{$indice} ";
          $arrayBindValue[$indice] = $valor;
        }
      }
      
      if (count($parametros) > 1 ) {
        $sql = $sql . ' WHERE '. implode(" AND ", $sqlinicial);
      }
      
      $statement = $db->prepare($sql);
      foreach ($arrayBindValue as $indice => $valor) {
        $statement->bindValue ( ":{$indice}", $valor );
      }
      
      $statement->execute();
      $registros = $statement->rowCount();
      $arrayResultado = array();
      $arrayResultado["registros"] = $registros;
      
      if ($registros == 0) {
        $array['info'] = "não foram encontrados resultados.";
        return $array;
        die;
      }
      
      foreach ($statement as $row ) {
        
        $arrayRetorno[] = array (
        'sistema' => $row['sistema'],
        'id' => $row['id_solicitacao'],
        'req' => $row['req'],
        'wo' => $row['wo'],
        'solicitante' => $row['solicitante'],
        'centralizadora' => $row['centralizadora'],
        'data_order' => $row['data_order'],
        'ambiente' => $row['ambiente'],
        'tipo' => $row['tipo']
        );
      }
      
      $arrayResultado["dados"] = $arrayRetorno;
      
      return $arrayResultado;
      } catch ( Exception $e ) {
      $array = [];
      $array['erro'] = "erro execucao da query";
      Transaction::close();
      return $array;
      } finally {
      Transaction::close();
      }
  }

  
  

  function listarServidoresParaVIP($parametros) {

  
    try {
      Transaction::open('database');
      $db = Transaction::get();
      $arrayBindValue = [ ];
      $sql = "SELECT distinct (sistema), ambiente, versao_plataforma, plataforma, produto from servidores where status <> ''"; 
      $s = "";
      foreach ($parametros as $indice => $valor) {
        if ($indice != 'acao') {
          switch ($indice) {
            case 'status':
            case 'id_regras':
            case 'site':
            case 'ambiente':
            $sqlinicial[] = "{$indice} = :{$indice} ";
            break;     
          }

          $arrayBindValue[$indice] = $valor;
        }
      }
      if (array_key_exists('sistema', $parametros)) {
        $s = "sistema ilike '%{$parametros['sistema']}%'";
        $sql .= " and $s";
        unset($parametros['sistema']);
        unset($arrayBindValue['sistema']);
      }

      if (count($parametros) > 1 ) {
        $sql = $sql . ' AND '. implode(" AND ", $sqlinicial);
      }
        
      $statement = $db->prepare($sql);
      foreach ($arrayBindValue as $indice => $valor) {
        $statement->bindValue ( ":{$indice}", $valor);
      }
      
      $statement->execute();
      $registros = $statement->rowCount();
      $arrayRetorno = array();
      
      if ($registros == 0) {
        $array['info'] = "não foram encontrados resultados.";
        return $array;
        die;
      }
      $qtd_apache = 0;
      $amb = "";

      foreach ($statement as $row ) {
        
        $arraySistemas[] = array (
        'sistema' => $row['sistema'],
        'ambiente' => $row['ambiente'],
        'produto' => $row['produto'],
        'plataforma' => $row['plataforma'],
        'versao_plataforma' => $row['versao_plataforma']
        );
        if ($row['produto'] == 'apache')
          $qtd_apache++;
      }
    
      $arrayRetorno["registros"] = $registros;
      $arrayRetorno["dados"] = $arraySistemas;
      
      return $arrayRetorno;
      } catch ( Exception $e ) {
      $array = [];
      $array['erro'] = "erro execucao da query";
      Transaction::close ();
      return $array;
      } finally {
      Transaction::close ();
    }
  }

  function listarServidoresParaAnteciparProducao($parametros) {

  
    try {
            
      Transaction::open('database');
      $db = Transaction::get();
      $arrayBindValue = [ ];
      $sql = "SELECT distinct id, sistema,cpu,memoria,plataforma,disco_opt,disco_log from servidores where status = 'ativado' and plataforma = 'vm' and ambiente = '{$parametros['ambiente']}' and sistema ilike '{$parametros['sistema']}%'
      and sistema not in (select sistema from servidores where status  = 'ativado' and plataforma = 'vm'
            and ambiente = 'prd' and sistema ilike '{$parametros['sistema']}%')"; 
      $sql .= " order by sistema";        
      $statement = $db->prepare($sql);
      
      
      $statement->execute();
      $registros = $statement->rowCount();
      $arrayRetorno = array();
      $arraySistemas=[];
            
      foreach ($statement as $row ) {
        
        $arraySistemas[] = array (
          'id' => $row['id'],
        'sistema' => $row['sistema'],
        'plataforma' => $row['plataforma'],
        'cpu' => $row['cpu'],
        'memoria' => $row['memoria'],
        'disco_opt' => $row['disco_opt'],
        'disco_log' => $row['disco_log'],
        );        
      }
    
      $arrayRetorno["registros"] = $registros;
      $arrayRetorno["dados"] = $arraySistemas;
      
      return Utils::apiReturnObject("OK",$arrayRetorno);
      } catch ( Exception $e ) {
      $array = [];
      $array['erro'] = "erro execucao da query";
      Transaction::close ();
      return Utils::apiReturn("ERROR",$e->getMessage());
      } finally {
      Transaction::close ();
    }
  }

  function listarSiteProducaoParaAnteciparProducao($parametros) {

  
    try {
      
      Transaction::open('database');
      $db = Transaction::get();
      $arrayBindValue = [ ];
      $sql = "SELECT distinct site from servidores where status = 'ativado' 
      and ambiente = 'prd' "; 
      $s = "";
      
      if (array_key_exists('sistema', $parametros)) {
        $s = "sistema ilike '%{$parametros['sistema']}%'";
        $sql .= " and $s";
        
      }
      $sql .= " order by site";
      
        
      $statement = $db->prepare($sql);
      
      
      $statement->execute();
      $registros = $statement->rowCount();
      $arrayRetorno = array();
      
      if ($registros == 0) {
        $statement->closeCursor();
        $sql = "SELECT site from sites"; 
        $statement = $db->prepare($sql);     
        $statement->execute();
        $registros = $statement->rowCount();
      }
      $arraySistemas =[];
      foreach ($statement as $row ) {        
        $arraySistemas[] = array (
        'site' => $row['site']   
        );        
      }
    
      $arrayRetorno["registros"] = $registros;
      $arrayRetorno["dados"] = $arraySistemas;
      
      return Utils::apiReturnObject("OK",$arrayRetorno);
      } catch ( Exception $e ) {      
      Transaction::close ();
      return Utils::apiReturn("ERROR",$e->getMessage());
      } finally {
      Transaction::close ();
    }
  }

  function cadastrarAnteciparProducao($json) {

  
    try {
      $fields = json_decode($json, true);         
      Transaction::open('database');      
      $servidor = new Servidor($fields['modulo']);
      if($servidor->id){
        if($servidor->plataforma=='container'){
          return Utils::apiReturn("ERROR","Antecipação de ambiente de produção não liberado para plataforma container.");
        }
        //recupera os parametros de alocacao de ip pelo site
        $parametros = getParametrosPorSiteAlocaIp($fields);
        if($parametros['retorno']['status'] == 'OK'){
          
        //gerar o ip e hostname
        $alocaip = new AlocaIpClient(endpoint_mudanca,user_mudanca,password_mudanca);
        $ip = $alocaip->postAlocaIp($parametros['retorno']['objeto']['parametros'],$servidor->sistema.'-'.$servidor->plataforma);        
        
        if(isset($ip->error)){
          return Utils::apiReturn("ERROR","Erro ao gerar o ip no serviço alocaip. Erro:".$ip->error);          
        }else{
          $ip2 = $alocaip->postAlocaIp($parametros['retorno']['objeto']['parametros'],$servidor->sistema.'-'.$servidor->plataforma);
          if(isset($ip2->error)){
            return Utils::apiReturn("ERROR","Erro ao gerar o ip no serviço alocaip. Erro:".$ip2->error);          
          }else{
          Transaction::open('database');
          //chamar o metodo ja existente de cadastrar servidores
          $jsonPost = '{ ';
            
            if(isset($fields['cpu'])){
              $jsonPost .= '"cpu":"'.$fields['cpu'].'",';
            }
            if(isset($fields['memoria'])){
              $jsonPost .= '"memoria":"'.$fields['memoria'].'",';
            }
            if(isset($fields['disco_opt'])){
              $jsonPost .= '"disco_opt":"'.$fields['disco_opt'].'",';
            }
            if(isset($fields['disco_log'])){
              $jsonPost .= '"disco_log":"'.$fields['disco_log'].'",';
            } 
            if($servidor->plataforma=='container'){
              $hostname1 = $servidor->sistema;
              $hostname2 = $servidor->sistema;
            } else{
              $hostname1 =strtolower($ip->Gerar[0]).".agil.caixa.gov.br";
              $hostname2 =strtolower($ip2->Gerar[0]).".agil.caixa.gov.br";
            }          
            $jsonPost .= '"sistema":"'.$servidor->sistema.'",';
            $jsonPost .= '"ambiente":"prd",';
            $jsonPost .= '"plataforma":"'.$servidor->plataforma.'",';
            $jsonPost .= '"site":"'.$fields['site'].'",';
            $jsonPost .= '"produto":"'.$servidor->produto.'",';
            $jsonPost .= '"versao":"'.$servidor->versao_plataforma.'",'; 
            $jsonPost .= '"versao_imagem":"'.$servidor->versao_imagem.'",';
            $jsonPost .= '"nome_imagem":"'.$servidor->nome_imagem.'",';                  
            $server1 = '"servidores":[{"ip":"'.$ip->Gerar[1].'","nome":"'.$hostname1.'", "ip10":"'.$ip->Gerar[2].'"}]';
            $server2 = '"servidores":[{"ip":"'.$ip2->Gerar[1].'","nome":"'.$hostname2.'", "ip10":"'.$ip2->Gerar[2].'"}]';

            $closeJson = ' }';
            $ret = cadastrarServidores($jsonPost.$server1.$closeJson);
            if($ret['retorno']['status'] == 'sucesso'){
              $ret2 = cadastrarServidores($jsonPost.$server2.$closeJson);
              if($ret2['retorno']['status'] == 'sucesso'){
                return Utils::apiReturn("OK","Módulo {$servidor->sistema} cadastrado com sucesso!");
              }else{
                return Utils::apiReturn("ERROR",isset($ret2['retorno']['mensagem']) ? $ret2['retorno']['mensagem'] : json_encode($ret2['retorno']['erros']));
              }
            }else{
              return Utils::apiReturn("ERROR",isset($ret['retorno']['mensagem']) ? $ret['retorno']['mensagem'] : json_encode($ret['retorno']['erros']));
            }
        }
      }
      }else{
       // http_response_code(404);
        return Utils::apiReturn("ERROR","Não foram encontrados parametros de alocação de ip para o site informado.");
      }
      }else{
        //http_response_code(404);
        return Utils::apiReturn("ERROR","Erro ao localizar o modulo informado.");
      }
      
      
      } catch ( Exception $e ) {    
      return Utils::apiReturn("ERROR",$e->getMessage());
      } finally {
      Transaction::close ();
    }
  }


   

  //funcoes para api de parametros do alocaip

  function listarParametrosAlocaIp($params){
  try{ 
    Transaction::open('database');
    $db = Transaction::get();
    $core = new Utils();
    return $core->getListWithSql("Select * from sites",$db);
  } finally {
    Transaction::close ();
  }
  }
  function getParametrosPorSiteAlocaIp($params){
    try{
      Transaction::open('database');
    $db = Transaction::get();
    $core = new Utils();
    return $core->getObjectWithSql("Select * from sites where site = '{$params['site']}'",$db);    
  } finally {
    Transaction::close ();
  }
  }
  function gerenciarParametrosAlocaIp($jsonPost){
  try{
    Transaction::open('database');
    $db = Transaction::get();
    $fields = json_decode($jsonPost, true);
    $ret = getParametrosPorSiteAlocaIp(array("site"=>$fields['site']));
    $parametros = json_encode($fields['parametros']);
    if($ret['retorno']['status'] == 'ERROR'){
      //INSERT
      $sql = "INSERT INTO sites(site,parametros)values('{$fields['site']}','{$parametros}')";
    }else{
      //UPDATE
      $sql = "UPDATE sites SET parametros = '{$parametros}' WHERE site = '{$fields['site']}'";
    }
    $core = new Utils();
    return $core->executeSQL($sql,$db); 
  } finally {
    Transaction::close ();
  }
  }
  function excluirParametrosAlocaIp($params){
    try{
      Transaction::open('database');
    $db = Transaction::get();
    $core = new Utils();
    return $core->executeSQL("delete from sites where site = '{$params['site']}'",$db); 
  } finally {
    Transaction::close ();
  }   
  }

  function verificaFQDN($params) {
    
    try {
      
      $cli = new DNSClient(dns_endpoint);
      $ret = $cli->consultaDisponibilidade($params['domain']);
      if(isset($ret->error)){
        throw new Exception($ret->error, 1);      
      }
  
      $arrayRetorno = array();
      $arrayRetorno['title'] ='OK';
      $arrayRetorno["available"] = $ret->available;
      
      return $arrayRetorno;
      } catch ( Exception $e ) {
      $retorno = [
        "title" => 'ERRO',
        "text" => $e->getMessage()
      ];
      
      
      return $retorno;
      } 
  } 
  