<?php
  
final class Connection
{
    private function __construct() {}
    
    public static function open($name)
    {
        $homeDir = dirname(__DIR__, 2);  
        // // verifica se existe arquivo de configuração para este banco de dados
        // if (file_exists($homeDir."/config/{$name}.ini")) {
        //     $db = parse_ini_file($homeDir."/config/{$name}.ini");
        // }
        // else {
        //     throw new Exception("Arquivo '$name' não encontrado");
        // }
        
        // lê as informações contidas no arquivo
        $user = db_user!= null ? db_user : NULL;
        $pass = db_pass!= null ? db_pass : NULL;
        $name = db_name!= null ? db_name : NULL;
        $host = db_host!= null ? db_host : NULL;
        $type = db_type!= null ? db_type : NULL;
        $port = db_port!= null ? db_port : NULL;
        
        // descobre qual o tipo (driver) de banco de dados a ser utilizado
        switch ($type) {
            case 'pgsql':
                $port = $port ? $port : '5432';
                $conn = new PDO("pgsql:dbname={$name}; user={$user}; password={$pass};host=$host;port={$port}");
                break;
            case 'mysql':
                $port = $port ? $port : '3306';
                $conn = new PDO("mysql:host={$host};port={$port};dbname={$name}", $user, $pass);
                break;
            case 'sqlite':
                $conn = new PDO("sqlite:{$name}");
                break;
            case 'ibase':
                $conn = new PDO("firebird:dbname={$name}", $user, $pass);
                break;
            case 'oci8':
                $conn = new PDO("oci:dbname={$name}", $user, $pass);
                break;
            case 'mssql':
                $conn = new PDO("mssql:host={$host},1433;dbname={$name}", $user, $pass);
                break;
        }
        // define para que o PDO lance exceções na ocorrência de erros
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $conn;
    }
}
