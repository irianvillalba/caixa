<?php

function cadastrarImagem($json_post)
{
    Transaction::open('database');
    try {
        $fields = json_decode($json_post, true);
        $db = Transaction::get();

        //verifica se existe uma novidade com o mesmo titulo
        $sql = "select nome from imagens where nome = '{$fields['nome']}' and versao = '{$fields['versao']}'";
        $statement = $db->query($sql, PDO::FETCH_ASSOC);
        $count = 0;
        if ($statement !== false) {
            $count = $statement->rowCount();
        }
        if ($count > 0) {
            http_response_code(422);  
            return Utils::apiReturn('erro', "Imagem já cadastrada com esse nome e versão.");
        }


        $obj = new Imagem();

        $obj->nome = $fields['nome'];
        $obj->status = $fields['status'];
        $obj->detalhamento =json_encode($fields['detalhamento']);
        $obj->plataforma = strtolower($fields['plataforma']);
        //$obj->produto = $fields['produto'];
        $obj->versao = $fields['versao'];
        $obj->store();
        return Utils::apiReturn('sucesso', "Imagem cadastrada com sucesso!");
    } catch (Exception $e) {
        Transaction::rollback();
        http_response_code(500);  
        return Utils::apiReturn('erro', $e->getMessage());
    } finally {
        Transaction::close();
    }
}

function ativarDesativarImagem($json_post)
{
    Transaction::open('database');
    try {
        $fields = json_decode($json_post, true);
        $db = Transaction::get();
        if($fields['status'] != 'ativo' && $fields['status'] != 'inativo'){
            http_response_code(422);  
            return Utils::apiReturn('erro', "Status deve conter 'ativo' ou 'inativo'");
        }


        
        $sql = "UPDATE imagens set status ='{$fields['status']}' where nome = '{$fields['nome']}' and versao = '{$fields['versao']}'";
        $statement = $db->exec($sql);
        
        if ($statement !== false) {
             
            return Utils::apiReturn('sucesso', "Imagem alterada com sucesso!");
        } else {
            http_response_code(400); 
            return Utils::apiReturn('erro', "erro ao alterar a imagem!");
        }
    } catch (Exception $e) {
        Transaction::rollback();
        http_response_code(500);  
        return Utils::apiReturn('erro', $e->getMessage());
    } finally {
        Transaction::close();
    }
}

function excluirImagem($paramentros)
{
    Transaction::open('database');
    try {
        $db = Transaction::get();
        $sql = "DELETE FROM imagens  WHERE nome = '{$paramentros['nome']}' and versao = '{$paramentros['versao']}'";
        $ret = $db->exec($sql);
        if ($ret === false) {
            return Utils::apiReturn('erro', "erro ao excluir a imagem!");
        }
        return Utils::apiReturn('sucesso', "Image, excluída com sucesso!");
    } catch (Exception $e) {
        Transaction::rollback();
        http_response_code(500);  
        return Utils::apiReturn('erro', $e->getMessage());
    } finally {
        Transaction::close();
    }
}

function listarImagens()
{
    Transaction::open('database');
    try {

        $db = Transaction::get();

        $sql = "select nome,status,detalhamento,plataforma,versao from imagens";
        $registros = $db->query($sql, PDO::FETCH_ASSOC)->fetchAll();
        return Utils::apiReturnList(count($registros),$registros);
    } catch (Exception $e) { 
        http_response_code(500);      
        return Utils::apiReturn('erro', $e->getMessage());
    } finally {
        Transaction::close();
    }
}

function listarImagemPorNome($parametros)
{
    Transaction::open('database');
    try {

        $db = Transaction::get();

        $sql = "select nome,status,detalhamento,plataforma,versao from imagens where nome = '{$parametros['nome']}' and versao = '{$parametros['versao']}'";
        $registro = $db->query($sql, PDO::FETCH_ASSOC)->fetch();
        if($registro === false){
            http_response_code(404);      
            return Utils::apiReturn("error","Registro não encontrado");
        }
        else return $registro;
    } catch (Exception $e) { 
        http_response_code(500);      
        return Utils::apiReturn('erro', $e->getMessage());
    } finally {
        Transaction::close();
    }
}