<?php

final class Configuration {
	
	private static $configurations = array();
	private static $name = 'database';
	
	private function __construct() {}
	
	public static function carrega($name = null) {
		$homeDir = dirname(__DIR__, 2);
		// $name = $name ? $name : self::$name;
        // if (file_exists($homeDir.'/config/database.ini')) {
        //     $config = parse_ini_file($homeDir.'/config/database.ini');
        // } else {
        //     throw new Exception("Arquivo '$name' nao encontrado");
        // }
        self::$configurations = ["ip_ldap"=>ip_ldap,"porta_ldap"=>porta_ldap];
	}
	
	public static function open($name = null) {
		if (self::$configurations == NULL) {
			self::carrega(self::$name);
		}
		return self::$configurations;
	}
	
	public static function get($variavel) {
		if (self::$configurations == NULL) {
			self::carrega(self::$name);
		}
		return self::$configurations[$variavel];
	}
	
}










