<?php
  date_default_timezone_set('America/Sao_Paulo');
  header('Content-Type: application/json; charset=utf-8');
  $homeDir = dirname(__DIR__, 1);
  include_once $homeDir.'/config/environment.php';
  include_once $homeDir.'/config/config.inc.php';
  include_once $homeDir.'/api/util/includes.php';  
  include_once $homeDir.'/includes/exceptions/MessagesException.php';
  include_once $homeDir.'/includes/exceptions/NegocioException.php';
  include_once $homeDir.'/includes/business/armazenamentoBusiness.php';
  include_once $homeDir.'/includes/functions_get.php';
  include_once $homeDir.'/includes/functions_post.php';
  include_once $homeDir.'/includes/recursosVm.php';
  include_once $homeDir.'/includes/email_caixa.php';
  include_once $homeDir.'/includes/relatorio.php';
  include_once $homeDir.'/includes/servidores.php';
  include_once $homeDir.'/includes/novidades.php';
  include_once $homeDir.'/includes/imagens.php';
  include_once $homeDir.'/includes/nuvempublica.php';
  include_once $homeDir.'/includes/methods_armazenamento.php';  
  include_once $homeDir.'/includes/backend.php';
  include_once $homeDir.'/includes/abertura_regra.php';
  include_once $homeDir . '/includes/wo.php';
  include_once $homeDir . '/includes/task.php';
  include_once $homeDir . '/includes/questions.php'; // incluido para criar REQ
  include_once $homeDir . '/includes/uri.php';
  include_once $homeDir . '/includes/vip.php'; // incluido para Abertura de VIP
  include_once $homeDir . '/includes/configNuvemPublica.php';
  include_once $homeDir . '/includes/configTaskQuestions.php';
  include_once $homeDir . '/includes/configtask.php';
  include_once $homeDir . '/includes/ConfigVip.php';
  include_once $homeDir . '/includes/configwo.php';
  include_once $homeDir . '/includes/ConfigRecursoVM.php';
  include_once $homeDir . '/includes/woRecursosVM.php';
  include_once $homeDir.'/includes/banco_dados.php';
  include_once $homeDir.'/includes/testes.php';

  // configurando o content type de retorno
  //header('Content-Type: application/json; Charset=UTF-8');
  //header("Access-Control-Allow-Origin: *");

   // configurando o content type de retorno

    // Allow from any origin

    if (isset($_SERVER['HTTP_ORIGIN'])) {

      header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
      header('Access-Control-Allow-Credentials: true');
      header('Access-Control-Max-Age: 86400');    // cache for 1 day

  }

  // Access-Control headers are received during OPTIONS requests

  if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {

      if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
          // may also be using PUT, PATCH, HEAD etc
          header("Access-Control-Allow-Methods: GET, POST, DELETE, PUT, OPTIONS");
      if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
          header("Access-Control-Allow-Headers: {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");

      exit(0);

  }

  // capturando o método de request do cliente
  $metodo = $_SERVER['REQUEST_METHOD'];
  
  // capturando a query_string passada. ela indicará a ação a ser realizada
  parse_str($_SERVER['QUERY_STRING'], $parametros);
  $acao = $parametros['acao'];
  $header = getallheaders();
  $array_json = file_get_contents("php://input");

  if ($_SERVER['REQUEST_METHOD'] != 'OPTIONS' && isset($header['matricula']) && $acao != 'autenticarUsuario') {
    setLog($acao,$header['matricula'],$array_json, $metodo);
  }

  if ($_SERVER['REQUEST_METHOD'] != 'OPTIONS' && !isset($header['matricula']) && $acao != 'autenticarUsuario') {
    setLog($acao,'C000000',$array_json, $metodo);
  }

if(function_exists($acao)){
  switch ($metodo) {
    case 'PUT':
    case 'POST':
      print json_encode($acao($array_json,$header), JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    break;
    case 'DELETE':
    case 'GET':       
        print json_encode($acao($parametros,$header), JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);     
     break;
     
     
  }
}else{
  http_response_code(404);
  Utils::apiReturn("ERRO","Método não encontrado");
}
  exit();
?>
