<?php

class Plataforma extends Record {
    
    const TABLENAME = 'plataforma';
    
}