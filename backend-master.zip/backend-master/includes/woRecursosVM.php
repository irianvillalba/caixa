<?php
    
    ini_set("xdebug.var_display_max_children", -1);
    ini_set("xdebug.var_display_max_data", -1);
    ini_set("xdebug.var_display_max_depth", -1);

    class RecursosWO {

        public $token;
        public $req;
        private $ch;
        private $api;

        function __construct($ambiente) {
            $this->ch = curl_init();
            if (strtolower($ambiente) == 'hmp')
                $this->api = Config::API_HMP; 
            else
                $this->api = Config::API_PRD;
        }

        //step 0 - requisitar o token
        public function getToken($usuario, $senha) {

            $options = array(
                CURLOPT_URL =>              $this->api . Config::ENDPOINT_LOGIN,
                CURLOPT_POST =>             1,
                CURLOPT_POSTFIELDS =>       "username={$usuario}&password={$senha}",
                CURLOPT_RETURNTRANSFER=>    1,
                CURLOPT_HTTPHEADER =>       array(
                    "Content-Type:application/x-www-form-urlencoded",
                    'cache-control:no-cache')
            );

            curl_setopt_array($this->ch, $options);
            $result = curl_exec($this->ch);
            return $result;
        }

        //step 1 - registrar a capa da requisição
        public function getREQ() {

            $post = json_encode(array('values' => array(
                "GSC_ddlStatus" => "Processar",
                "GSC_chrTituloRequisicao" => "Multiplataforma - Realizar Aporte de Recurso",
                "GSC_chrIDInstancia" => "SRGAA5V0F9OUSAQ8Z3YJQ8BA19YGSO",
                "GSC_ddlStatusRequisicao" => "Draft",
                "GSC_chrSolicitadoPor" => "USR_CETADPOR1",
                "GSC_chrSolicitadoPara" => "USR_CETADPOR1",
                "GSC_ddlOrigem" => "{Web Services}"
                )));

            $options = array(
                CURLOPT_URL =>              $this->api . Config::ENDPOINT_REQ,
                CURLOPT_HEADER =>           false,
                CURLOPT_POST =>             1,
                CURLOPT_POSTFIELDS =>       $post,
                CURLOPT_RETURNTRANSFER=>    1,
                CURLOPT_HTTPHEADER =>       array(
                    "Content-Type:application/json",
                    'Authorization:AR-JWT ' . $this->token)
            );

            curl_setopt_array($this->ch, $options);
            $cabecalho = json_decode(curl_exec($this->ch));

            if (isset($cabecalho->values->GSC_chrIDRegistro))
                $result = $cabecalho->values->GSC_chrIDRegistro;
            else
                $result = $cabecalho;

            return $result;
        }

        //step 2 - responder questionário
        public function setQuestionario($req, $json) {
            $config = new ConfigRecursoVM();
            $this->req = $this->getREQ();
            
            $dados = json_decode($json);

            $dados->texto = "Prezado Analista, \n Foi aberta uma nova solicitação no Portal InfraFácil referente a Recursos de VM. \n Para concluir o presente atendimento, acesse a página do pedido para realizar sua análise e aprovação/reprovação. \n\nSistema: {$dados->sistema}\nAmbiente: {$dados->ambiente}\n\n URL pedido: https://infradevops.caixa/#/cadastros/admin-vm/{$dados->sistema}/{$dados->ambiente}";

            switch ($dados->ambiente) {
                case 'des':
                    $dados->ambiente = "Desenvolvimento (DES)";
                break;
                case 'tqs':
                    $dados->ambiente = "Testes (TQS)";
                break;
                case 'hmp':
                    $dados->ambiente = "Homologação (HMP)";
                break;
                case 'prd':
                    $dados->ambiente = "Produção (PRD)";
                break;                                                
            }

            foreach($config->questionario as $q) {
                
                $q['values']['GSC_chrIDRegistroPai'] = $req;
                
                if ($q['values']['GSC_chrPergunta'] == "Selecionar ambiente que o aporte de recurso será realizado")
                    $q['values']['GSC_chrResposta'] = $dados->ambiente;
                if ($q['values']['GSC_chrPergunta'] == "Informar os dados do IC que receberá o aporte")
                    $q['values']['GSC_chrResposta'] = "{$dados->sistema} - {$dados->ambiente}";
                if ($q['values']['GSC_chrPergunta'] == "Informar mais detalhes sobre o atendimento a ser realizado")
                    $q['values']['GSC_chrResposta'] = $dados->texto;                                                              
                if ($q['values']['GSC_chrPergunta'] == "Informar qual o recurso e quanto será aportado")
                    $q['values']['GSC_chrResposta'] = "VCPU: {$dados->cpu} | Memoria: {$dados->memoria} GB | Disco/OPT: {$dados->discoOpt} GB | Disco/LOG: {$dados->discoLog} GB";
                
                $questao = json_encode($q, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);

                $options = array(
                    CURLOPT_URL =>              $this->api . Config::ENDPOINT_QUESTIONARIO, 
                    CURLOPT_POST =>             1,   
                    CURLOPT_HEADER =>           false,
                    CURLOPT_CUSTOMREQUEST =>    "POST",
                    CURLOPT_HTTPHEADER =>       array("Accept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7"), 
                    CURLOPT_POSTFIELDS =>       $questao,
                    CURLOPT_RETURNTRANSFER=>    1,
                    CURLOPT_HTTPHEADER =>       array(
                        "Content-Type:application/json",
                        'Authorization:AR-JWT ' . $this->token)
                );

                curl_setopt_array($this->ch, $options);
                $result = curl_exec($this->ch);

            }

        }

        //step 3 - processar requisição
        public function processarREQ($req) {
            $post = json_encode(array('values' => array(
                "GSC_ddlStatus" => "Inicio"
                )));

            $options = array(
                CURLOPT_URL =>              $this->api . Config::ENDPOINT_PROCESSAREQ . "/{$req}",
                CURLOPT_HEADER =>           true,
                CURLOPT_CUSTOMREQUEST =>    "PUT",
                CURLOPT_POST =>             1,    
                CURLOPT_POSTFIELDS =>       $post,
                CURLOPT_RETURNTRANSFER=>    1,
                CURLOPT_HTTPHEADER =>       array(
                    "Content-Type:application/json",
                    'Authorization:AR-JWT ' . $this->token,
                    "X-AR-Client-Type:34")
            );

            curl_setopt_array($this->ch, $options);
            $result = json_decode(curl_exec($this->ch));

            return $result;
        }

        //step 4 - buscar requisição
        public function buscarREQ($req) {

            $options = array(
                CURLOPT_URL =>              $this->api . "/api/arsys/v1/entry/GSC:RF223:IntSRM_Definicao?q='GSC_chrIDRegistro'=\"{$req}\"&fields=values(GSC_chrIDRegistro,GSC_chrNumeroRequisicao,GSC_chrMensagem)",
                CURLOPT_HEADER =>           false,
                CURLOPT_CUSTOMREQUEST =>    "GET",
                CURLOPT_RETURNTRANSFER=>    1,
                CURLOPT_HTTPHEADER =>       array(
                    "Content-Type:application/json",
                    'Authorization:AR-JWT ' . $this->token)
            );

            curl_setopt_array($this->ch, $options);
            $result = json_decode(curl_exec($this->ch));

            return $result;
        }
        
        //step 5 - buscar WO
        public function buscarNumWO($req) {

            $options = array(
                CURLOPT_URL =>              $this->api . "/api/arsys/v1/entry/WOI:WorkOrderInterface?q='SRID'=\"{$req}\"",
                CURLOPT_HEADER =>           false,
                CURLOPT_CUSTOMREQUEST =>    "GET",
                CURLOPT_RETURNTRANSFER=>    1,
                CURLOPT_HTTPHEADER =>       array(
                    "Content-Type:application/json",
                    'Authorization:AR-JWT ' . $this->token)
            );
           
            curl_setopt_array($this->ch, $options);
            $result = json_decode(curl_exec($this->ch));

            return $result;

        }

        private function logout() {
            $options = array(
                CURLOPT_URL =>              $this->api . Config::ENDPOINT_LOGOUT,
                CURLOPT_POST =>             1,    
                CURLOPT_RETURNTRANSFER=>    1,
                CURLOPT_HTTPHEADER =>       array(
                    "cache-control:no-cache",
                    'Authorization:AR-JWT ' . $this->token)
            );

            curl_setopt_array($this->ch, $options);
            $result = curl_exec($this->ch);
        }

        function __destruct()
        {
            $this->logout();
            curl_close($this->ch);
        }
    }

    /*$array_json = json_decode(file_get_contents("php://input"), true);
    $wo = new WO("hmp");

    $wo->token = $wo->getToken("USR_CETADAUT2", "CETADAUT2");
    var_dump($wo->token);
    $req = $wo->getREQ();
    $dtE = date("Y-m-d") . "T19:00:00-03:00";
    $dtF = date("Y-m-d", strtotime('+1 day')) . "T19:00:00-03:00";
    $wo->setQuestionario($req, $dtE, $dtF);
    $wo->processarREQ($req);

    echo "<p>Buscar requisição</p>";
    $busca =  $wo->buscarREQ($req);
    echo $busca->entries[0]->values->GSC_chrNumeroRequisicao;
    
    echo "<p>Buscar WO</p>";
    sleep(5);
    $numwo = $wo->buscarNumWO("REQ000026231211");
    var_dump($numwo->entries[0]->values->{'Work Order ID'});*/

?>