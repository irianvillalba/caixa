<?php
class AlocaIpClient {
    public $token;    
    private $ch;
    private $endpoint;
    private $user;
    private $password;
    public $connected=false;
    function __construct(String $endpoint,String $user,String $password)
    {
        $this->ch = curl_init();
        $this->endpoint = str_replace("des.","",$endpoint);
        $this->user = $user;
        $this->password = $password;

    }

    function __destruct()
    {
        $this->logoff();
    }

    
    public function logoff():bool {
        try{
        $this->user = null;
        $this->password = null;    
        curl_close($this->ch);   
        return true;
    }catch(Exception $e){
        return false;
    }
    }

    public function postAlocaIp(String $parametros,String $descricao) {
        try{
            $p = json_decode($parametros, true);        
          $body = "";
          if(sandbox){
            $body = '{"id": "'.$this->user.'",
              "senha": "'.$this->password.'",
              "site":"CTC",
              "vertical": "Desenvolvimento",
              "ambiente": "Aplicacao",
              "unidade": "CETAD",
              "categoria":"Linux",
              "descricao":"'.$descricao.'",
              "red_num": "4995",
              "par":"S",
              "parCriado":"S"
             }';
          }else{
            $body = '{"id": "'.$this->user.'",
                "senha": "'.$this->password.'",
                "site":"'.$p['site'].'",
                "vertical": "'.$p['vertical'].'",
                "ambiente": "'.$p['ambiente'].'",
                "unidade": "'.$p['unidade'].'",
                "categoria": "'.$p['categoria'].'",
                "descricao":"'.$descricao.'",
                "red_num": "'.$p['red_num'].'",
                "par":"S",
                "parCriado":"S"
               }';
          }      
       
         
        $options = array(
            CURLOPT_URL => $this->endpoint."/Gerar",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 300,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => $body,
            CURLOPT_HTTPHEADER => array('Content-Type: application/json')
                );
                curl_setopt_array($this->ch, $options);
                $result = curl_exec($this->ch);
                if(curl_errno($this->ch)){
                    $status = curl_getinfo($this->ch,CURLINFO_HTTP_CODE);
                    return  json_decode('{"error":"Falha ao executar o comando.'.curl_error($this->ch).'"}');
                }   
                
                $status = curl_getinfo($this->ch,CURLINFO_HTTP_CODE);                
                switch ($status) {
                    case 200:                                       
                        $retorno = preg_replace('/[\x00-\x1F\x80-\xFF]/', '', $result);        
                        $json = json_decode($retorno);
                        if(isset($json->Gerar[1])){
                       return json_decode($retorno);
                        }else{
                            return json_decode('{"error":"'.$json->Gerar[0].'"}');   
                        }
                        break;                
                    default:
                        return json_decode('{"error":"Response code: '.$status.'"}');
                        break;
                }
        }catch(Exception $e){
            return json_decode('{"error":"'.$e->getMessage().'"}');
        }
        
    }

    
}