<?php
    class Config {

        //ENDPOINTS
        const ENDPOINT_REQ      		= "/api/arsys/v1/entry/GSC:RF223:IntSRM_Definicao?fields=values(GSC_chrIDRegistro,GSC_chrNumeroRequisicao)";
        const ENDPOINT_QUESTIONARIO     = "/api/arsys/v1/entry/GSC:RF224:IntSRM_Perguntas?fields=values(GSC_chrIDRegistro)";
        const ENDPOINT_PROCESSAREQ      = "/api/arsys/v1/entry/GSC:RF223:IntSRM_Definicao";
        const ENDPOINT_LOGIN 			= "/api/jwt/login";
        const ENDPOINT_LOGOUT 			= "/api/jwt/logout";
        const API_HMP                   = "http://scthmapllx0106.df.caixa:8008";
        const API_PRD                   = "http://cctdcapllx0388.df.caixa:8008";

        
        const ENDPOINT_ALLOCATION_CRQ 	= "/api/arsys/v1/entry/CHG:CFG%20Ticket%20Num%20Generator/";
        const ENDPOINT_GET_PEOPLE 		= "/api/arsys/v1/entry/CTM:People/";
        const ENDPOINT_CREATE_CHANGE 	= "/api/arsys/v1/entry/CHG:ChangeInterface_Create/";
        const ENDPOINT_QUERY_CHANGE 	= "/api/arsys/v1/entry/CHG:Infrastructure%20Change/";

        
        //QUESTIONARIO
        public $questionario = [
            'menu1' => array("values" => array(
            "GSC_chrIDRegistroPai" => "",
            "GSC_chrPergunta" => "Qual o tipo de serviço?",
            "GSC_chrResposta" => "Alterar configurações em firewall")),

            'menu2' => array("values" => array(
            "GSC_chrIDRegistroPai" => "",
            "GSC_chrPergunta" => "Selecione a atividade a ser executada",
            "GSC_chrResposta" => "Alterar objetos em firewall",
            "GSC_chrSubPergunta01" => "Qual o tipo de serviço?",
            "GSC_chrSelecao01" => "Alterar configurações em firewall")),
    
            'dtExecucao' => array("values" => array(
            "GSC_chrIDRegistroPai" => "",
            "GSC_chrPergunta" => "Data e Hora de execução",
            "GSC_chrResposta" => "2020-09-06T19:00:00-03:00",
            "GSC_chrSubPergunta01" => "Qual o tipo de serviço?",
            "GSC_chrSelecao01" => "Alterar configurações em firewall",
            "GSC_chrSubPergunta02" => "Selecione a atividade a ser executada",
            "GSC_chrSelecao02" => "Alterar objetos em firewall")),

            'dtFinal' => array("values" => array(
            "GSC_chrIDRegistroPai" => "",
            "GSC_chrPergunta" => "Prazo final do atendimento",
            "GSC_chrResposta" => "2020-09-07T19:00:00-03:00",
            "GSC_chrSubPergunta01" => "Qual o tipo de serviço?",
            "GSC_chrSelecao01" => "Alterar configurações em firewall",
            "GSC_chrSubPergunta02" => "Selecione a atividade a ser executada",
            "GSC_chrSelecao02" => "Alterar objetos em firewall")),

            'descricao' => array("values" => array(
            "GSC_chrIDRegistroPai" => "",
            "GSC_chrPergunta" => "Descrição da solicitação",
            "GSC_chrResposta" => "À\nCETAD/REDES\n\n1. Solicitamos incluir o IP: xxx.xxx.xxx.xxx no objeto de firewall network: OBJETO_TESTE_SERVIDOR.\n\nAt.te\n\nCETAD36"))];
    }
?>