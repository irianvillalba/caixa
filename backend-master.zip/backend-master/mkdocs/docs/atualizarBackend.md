Atualiza as informaçoes de um Backend previamente cadastrado.

|MÉTODO|CHAMADA|
|:----------|:-----------|
|POST|https://infra.devops.caixa/api/api.php?acao=atualizarBackend|

-----

#### Parâmetros obrigatórios

|PARÂMETRO|DESCRIÇÃO|
|:----------|:-----------|
|**nome**|Nome do backend a ser alterado, conforme cadastro na base.|
|**ambiente**|Ambiente do backend.|
|**ip**|IP do backend.|
|**porta**|Porta do backend.|
|**descricao**|Descrição do backend.|
|**tipo**|Tipo do backend.|
|**servidores**|Servidores do backend.|

-----

#### Exemplo de JSON a ser usado na chamada

```json
		{
			"nome": "mq01",
			"ambiente": "des",
			"ip": "10.128.98.27",
			"porta": "9999",
			"descricao": "teste de alteração",
			"tipo": "mq",
			"servidores": "servidor 1"
		}
```

-----

#### Retornos esperados

- No caso de Erros: `"O backend com nome xxx não foi encontrado."`
- No caso de sucesso: `"Informacoes atualizadas para o backend orades02."`