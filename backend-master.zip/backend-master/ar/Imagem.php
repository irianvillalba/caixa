<?php

class Imagem extends Record {
    
    const TABLENAME = 'imagens';
    
}