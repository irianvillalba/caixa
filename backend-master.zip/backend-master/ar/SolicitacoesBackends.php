<?php

class SolicitacoesTipoBackends extends Record {
    
    const TABLENAME = 'solicitacoes_tipo_backends';
    
}