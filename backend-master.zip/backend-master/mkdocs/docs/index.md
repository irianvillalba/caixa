## Sobre a API

Todo o Portal https://infra.devops.caixa está construído sobre um conjunto de APIs.

As APIs ajudam a facilitar a integração com as inúmeras automações utilizadas no âmbito das Esteiras Ágeis. As APIs fornecem os alicerces para o Portal, mas podem ser utilizadas em um escopo mais amplo, fornecendo outras integrações, caso necessário. A infraestrutura é modular, favorecendo à adição de novas funcionalidades.

-----

## Endpoints Disponíveis

A API está disponibilizada em https://infra.devops.caixa/api/.

As seguintes ações estão disponíveis na `API`:

|AÇÂO|FINALIDADE|
|:----------:|:-----------:|
|autenticarUsuario|Autentica os usuários de acordo com as credenciais utilizadas no domínio corpcaixa.|
|cadastrarBackend|Realiza o cadastramento de um novo backend na Base de dados.|
|atualizarBackend|Possibilita a alteração de dados de um backend previamente cadastrado.|
|removerBackend|Remove um backend previmente cadastrado.|
|relacionarBackend|Possibilita relacionar um backend previamente cadastrado com uma solicitação de infraestrutura.|
|solicitarInfraestrutura|Utilizada para solicitar a criação de novas infraestruturas na esteira.|
|cadastrarServidores|Relaciona os servidores criados com uma solicitação de infraestrutura.|
|solicitarBalanceamento|Realiza a interação com as automações de criação de balanceamento.|
|listarBackend|Lista os backends cadastrados.|
|listarTiposBackend|Lista os tipos de backends cadastrados.|
|listarRelacionamentosBackendPendentes|Exibe as solicitações pendentes de alocação de backend.|
|listarSolicitacoes|Exibe as solicitações realizadas.|

-----

## Fluxos de interação/utilização das APIs

Até o momento, estão previstos 3 fluxos de interação com o portal: Solicitação de uma nova infraestrutura, Manutenção de Backends e Relacionar Backends.

### Manutenção de Backends

O fluxo de **Manutenção de Backends** deve ser realizado pelas equipes de suporte e consiste na gestão do ciclo de vida dos backends, com ações visando ao cadastro, atualização e remoção de backends. É o primeiro fluxo a ser tratado, pos gerará insumos utilizados em todos os outros fluxos.

Endpoints relacionados:

  - cadastrarBackend
  - atualizarBackend
  - removerBackend
  
### Solicitação de nova Infraestrutura

O fluxo de **Solicitação de nova Infraestrutura** está previsto para ser utilizado pelas equipes de desenvolvimento e consiste nos passos necessários para descrever que tipo de infraestrutura será necessária à entrega do sistema.

A **Solicitação de nova Infraestrutura** resulta em uma **Solicitação de Infraestrutura**.

Endpoints relacionados:

  - solicitarInfraestrutura
  
### Relacionar Backends

O fluxo de **Relacionar Backends** deverá ser utilizado pelas equipes que operacionalizam os ambientes nos quais a infraestrutura será criada. Consiste em relacionar um tipo de *backend*, conforme gerado na **Solicitação de Infraestrutura** com um backend previamente cadastrado através do fluxo de **Manutenção de Backends**.

Endpoints relacionados:

  - relacionarBackend  