<?php
    $homeDir = dirname(__DIR__, 1);
    include_once $homeDir.'/config/config.inc.php';
    require_once "config.php";
    ini_set("xdebug.var_display_max_children", -1);
    ini_set("xdebug.var_display_max_data", -1);
    ini_set("xdebug.var_display_max_depth", -1);
    
    class Mudanca {

        public $token;
        public $crq;
        private $ch;
        private $api;

        function __construct($ambiente) {
            $this->ch = curl_init();
            // if (strtolower($ambiente) == 'hmp')
            //     $this->api = Config::API_HMP; 
            // else
                $this->api = gsc_endpoint;
        }

        public function getToken($usuario, $senha) {

            $options = array(
                CURLOPT_URL =>              $this->api . Config::ENDPOINT_LOGIN,
                CURLOPT_POST =>             1,
                CURLOPT_POSTFIELDS =>       "username={$usuario}&password={$senha}",
                CURLOPT_RETURNTRANSFER=>    1,
                CURLOPT_HTTPHEADER =>       array(
                    "Content-Type:application/x-www-form-urlencoded",
                    'cache-control:no-cache')
            );

            curl_setopt_array($this->ch, $options);
            $result = curl_exec($this->ch);
            return $result;
        }

        public function getCRQ() {
            $options = array(
                CURLOPT_URL =>              $this->api . Config::ENDPOINT_ALLOCATION_CRQ,
                CURLOPT_HEADER =>           true,
                CURLOPT_POST =>             1,
                CURLOPT_POSTFIELDS =>       '{"values":{"Short Description":"Generate Change ID"}}',
                CURLOPT_RETURNTRANSFER=>    1,
                CURLOPT_HTTPHEADER =>       array(
                    "Content-Type:application/json",
                    'Authorization:AR-JWT ' . $this->token)
            );

            curl_setopt_array($this->ch, $options);
            $cabecalho = curl_exec($this->ch);

            $pos = strpos($cabecalho, 'Generator/');
            $result = substr($cabecalho, $pos + 10, 15);

            return $result;
        }

        public function setQuestionario($ambiente) {
            $config = new Config();
            $this->crq = $this->getCRQ();            
            for ($x = 1; $x <= count($config->questionario); $x++) {
                $config->questionario["questao{$x}"]["Infrastructure Change ID"] = $this->crq;
                if ($ambiente == 'prd')
                    $config->questionario["questao{$x}"]["Template Instance Id"] = $config->templatePRD[$x-1];
                else
                    $config->questionario["questao{$x}"]["Template Instance Id"] = $config->templateHMP[$x-1];

                $questao = '{"values":' .json_encode($config->questionario["questao{$x}"]). '}';
                $options = array(
                    CURLOPT_URL =>              $this->api . Config::ENDPOINT_FETCH_RISKS,
                    CURLOPT_POST =>             1,    
                    CURLOPT_POSTFIELDS =>       $questao,
                    CURLOPT_RETURNTRANSFER=>    1,
                    CURLOPT_HTTPHEADER =>       array(
                        "Content-Type:application/json",
                        'Authorization:AR-JWT ' . $this->token)
                );

                curl_setopt_array($this->ch, $options);
                $result = curl_exec($this->ch);
            }

            return $result;
        }

        public function setCriarMudanca($valores) {

            $body = array( 'values' => array(
                "z1D_Action" =>                 "CREATE",
                "Infrastructure Change Id" =>   $this->crq,
                "ASCPY" =>                      "CAIXA",
                "ASORG" =>                      "CETAD",
                "ASGRP" =>                      "Suporte a Esteiras Ágeis",
                "Description" =>                $valores["Description"],
                "Detailed Description" =>       $valores["Detailed Description"],
                "Change Timing" =>              "Padrão DevOps",
                "Reason For Change" =>          "New Functionality",
                "Change Target Date" =>         $valores["Change Target Date"],
                "Company3" =>                   "CAIXA",
                "Support Organization" =>       "CETAD",
                "Support Group Name"=>          "Gestão de Mudanças",
                "Environment" =>                $valores["Environment"],
                "Location Company" =>           "CAIXA",
                "Categorization Tier 1" =>      "Criar",
                "Categorization Tier 2" =>      "Ambiente",
                "Product Cat Tier 1(2)" =>      "Hardware",
                "Product Cat Tier 2 (2)" =>     "Servidor Lógico",
                "Product Cat Tier 3 (2)" =>     "Baixa Plataforma",
                "CI Name" =>                    $valores["CI Name"],
                "Scheduled Start Date" =>       $valores["Scheduled Start Date"],
                "Scheduled End Date" =>         $valores["Scheduled End Date"],
                "Actual Start Date" =>          $valores["Actual Start Date" ],
                "Actual End Date" =>            $valores["Actual End Date"],
                "GSC_chrGestorNome" =>          "Victor Thiago Batista da Silva",
                "GSC_chrGestorTelefone" =>      "(61) 1111-1111",
                "GSC_chrTecnicoNome" =>         "Técnico Nome",
                "GSC_chrTecnicoTelefone" =>     "(61) 2222-2222",
                "Last Name" =>                  "CETADAUT1"
            ));

            $b = json_encode($body, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);

            $options = array(
                CURLOPT_URL =>              $this->api . Config::ENDPOINT_CREATE_CHANGE,
                CURLOPT_POST =>             1,    
                CURLOPT_POSTFIELDS =>       $b,
                CURLOPT_RETURNTRANSFER=>    1,
                CURLOPT_HEADER =>           1,
                CURLOPT_HTTPHEADER =>       array(
                    "Content-Type:application/json",
                    'Authorization:AR-JWT ' . $this->token)
            );

            curl_setopt_array($this->ch, $options);
            $result = curl_exec($this->ch);

            $data = explode("\n", $result);
        
            $result = [
                'crq'   => $this->crq,
                'status'=> trim(substr($data[2], 8, 4)),
                'erro'  => trim($data[9])
            ];

            return json_encode($result, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        }

        private function logout() {
            $options = array(
                CURLOPT_URL =>              $this->api . Config::ENDPOINT_LOGOUT,
                CURLOPT_POST =>             1,    
                CURLOPT_RETURNTRANSFER=>    1,
                CURLOPT_HTTPHEADER =>       array(
                    "cache-control:no-cache",
                    'Authorization:AR-JWT ' . $this->token)
            );

            curl_setopt_array($this->ch, $options);
            $result = curl_exec($this->ch);
        }

        function __destruct()
        {
            $this->logout();
            curl_close($this->ch);
        }
    }
    $array_json = json_decode(file_get_contents("php://input"), true);
    $mudanca = new Mudanca($array_json['ambiente']);
    $config = new Config();
    

    $mudanca->token = $mudanca->getToken($array_json['user'], $array_json['password']);
    $mudanca->setQuestionario($array_json['ambiente']);
    $retorno = $mudanca->setCriarMudanca($array_json);
    echo $retorno;

?>