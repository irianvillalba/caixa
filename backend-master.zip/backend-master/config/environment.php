<?php

$homeDir = dirname(__DIR__, 1);

//inivializando as variaveis de ambinete
if(!isset($_ENV['DOCUMENTROOT'])){
    if (file_exists($homeDir.'/config/local.env')) {
        $config = parse_ini_file($homeDir.'/config/local.env');
        $_ENV = $config;
    } else {
        http_response_code(500);
        throw new Exception("Arquivo '$name' nao encontrado");
    }
}