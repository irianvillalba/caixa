<?php

//cadastrar solicitação de recursos (method POST)
function solicitarRecursoVM($json)
{
  $dados = $json;
  $json = json_decode($json, true);
  Transaction::open('database');
  $db = Transaction::get();
  try {

    $dt_inclusao = date('Y-m-d H:i:s');

    $db->exec("insert into recursos_vm 
            (cpu, memoria, disco_opt, disco_log, qtd_vm, justificativa, opcoes, status, matricula, sistema, ambiente, dt_inclusao) values 
            ({$json['cpu']},{$json['memoria']},{$json['discoOpt']},{$json['discoLog']},{$json['vm']},'{$json['justificativa']}', 
            '{$json['opcao']}', 'solicitado', '{$json['matricula']}', '{$json['sistema']}', '{$json['ambiente']}', '{$dt_inclusao}')");

    $solicitacao = $db->query("select max(id_recursos) as id from recursos_vm", PDO::FETCH_ASSOC)->fetch();

    $woResponse = recursoWO($dados, $solicitacao);

    $response = [
      'text' => "Recursos solicitados com sucesso.",
      'wo' => isset($woResponse['wo']) ? $woResponse['wo'] : ''
    ];

    http_response_code(201);
  } catch (Exception $e) {
    $response = [
      'text' => "Erro na solicitação de recursos. Descricao: {$e->getMessage()}"
    ];
  } finally {
    Transaction::close();
  }

  return ($response);
}

function editarRecursoVM($json)
{
  $json = json_decode($json, true);

  Transaction::open('database');
  $db = Transaction::get();
  try {
    $dt_alteracao = date('Y-m-d H:i:s');

    $db->exec("update recursos_vm SET cpu = {$json['cpu']}, memoria = {$json['memoria']}, 
            disco_opt = {$json['discoOpt']}, disco_log = {$json['discoLog']}, qtd_vm = {$json['vm']}, justificativa_status = '{$json['justificativa_status']}',
            dt_alteracao = '{$dt_alteracao}' where id_recursos = {$json['id_recurso']}");

    $mensagem = "Solicitado com sucesso.";
    http_response_code(201);
  } catch (Exception $e) {
    $mensagem = "Descricao: {$e->getMessage()}";
  } finally {
    Transaction::close();
  }
  return ($mensagem);
}

//mudança de status da solicitacao (method POST)
function mudancaStatus($json)
{
  $json = json_decode($json, true);

  Transaction::open('database');
  $db = Transaction::get();
  try {

    $dt_alteracao = date('Y-m-d H:i:s');
    $sql = "update recursos_vm SET status = '{$json['status']}', justificativa_status = '{$json['justificativa_status']}',
          dt_alteracao='{$dt_alteracao}' , matricula_aprovacao='{$json['matricula_aprovacao']}'
          where id_recursos = {$json['id_recurso']}";

    $db->exec($sql);

    if ($json['status'] == 'executado') {
      $campos = "";

      $sql = "select cpu, memoria, disco_opt, disco_log, sistema, ambiente from recursos_vm where id_recursos = {$json['id_recurso']}";
      $alteracao = $db->query($sql, PDO::FETCH_ASSOC)->fetchAll();

      if ($alteracao[0]['cpu'] > 0)
        $campos = "cpu = {$alteracao[0]['cpu']},";
      if ($alteracao[0]['memoria'] > 0)
        $campos .= "memoria = {$alteracao[0]['memoria']},";
      if ($alteracao[0]['disco_opt'] > 0)
        $campos .= "disco_opt = {$alteracao[0]['disco_opt']},";
      if ($alteracao[0]['disco_log'] > 0)
        $campos .= "disco_log = {$alteracao[0]['disco_log']},";
      $campos = rtrim($campos, ",");

      $db->exec("update servidores SET $campos
            where sistema = '{$alteracao[0]['sistema']}' and ambiente= '{$alteracao[0]['ambiente']}'");
    }

    $mensagem = "Status alterado com sucesso.";
    http_response_code(201);
  } catch (Exception $e) {
    $mensagem = "Descricao: {$e->getMessage()}";
  } finally {
    Transaction::close();
  }
  return ($mensagem);
}

//retorna  a lista de solicitacoes (method GET)
function listaSolicitacao()
{
  try {
    Transaction::open('database');
    $db = Transaction::get();

    $sql = "select * from recursos_vm order by dt_inclusao";

    $registros = $db->query($sql, PDO::FETCH_ASSOC)->fetchAll();

    return $registros;
  } catch (Exception $e) {
    $array = [];
    $array['erro'] = "erro execucao da query";
    Transaction::close();
    return $array;
  } finally {
    Transaction::close();
  }
}

//retorna a lista de solicitacoes por sistema/ambiente (method GET)
function listaSolicitacaoSistema($json)
{
  try {
    Transaction::open('database');
    $db = Transaction::get();

    $sql = "select * from recursos_vm where sistema ilike '%{$json['sistema']}%' and ambiente = '{$json['ambiente']}' order by dt_inclusao desc, status";

    $registros = $db->query($sql, PDO::FETCH_ASSOC)->fetchAll();

    return $registros;
  } catch (Exception $e) {
    $array = [];
    $array['erro'] = "erro execucao da query";
    Transaction::close();
    return $array;
  } finally {
    Transaction::close();
  }
}

//retorna a solicitação aprovada por sistema/ambiente (method GET)
function listaAprovadoSistema($json)
{
  try {
    Transaction::open('database');
    $db = Transaction::get();

    $sql = "select id_recursos, sistema, ambiente, cpu tf_var_num_cpus, memoria tf_var_num_mem, qtd_vm tf_var_quant, disco_opt tf_var_vm_opt_size, disco_log tf_var_vm_log_size  from recursos_vm 
      where sistema = '{$json['sistema']}' and ambiente = '{$json['ambiente']}' and status = 'aprovado'";

    $registros = $db->query($sql, PDO::FETCH_ASSOC)->fetchAll();

    return $registros;
  } catch (Exception $e) {
    $array = [];
    $array['erro'] = "erro execucao da query";
    Transaction::close();
    return $array;
  } finally {
    Transaction::close();
  }
}

function recursoWO($json, $solicitacao)
{
  try {
    Transaction::open('database');
    $db = Transaction::get();
    $wo = new RecursosWO("prd");

    //GERANDO WO
    //$wo->token = $wo->getToken("USR_CETADPOR1", "CETADPOR1");
    $wo->token = $wo->getToken("USR_CETADAUT2", "CETADAUT2");
    $req = $wo->getREQ();

    $wo->setQuestionario($req, $json);
    $wo->processarREQ($req);
    $busca =  $wo->buscarREQ($req);
    sleep(10);

    $numwo = $wo->buscarNumWO($busca->entries[0]->values->GSC_chrNumeroRequisicao);

    //RETORNANDO WO  e salvado no banco de dados
    $retorno = [
      "requisicao" => $busca->entries[0]->values->GSC_chrNumeroRequisicao,
      "wo" => $numwo->entries[0]->values->{'Work Order ID'}
    ];

    //atualiza a solitação de recursos de VM

    $db->exec("UPDATE recursos_vm SET wo_req='{$retorno['wo']}' WHERE id_recursos={$solicitacao['id']}");

    $response = [
      'text' => "enviado com sucesso",
      'wo' => $retorno['wo']
    ];

    return $response;
  } catch (Exception $e) {
    $response = [
      'text' => "erro execucao da query",
      'error' => $e->getMessage()
    ];

    Transaction::close();

    return $response;
  } finally {
    Transaction::close();
  }
}
