<?php
  
$homeDir = dirname(__DIR__, 2);
include_once $homeDir.'/api/util/SipgcClient.php';
include_once $homeDir.'/api/util/DNSClient.php';
include_once $homeDir.'/api/util/GSCClient.php';
include_once $homeDir.'/api/util/AlocaIpClient.php';
include_once $homeDir.'/api/util/Utils.php';
include_once $homeDir.'/api/util/Logger.php';
include_once $homeDir.'/api/util/Configuration.php';
include_once $homeDir.'/api/db/Expression.php';
include_once $homeDir.'/api/db/Filter.php';
include_once $homeDir.'/api/db/Criteria.php';
include_once $homeDir.'/api/db/Repository.php';
include_once $homeDir.'/api/db/Record.php';
include_once $homeDir.'/api/db/Connection.php';
include_once $homeDir.'/api/db/Transaction.php';
include_once $homeDir.'/api/util/PhpMail.php';
include_once $homeDir.'/api/Autentica.php';

include_once $homeDir.'/ar/Backend.php';
include_once $homeDir.'/ar/Plataforma.php';
include_once $homeDir.'/ar/Tipo.php';
include_once $homeDir.'/ar/Usuario.php';
include_once $homeDir.'/ar/Solicitacao.php';
include_once $homeDir.'/ar/SolicitacoesBackends.php';
include_once $homeDir.'/ar/Servidor.php';
include_once $homeDir.'/ar/Cota.php';
include_once $homeDir.'/ar/Imagem.php';
include_once $homeDir.'/ar/ArmazenamentoEntity.php';
