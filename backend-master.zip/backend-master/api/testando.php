<?php

$var = "\"SERVIDOR\"";
echo $var;

$novo = str_replace('"', "", $var);

echo $novo;

?>