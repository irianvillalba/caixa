<?php

class Tipo extends Record {
    
    const TABLENAME = 'tipo_backend';
    
}