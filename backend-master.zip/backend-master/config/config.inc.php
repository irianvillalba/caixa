<?php

$homeDir = dirname(__DIR__, 1);


define("sandbox",$_ENV['SANDBOX']);
//regas
define('endpoint_regrasbr', $_ENV['REGRAS_ENDPOINT']);
define('usuario_regrasbr',$_ENV['REGRAS_USER']);
define('senha_usuario_regrasbr',$_ENV['REGRAS_PASS']);

//alocaip
define('endpoint_mudanca',$_ENV['ALOCA_IP_ENDPOINT']);   
define('user_mudanca',$_ENV['ALOCA_IP_USER']);
define('password_mudanca',$_ENV['ALOCA_IP_PASS']);
define('usuario_mudanca',$_ENV['ALOCA_IP_USER2']);
define('senha_usuario_mudanca',$_ENV['ALOCA_IP_PASS2']);
define('endpoint_solicitar_dns', $_ENV['AUTO_SERVICO_ENDPOINT']);

//gsc
define('gsc_endpoint',$_ENV['GSC_ENDPOINT']);
define('gsc_user',$_ENV['GSC_USER']);
define('gsc_password',$_ENV['GSC_PASS']);
define('gsc_instance_id_vip',$_ENV['GSC_INSTANCE_ID_VIP']);
define('gsc_instance_id_dns',$_ENV['GSC_INSTANCE_ID_DNS']);
define('gsc_instance_id_nuvem_publica',$_ENV['GSC_INSTANCE_ID_NUVEM_PUBLICA']);
define('gsc_instance_id_armazenamento',$_ENV['GSC_INSTANCE_ID_ARMAZENAMENTO']);
define('gsc_instance_id_banco_dados',$_ENV['GSC_INSTANCE_ID_BANCO_DE_DADOS']);

//sipgc
define('endpoint_sipgc',$_ENV['SIPGC_ENDPOINT']);
define('endpoint_sipgc_siapp',$_ENV['SIPGC_SIAPP_ENDPOINT']);
define('dns_endpoint',$_ENV['DNS_ENDPOINT']);

//ldap
define('ip_ldap',$_ENV['LDAP_HOST']);
define('porta_ldap',$_ENV['LDAP_PORT']);

//db
define('db_type',$_ENV['POSTGRESDB01_DBTYPE']);
define('db_host',$_ENV['POSTGRESDB01_DBHOST']);
define('db_name',$_ENV['POSTGRESDB01_DBNAME']);
define('db_port',$_ENV['POSTGRESDB01_DBPORT']);
define('db_user',$_ENV['POSTGRESDB01_DBUSER']);
define('db_pass',$_ENV['POSTGRESDB01_DBPASS']);



?>