<?php
print_r(getenv());
