Atualiza as informaçoes de um Backend previamente cadastrado.

|MÉTODO|CHAMADA|
|:----------|:-----------|
|POST|https://infra.devops.caixa/api/api.php?acao=removerBackend|

-----

#### Parâmetros obrigatórios

|PARÂMETRO|DESCRIÇÃO|
|:----------|:-----------|
|**nome**|Nome do backend a ser removido, conforme cadastro na base.|

-----

#### Exemplo de JSON a ser usado na chamada

```json
		{
			"nome": "mq01"
		}
```

-----

#### Retornos esperados

- No caso de Erros: `"O backend com nome mq07 não foi encontrado."."`
- No caso de sucesso: `"O backend mq06 foi desabilitado."`