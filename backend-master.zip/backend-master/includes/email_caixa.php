<?php
include_once $homeDir . '/includes/PHPMailer/src/Exception.php';
include_once $homeDir . '/includes/PHPMailer/src/PHPMailer.php';
include_once $homeDir . '/includes/PHPMailer/src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

function enviarEmail($json)
{
    $json = json_decode($json);
    $mail = new PHPMailer(true);                              // Passing `true` enables exceptions
    try {
        //Server settings
        $mail->SMTPDebug = 2;
        $mail->CharSet = "UTF-8";
        $mail->isSMTP();                                      // Set mailer to use SMTP
        $mail->Host = 'sistemas.correiolivre.caixa';  // Specify main and backup SMTP servers
        //$mail->SMTPAuth = true;                               // Enable SMTP authentication
        //$mail->Username = 'user@example.com';                 // SMTP username
        //$mail->Password = 'secret';                           // SMTP password
        //$mail->SMTPSecure = 'tls';                            // Enable TLS encryption, `ssl` also accepted
        $mail->Port = 25;                                    // TCP port to connect to

        //Recipients
        $mail->setFrom('cesti364@caixa.gov.br', 'InfraFácil');
        $mail->addAddress('cesti11@caixa.gov.br');               // Name is optional

        //Content
        $mail->isHTML(true);                                  // Set email format to HTML
        $mail->Subject = 'Solicitação de recursos para VM';

        $wo = isset($json->wo) ? "<p>WO: {$json->wo}</p>" : '';
        $mail->Body    = "<p>À</p>
        <p>CESTI11</p>
        <p>Solicitamos a analise da solicitação de recursos para VM no portal InfraFácil clicando no link: https://infradevops.caixa/#/cadastros/admin-vm/{$json->sistema}/{$json->ambiente}</p>
        {$wo}
        
        <p>Mensagem automática do portal InfraFácil.</p>
        ";

        $mail->send();
        echo 'Mensagem enviada com sucesso';
    } catch (Exception $e) {
        echo 'ocorreu um erro ao enviar a mensagem ', $mail->ErrorInfo;
    }
}

function enviarEmailBackend($json)
{
    $json = json_decode($json);

    $mail = new PHPMailer(true);                              // Passing `true` enables exceptions
    try {
        //Server settings
        $mail->SMTPDebug = 2;                                 // Enable verbose debug output
        $mail->CharSet = "UTF-8";
        $mail->isSMTP();                                      // Set mailer to use SMTP
        $mail->Host = 'sistemas.correiolivre.caixa';  // Specify main and backup SMTP servers
        $mail->Port = 25;                                    // TCP port to connect to

        //Recipients
        $mail->setFrom('cesti364@caixa.gov.br', 'InfraFácil');
        $mail->addAddress('cesti364@caixa.gov.br');               // Name is optional

        //Content
        $mail->isHTML(true);                                  // Set email format to HTML
        $mail->Subject = 'Portal InfraFacil - Novo Backend Cadastrado';
        $mail->Body    = "
        <p>Foi realizado um novo cadastro de Backend no portal InfraFacil.</p>
        <p>Backend: {$json->nome}</p>
        <p>Ambiente: {$json->ambiente}</p>
        <p>Usuário solicitante: {$json->usuario}</p>
        <p>Matricula: {$json->matricula}</p>
        <p>https://infradevops.caixa/#/cadastros/backend-restrito</p>       
        <p>Mensagem automática do portal InfraFácil.</p>
        ";

        $mail->send();
        echo 'Mensagem enviada com sucesso';
    } catch (Exception $e) {
        echo 'ocorreu um erro ao enviar a mensagem ', $mail->ErrorInfo;
    }
}

function enviarEmailBackendStatus($json)
{
    $json = json_decode($json);

    $mail = new PHPMailer(true);                              // Passing `true` enables exceptions
    try {
        //Server settings
        $mail->SMTPDebug = 2;
        $mail->CharSet = "UTF-8";                            // Enable verbose debug output
        $mail->isSMTP();                                      // Set mailer to use SMTP
        $mail->Host = 'sistemas.correiolivre.caixa';  // Specify main and backup SMTP servers
        $mail->Port = 25;                                    // TCP port to connect to

        //Recipients
        $mail->setFrom('cesti364@caixa.gov.br', 'InfraFácil');
        $mail->addAddress("{$json->email}@caixa.gov.br");              // Name is optional

        //Content
        $mail->isHTML(true);                                  // Set email format to HTML
        $mail->Subject = 'Portal InfraFacil - Novo Backend Cadastrado';
        $mail->Body    = "
        <p>O Backend  {$json->backend} solicitado para cadastro foi alterado para o status {$json->status} no portal InfraFacil.</p>
        <p>Se o Status foi alterado para desativado, pesquise no portal pelo IP que provavelmente ele já esta cadastrado!</p>
        <p>Para pesquisar acesse: https://infradevops.caixa/#/cadastros/backend</p>       
        <p>Mensagem automática do portal InfraFácil.</p>
        ";

        $mail->send();
        echo 'Mensagem enviada com sucesso';
    } catch (Exception $e) {
        echo 'ocorreu um erro ao enviar a mensagem ', $mail->ErrorInfo;
    }
}
