<?php

class ArmazenamentoEntity extends Record {
    
    const TABLENAME = 'armazenamento';
    
}