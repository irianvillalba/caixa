<?php

ini_set("xdebug.var_display_max_children", -1);
ini_set("xdebug.var_display_max_data", -1);
ini_set("xdebug.var_display_max_depth", -1);

class NuvemPublica
{
    public function criarRequisicaoNuvem($descricao , $ambienteAbrv) {
        $retorno = [];
     try{
      $gsc = new GSCClient(gsc_endpoint,gsc_user,gsc_password);
     
      if ($gsc->connected == false) {
        $retorno = [
          "title" => 'ERRO_API',
          "mensagem" => 'Erro na comunicação com a API do GSC'
        ];
        return;
      }

      $capa = $gsc->recPostDefinitition('CETAD - Nuvem Publica',gsc_instance_id_nuvem_publica,gsc_user,gsc_user);
      if (isset($capa->error)) {
        $retorno = [
          "title" => 'ERRO_API',
          "mensagem" => $capa->error
        ];
        return;
      }
      $registerId = $capa->values->GSC_chrIDRegistro;

      
      $dtF = date("Y-m-d", strtotime('+1 day')) . "T19:00:00-03:00";

      
        $config = new ConfigNuvemPublca();        
        foreach ($config->questionario as $q) {

            $q['values']['GSC_chrIDRegistroPai'] = $registerId;
            if ($q['values']['GSC_chrPergunta'] == "Ambiente / Subscrição")
                $q['values']['GSC_chrResposta'] = $ambienteAbrv;
            if ($q['values']['GSC_chrPergunta'] == "Data esperada para atendimento")
                $q['values']['GSC_chrResposta'] = $dtF;
            if ($q['values']['GSC_chrPergunta'] == "Descrição da solicitação")
                $q['values']['GSC_chrResposta'] = $descricao;
                $gsc->recPostQuestion($registerId,$q);
                
        }  
    

    //atualizando a requisição
    $gsc->recPutProcess($registerId,"Inicio");    

    $requestNumber =  $gsc->recGetRequestNumber($registerId);

      if ($requestNumber->entries[0]->values->GSC_chrNumeroRequisicao == 'ERRO') {

        $retorno = [
          "title" => 'ERRO_API',
          "mensagem" => $requestNumber->entries[0]->values->GSC_chrMensagem
        ];
        return;
      }

      $numreq = $requestNumber->entries[0]->values->GSC_chrNumeroRequisicao;
      //RETORNANDO REQ  
      $retorno = [
        "title" => 'OK',
        "requisicao" => $requestNumber->entries[0]->values->GSC_chrNumeroRequisicao,
        "mensagem" => $requestNumber->entries[0]->values->GSC_chrMensagem,
        "registroPai" => $requestNumber->entries[0]->values->GSC_chrIDRegistro
      ];
    } catch (\Exception $e) {
        $retorno = [
          "title" => 'ERRO',
          "mensagem" => $e->getMessage()
        ];
      } finally {   
        $gsc = null;     
        return  $retorno;
      }
    }
    
  
}
