<?php
class DNSClient {
    public $token;    
    private $ch;
    private $endpoint;
    public $connected=false;
    function __construct(String $endpoint)
    {
        $this->ch = curl_init();
        $this->endpoint = $endpoint;
        
    }

    function __destruct()
    {
        curl_close($this->ch);
    }

    

    public function consultaDisponibilidade(String $dns) {
        try{
        $options = array(
                    CURLOPT_URL =>  $this->endpoint . "/query_dns?domain=".$dns,
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_ENCODING => "",
                    CURLOPT_MAXREDIRS => 10,
                    CURLOPT_TIMEOUT => 600,
                    CURLOPT_FOLLOWLOCATION => true,
                    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                    CURLOPT_CUSTOMREQUEST => "GET",
                    CURLOPT_HTTPHEADER =>       array(
                        "Content-Type:application/json"                        
                    )
                );
                curl_setopt_array($this->ch, $options);
                $result = curl_exec($this->ch);
                if(curl_errno($this->ch)){
                    return  json_decode('{"error":"Falha ao consultar disponibilidade do fqdn"}');
                }   
                
                $status = curl_getinfo($this->ch,CURLINFO_HTTP_CODE);
                switch ($status) {
                    case 200:                       
                       return json_decode($result);
                        break;  
                        
                        
                        case 400:                       
                            return json_decode($result);
                             break;  
                    default:
                        return json_decode('{"error":"Falha ao consultar disponibilidade do fqdn"}');
                        break;
                }
        }catch(Exception $e){
            return json_decode('{"error":"'.$e->getMessage().'"}');
        }
        
    }

    public function registraRotaOKD(String $namespace,String $service,String $dominio,String $site) {
        try{
           
        $options = array(
                    CURLOPT_URL =>  $this->endpoint . "/oc-route?namespace=".$namespace."&service=".$service."&dominio=".$dominio."&site=".$site,
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_ENCODING => "",
                    CURLOPT_MAXREDIRS => 10,
                    CURLOPT_TIMEOUT => 600,
                    CURLOPT_FOLLOWLOCATION => true,
                    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                    CURLOPT_CUSTOMREQUEST => "GET",
                    CURLOPT_HTTPHEADER =>       array(
                        "Content-Type:application/json"                        
                    )
                );
                curl_setopt_array($this->ch, $options);
                $result = curl_exec($this->ch);
                
                if(curl_errno($this->ch)){
                    return  json_decode('{"error":"Falha ao registrar rota no OKD"}');
                }   
                     
                $status = curl_getinfo($this->ch,CURLINFO_HTTP_CODE);                
                switch ($status) {
                    case 200:                                         
                       return json_decode($result);
                        break;
                    default:
                    
                    return json_decode('{"error":"Falha ao registrar rota no OKD"}');
                        break;
                }
        }catch(Exception $e){
            return json_decode('{"error":"'.$e->getMessage().'"}');
        }
        
    }

    
}