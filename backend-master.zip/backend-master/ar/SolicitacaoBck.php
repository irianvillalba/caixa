<?php

class SolicitacaoBck extends Record {
    
    const TABLENAME = 'solicitacoes_backends';
    
}