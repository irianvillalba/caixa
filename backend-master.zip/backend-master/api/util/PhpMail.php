<?php

class PhpMail {
	
	const MIN_PRIORITY = 5, MAX_PRIORITY = 1, STANDARD_PRIORITY = 3;
	const TYPE_HTML = 'html', TYPE_TEXT = 'text';
	const UTF_8 = 'utf-8', ISO_8859 = 'iso-8859-1';
	private $to, $from, $cc, $bcc;
	private $priority;
	private $subject;
	private $headers;
	private $message;
	private $type;
	private $notification;
	private static $logger;
	private $padrao;
	
	public function __construct($logger = null) { 
		$this->headers  = 'MIME-Version: 1.0' . "\n";							// sempre devera existir
		$this->padrao = self::UTF_8;											// set utf-8
		$this->type = "Content-type: text/html; charset={$this->padrao}\n";  	// set html
		$this->priority = 'X-Priority: '.self::STANDARD_PRIORITY."\n";			// set prioridade normal
		self::$logger = $logger; 
	}
	
	public function setLogger($logger) { self::$logger = $logger; }
	
	public function log($message, $level = null) { 
		if (self::$logger) { self::$logger->write($message, $level); } 
	}
	
	public function setType($option) {
		$option = strtolower($option);
		switch ($option) {
			case 'html':
				$this->type = "Content-type: text/html; charset={$this->padrao}\n";
				break;
			case 'text':
				$this->type = "Content-type: text/plain; charset={$this->padrao}\n";
				break;
		}
	}
	
	public function setPriority($priority) {
		$this->priority = 'X-Priority: '.$priority."\n";
	}
		
	public function subject($subject) { $this->subject = $subject; }
	
	public function message($message) { $this->message = $message; }
	
	private function converteUsuarios($usuarios) {
		$array_usr = array();
		if (is_string($usuarios)) { $array_tmp = explode(',', $usuarios); }
		if (is_array($usuarios))  { $array_tmp = $usuarios; }
		foreach ($array_tmp as $usr) {
			$usr = trim($usr);
			$array_usr[] = (strlen($usr) == 7 ) ? '<'.$usr.'@mail.caixa>' : '<'.$usr.'>';
		}
		$str_usr = implode(', ', $array_usr);
		return $str_usr;
	}
	
	public function to($users) {
		$string = $this->converteUsuarios($users);
		$this->to = 'To: '.$string."\n";
	}
	
	public function from($users) {
		$string = $this->converteUsuarios($users);
		$this->from = 'From: '.$string."\n";
	}
	
	public function cc($users) {
		$string = $this->converteUsuarios($users);
		$this->cc = 'Cc: '.$string."\n";
	}
	
	public function bcc($users) {
		$string = $this->converteUsuarios($users);
		$this->bcc = 'Bcc: '.$string."\n";
	}
	
	public function dispositionNotificationTo($users) {
		$string = $this->converteUsuarios($users);
		$this->notification = 'Disposition-Notification-To: '.$string."\n";
	}
	
	public function send() {
		$final_header = $this->headers . $this->type . $this->priority . $this->to . $this->from . $this->cc . $this->bcc . $this->notification;
		try {
			$flag = mail( null, $this->subject, $this->message, $final_header) ? 'OK' : 'FAIL';
			self::log('E-mail >> '.$flag.' >> '.$final_header, 'INFO');
			self::log('E-mail >> '.$flag.' >> '.$this->message, 'DEBUG');
			return $flag =='OK' ? true : false;
		} catch (Exception $e) {
			self::log('E-mail >> '.$e->getMessage(), 'ERROR');
		}
	}
	
	
}

// ##############  INICIO TESTE DE CLASSE  ###############################################################################
/*

$mail = new PhpMail();
$sistema = 'SIAAA';
$ambiente = 'desenvolvimento';
$id = '123';
$requisicao = 'TAS2345600023';
$solicitante = 'c056128';
$data_req = "21/02/2016";
$string_json = '{"timestamp":"2016-06-30-123800","sistema":"siron","solicitacao":"tas098786786786","ambiente":"des","acao":"criar","apresentacao":"intra","servidor":"srjdeapllx0019","solicitante":"c080028","instancias":"1","datasources":[{"data-source":"oraron","connection-url":"jdbc:oracle:thin:@oracle.caixa:1530:ORADES01","jndi-name":"java:\/oraron","user-name":"sabcdr01","password":"123456","driver-name":"oracle","driver-class":"oracle.jdbc.OracleDriver","max-pool-size":"40","min-pool-size":"4","enabled":"true","track-statements":"NOWARN","flush-strategy":"EntirePool","pool-prefill":"true","jta":"true","idle-timeout-minutes":"1"},{"data-source":"db2ron","jndi-name":"java:\/db2ron","connection-url":"jdbc:db2:\/\/db2connect.dsd0.caixa:448\/RJKDB2DSD0","user-name":"sabcdr01","password":"789456123","driver-name":"db2","driver-class":"com.ibm.db2.jcc.DB2Driver","max-pool-size":"40","min-pool-size":"4","enabled":"true","track-statements":"NOWARN","flush-strategy":"EntirePool","pool-prefill":"true","jta":"true","idle-timeout-minutes":"1"}],"targets":[{"nome":"tgronaa00","prefix":"aa","transid":"aa00","usr":"sabcdr01","pwd":"123456","host":"jcicsdirect.caixa","port":"7000","program":"pscpsdi3","mincommarea":"0","programtype":"3","timeout":"120000","reuselogin":"true"},{"nome":"tgronbb01","prefix":"bb","transid":"bb01","usr":"sabcdr01","pwd":"123","host":"jcicsdirect.caixa","port":"7000","program":"pscpsdi3","mincommarea":"0","programtype":"3","timeout":"120000","reuselogin":"true"}]}';
$array_json = (array) json_decode($string_json, true);
$i = 0;
foreach ($array_json["datasources"] as $datasource) {
	$array_json['datasources'][$i++]['password'] = "******";
}
$string_json = json_encode($array_json, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);


$subject = "Criacao do sistema {$sistema} no ambiente de {$ambiente}";
 		
$message = "
 			<html>
 				<header><title>{$subject}</title></header>
 			   	<body>
 			   		<font size=\"4\" face=\"Verdana\">
 			   			<n1>{$subject}</n1>
						<hr><br>
						À {$solicitante}<br><br>
						Seu ID de atendimento é <font color=\"red\">{$id}</font><br>
						Originado da requisição {$requisicao} feita por você em em {$data_req}<br>
						Um resumo de seu pedido se encontra a seguir:<br>
						<pre>
						{$string_json}
						</pre>
						<br><br>
						Att,<br>Suporte Multiplataforma<br>
					</font>
				</body>
			</html>";

						
$mail->to($solicitante);
$mail->cc($solicitante);
$mail->from($solicitante);
$mail->setPriority(PhpMail::MAX_PRIORITY);
$mail->subject($subject);
$mail->dispositionNotificationTo($solicitante);
$mail->message($message);
$mail->send();
*/
//var_dump($array_json);
// ##############  FIM TESTE DE CLASSE  ###############################################################################
























