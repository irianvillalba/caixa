<?php
class Utils
{
    public static function apiReturn(String $status, String $mensagem)
    {
        return array("retorno" => array("status" => $status, "mensagem" => $mensagem));
    }

    
    public static function apiReturnList(int $count, array $registros)
    {
        return array("retorno" =>array("status" => "OK", "registros" => $count, "dados" => $registros));
    }

    public static function apiReturnObject(String $status, array $registro)
    {
        return array("retorno" => array("status" => $status, "objeto" => $registro));
    }

    public function getListWithSql(String $sql,PDO $db): array
    {

        try {
            $registros = $db->query($sql, PDO::FETCH_ASSOC)->fetchAll();
            if ($registros === false) {
                throw new Exception("Falha ao executar a query: '$sql'", 1);
            }
            return $this->apiReturnList(count($registros), $registros);
        } catch (Exception $e) {
            return  $this->apiReturn("ERROR", $e->getMessage());
        }
    }

    public function getObjectWithSql(String $sql,PDO $db): array
    {

        try {
            $registro = $db->query($sql, PDO::FETCH_ASSOC)->fetch();
            if ($registro === false) {
                throw new Exception("objeto não encontrado", 1);
            }
            return $this->apiReturnObject("OK", $registro);
        } catch (Exception $e) {
            return  $this->apiReturn("ERROR", $e->getMessage());
        }
    }

    public function executeSQL(String $sql, PDO $db): array
    {

        try {
            $ret = $db->exec($sql);
            if ($ret === false) {
                throw new Exception("Falha na execução da query", 1);
            }
            return $this->apiReturn('OK', "executado com sucesso!");
        } catch (Exception $e) {            
            return $this->apiReturn('ERROR', $e->getMessage());
        } 
    }
}
