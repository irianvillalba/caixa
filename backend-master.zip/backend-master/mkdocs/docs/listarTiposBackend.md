Lista os tipos de backends cadastrados na base.

|MÉTODO|CHAMADA|
|:----------|:-----------|
|GET|https://infra.devops.caixa/api/api.php?acao=listarTiposBackend|

> Os tipos de backend devem ser cadastrados antes que possam ser utilizado para o cadastro do backend daquele tipo.


-----

#### Retorno

Para cada registro encontrado, as seguintes informações são retornadas na consulta:

|VALOR|DESCRIÇÃO|
|:----------:|:-----------:|
|**id**|ID do tipo de backend.|
|**tipo**|Nome do tipo de backend.|
|**data_inclusao**|Data na qual o tipo foi inserido.|


-----

#### Exemplo de chamada

```bash
https://infra.devops.caixa/api/api.php?acao=listarTiposBackend
```

-----


#### Exemplo de Retorno esperado

```json
{
	"registros": 4,
	"dados": [
		{
			"id": 1,
			"tipo": "oracle",
			"data_inclusao": "2019-12-23 15:50:13"
		},
		{
			"id": 2,
			"tipo": "db2",
			"data_inclusao": "2019-12-23 15:50:13"
		},
		{
			"id": 3,
			"tipo": "mq",
			"data_inclusao": "2019-12-23 15:50:13"
		},
		{
			"id": 4,
			"tipo": "sso",
			"data_inclusao": "2019-12-23 15:50:13"
		}
	]
}
```