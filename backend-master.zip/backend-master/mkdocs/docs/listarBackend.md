Lista os backends cadastrados na base.

|MÉTODO|CHAMADA|
|:----------|:-----------|
|GET|https://infra.devops.caixa/api/api.php?acao=listarBackend|

> A chamada aceita qualificadores, delimitando o retorno.

-----

#### Qualificadores

|TIPO|DESCRIÇÂO|
|:----------:|:-----------:|
|`ambiente`|Limita o retorno a determinado ambiente.|
|`tipo`|Limita o retorno a determinado tipo de backend.|
|`nome`|Retorna o backend que possui exatamente o nome informado.|
|`porta`|Retorna todos os backends que possuem determinada porta no cadastro.|


-----

#### Retorno

Para cada registro encontrado, as seguintes informações são retornadas na consulta:

|VALOR|DESCRIÇÃO|
|:----------:|:-----------:|
|**id**|ID do backend.|
|**nome**|Nome do backend.|
|**ambiente**|Ambiente do backend.|
|**ip**|IP do backend.|
|**porta**|Porta do backend.|
|**descricao**|Descricao do backend.|
|**tipo**|Tipo do backend.|
|**servidores**|Servidores nos quais o backend executa.|


-----

#### Exemplos de chamada

- Listar os backends com porta `5432`:
```bash
https://infra.devops.caixa/api/api.php?acao=listarBackend&porta=5432
```
- Listar todos os backends existentes no ambiente de `des`:
```bash
https://infra.devops.caixa/api/api.php?acao=listarBackend&ambiente=des
```
- Listar todos os backends `oracle` em `des`:
```bash
https://infra.devops.caixa/api/api.php?acao=listarBackend&ambiente=des&tipo=oracle
```

-----


#### Exemplo de Retorno esperado

```json
{
	"registros": 4,
	"dados": [
		{
			"id": 53,
			"nome": "ora43",
			"ambiente": "des",
			"ip": "10.216.76.185",
			"porta": "5432",
			"descricao": null,
			"tipo": "oracle",
			"servidores": "drjscgerlx0031"
		},
...
		{
			"id": 58,
			"nome": "ORACLE0001",
			"ambiente": "des",
			"ip": "10.116.82.1",
			"porta": "1521",
			"descricao": null,
			"tipo": "oracle",
			"servidores": "C"
		}
	]
}
```