<?php

class Autentica {

	const LIMITE_TENTATIVAS = 5;
	private static $logger;
	private $obj_usuario;
	private $usuario;
	private $senha;

	public function __construct($logger = null) {
		self::$logger = $logger;
	}

	public static function setLogger(Logger $logger) { self::$logger = $logger; }

	public static function log($message, $level = null) {
		if (self::$logger) { self::$logger->write($message, $level); }
	}

	public function existeNoAD($usuario, $senha) {
		$ip    = ip_ldap;
		$porta = porta_ldap;
		$perfil = array();

		// tenta a conexao ao AD

		$grupos = ['IAG_SUP','IAG_DEV','IAG_OPS'];
		$ldap_url 	= 'ldap://'.$ip.':'.$porta;
		$ldap_conn 	= ldap_connect($ldap_url); // or die("Could not connect to LDAP server.");

		// set opcoes
		ldap_set_option($ldap_conn, LDAP_OPT_PROTOCOL_VERSION, 3);
		ldap_set_option($ldap_conn, LDAP_OPT_REFERRALS, 0);

		if ($ldap_conn) {
			$ldaprdn  = "uid={$usuario},ou=People,o=caixa";
			error_reporting(E_ALL ^ E_WARNING);
			$ldap_bind_return = ldap_bind($ldap_conn, $ldaprdn, $senha);
			error_reporting(E_ALL);
			if ($ldap_bind_return) {
				$res = ldap_search($ldap_conn, $ldaprdn,  "(cn=*)");
				// Full user info ($gruposldap)
				$gruposldap = ldap_get_entries($ldap_conn, $res);
				$cgc = $gruposldap[0]['nu-lotacaofisica'][0];

				foreach($grupos as $grp) {
						$ldaprdn = "cn={$grp},cn=SIIAG,ou=Groups,o=caixa";
						$res = ldap_search($ldap_conn, $ldaprdn,  "(cn=*)");
						$gruposldap = ldap_get_entries($ldap_conn, $res);
						
						$u = strtolower($usuario);
						$teste = array_search("uid={$u},ou=People,o=caixa", $gruposldap[0]['uniquemember']);
						if (gettype($teste) == "integer") {
								$perfil["grupos"] = $grp;
						}				
					}				

				$perfil["nome"] = 'teste';
				$perfil["matricula"] = $usuario;
				$perfil["status"] = true;
				$perfil["cgc"] = $cgc;

				return $perfil;
			} else {
				$perfil["status"] = false;
				return $perfil;
			}
		}
	}

	public function getUsuarioNaBase($usuario, $senha = NULL) {
		try {
			Transaction::get();
			$criteria = new Criteria();
			$criteria->add(new Filter('matricula', '=', $usuario));
			if ($senha) { $criteria->add(New Filter('senha', '=', $senha)); }
			$array_obj_usuarios = Usuario::all($criteria);
			return count($array_obj_usuarios) > 0 ? $array_obj_usuarios[0] : NULL;
		} catch (Exception $e) {
			print $e->getMessage();
			return NULL;
		}
	}


	public function getPerfil($usuario, $senha) {
		$return = NULL;
		Transaction::open('database');
		Transaction::setLogger(self::$logger);
		if ( $this->existeNoAD($usuario, $senha) ) {				// se existir no AD
			$obj_usuario = $this->getUsuarioNaBase($usuario);			// verifica apenas o usuario na base de dados
			if ( $obj_usuario ) {										// se existir usuario na base de dados
				if ( $obj_usuario->ativo === TRUE) {						// se usuario esta ativo
					if ( $obj_usuario->tentativas > 0 ) {						// se existem mais de 1 tentativa de login
						$obj_usuario->tentativas = 0;								// zera tentativas
						$obj_usuario->store();										// grava alteracao
					}
					return $obj_usuario->perfil;								// retorna perfil com valor obtido
				}
			} else {													// se NAO existir o usuario na base de dados
				$return = NULL;												// retorna perfil com valor NULL
			}
		} else {													// se NAO existir no AD
			$obj_usuario = $this->getUsuarioNaBase($usuario);			// verifica apenas usuario na base de dados
			if ($obj_usuario) {											// se existir usuario
				if ( $obj_usuario->ativo === TRUE) {						// verifica se usuario esta ativo
					if ($obj_usuario->senha == $senha) {						// verifica se a senha esta correta
						if ( $obj_usuario->tentativas > 0 ) {						// se existem mais de 1 tentativa de login
							$obj_usuario->tentativas = 0;								// zera tentativas
							$obj_usuario->store();										// grava alteracao
						}
							$return = $obj_usuario->perfil;							// retorna perfil com valor obtido

					} else {												// se a senha estiver incorreta
						$obj_usuario->tentativas += 1;							// adiciona 1 em tentativas
						$obj_usuario->store();									// grava alteracao
						$return = NULL;											// retorna perfil NULL
					}
				} else {
					$obj_usuario->tentativas += 1;
					$obj_usuario->store();
					$return = NULL;
				}
			}
		}

		/*if ($obj_usuario->tentativas >= self::LIMITE_TENTATIVAS ) { 	// se exceder limite de tentativas
			$obj_usuario->ativo = FALSE;									// set false para usuario ativo
			Transaction::log("Usuario {$usuario} bloqueado por mais de ".self::LIMITE_TENTATIVAS.' tentativas.', 'INFO' );
		}*/
		Transaction::close();
		return $return;
	}

}