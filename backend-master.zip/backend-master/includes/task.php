<?php
    
    ini_set("xdebug.var_display_max_children", -1);
    ini_set("xdebug.var_display_max_data", -1);
    ini_set("xdebug.var_display_max_depth", -1);

    class Task {

        public $token;
        public $req;
        private $ch;
        private $api;

        function __construct($ambiente) {
            $this->ch = curl_init();
            if (strtolower($ambiente) == 'hmp')
                $this->api = ConfigTask::API_HMP; 
            else
                $this->api = ConfigTask::API_PRD;
        }

        //step 0 - requisitar o token
        public function getToken($usuario, $senha) {

            $options = array(
                CURLOPT_URL =>              $this->api . ConfigTask::ENDPOINT_LOGIN,
                CURLOPT_POST =>             1,
                CURLOPT_POSTFIELDS =>       "username={$usuario}&password={$senha}",
                CURLOPT_RETURNTRANSFER=>    1,
                CURLOPT_HTTPHEADER =>       array(
                    "Content-Type:application/x-www-form-urlencoded",
                    'cache-control:no-cache')
            );

            curl_setopt_array($this->ch, $options);
            $result = curl_exec($this->ch);
            return $result;
        }


        public function buscarTask($crq = '') {

            $options = array(
                CURLOPT_URL =>  $this->api . "/api/arsys/v1/entry/TMS:Task?q='RootRequestName'=%22{$crq}%22%20AND%20'TaskName'=%22REGRAS%20FW:%20Valida%C3%A7%C3%A3o%20Final%22",
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => "",
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 0,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => "GET",
                CURLOPT_HTTPHEADER =>       array(
                    "Content-Type:application/json",
                    'Authorization:AR-JWT ' . $this->token)
            );
            
            curl_setopt_array($this->ch, $options);
            $result = curl_exec($this->ch);

            return json_decode($result);
        }

        public function criarLogTask($tas = '', $nota) {
            $config = new ConfigTask();
            $config->paramTask['log']["values"]["z1D_WorkInfoSummary"] = "Realização do teste de regra";
            $config->paramTask['log']["values"]["z1D_WorkInfoNotes"] = $nota;

            $options = array(
                CURLOPT_URL =>              $this->api . "/api/arsys/v1/entry/TMS:Task/{$tas}",
                CURLOPT_RETURNTRANSFER =>   true,
                CURLOPT_ENCODING =>         "",
                CURLOPT_MAXREDIRS =>        10,
                CURLOPT_TIMEOUT =>          0,
                CURLOPT_FOLLOWLOCATION =>   true,
                CURLOPT_HTTP_VERSION =>     CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST =>    "PUT",
                CURLOPT_POSTFIELDS =>       json_encode($config->paramTask['log']),
                CURLOPT_HTTPHEADER =>       array(
                    "Content-Type:application/json",
                    'Authorization:AR-JWT ' . $this->token)
            );

            var_dump($options);
            curl_setopt_array($this->ch, $options);
            $result = json_decode(curl_exec($this->ch));

            return $result;
        }

        public function andamentoTask($tas = '') {
            $config = new ConfigTask();
            $options = array(
                CURLOPT_URL =>              $this->api . "/api/arsys/v1/entry/TMS:Task/{$tas}",
                CURLOPT_RETURNTRANSFER =>   true,
                CURLOPT_ENCODING =>         "",
                CURLOPT_MAXREDIRS =>        10,
                CURLOPT_TIMEOUT =>          0,
                CURLOPT_FOLLOWLOCATION =>   true,
                CURLOPT_HTTP_VERSION =>     CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST =>    "PUT",
                CURLOPT_POSTFIELDS =>       json_encode($config->paramTask['andamento']),
                CURLOPT_HTTPHEADER =>       array(
                    "Content-Type:application/json",
                    'Authorization:AR-JWT ' . $this->token)
            );

            curl_setopt_array($this->ch, $options);
            $result = json_decode(curl_exec($this->ch));

            return $result;
        }

        public function fecharTask($tas = '') {
            $config = new ConfigTask();
            $options = array(
                CURLOPT_URL =>              $this->api . "/api/arsys/v1/entry/TMS:Task/{$tas}",
                CURLOPT_RETURNTRANSFER =>   true,
                CURLOPT_ENCODING =>         "",
                CURLOPT_MAXREDIRS =>        10,
                CURLOPT_TIMEOUT =>          0,
                CURLOPT_FOLLOWLOCATION =>   true,
                CURLOPT_HTTP_VERSION =>     CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST =>    "PUT",
                CURLOPT_POSTFIELDS =>       json_encode($config->paramTask['fechamento']),
                CURLOPT_HTTPHEADER =>       array(
                    "Content-Type:application/json",
                    'Authorization:AR-JWT ' . $this->token)
            );

            curl_setopt_array($this->ch, $options);
            $result = json_decode(curl_exec($this->ch));

            return $result;
        }

        private function logout() {
            $options = array(
                CURLOPT_URL =>              $this->api . Config::ENDPOINT_LOGOUT,
                CURLOPT_POST =>             1,    
                CURLOPT_RETURNTRANSFER=>    1,
                CURLOPT_HTTPHEADER =>       array(
                    "cache-control:no-cache",
                    'Authorization:AR-JWT ' . $this->token)
            );

            curl_setopt_array($this->ch, $options);
            $result = curl_exec($this->ch);
        }

        function __destruct()
        {
            $this->logout();
            curl_close($this->ch);
        }
    }

    //$array_json = json_decode(file_get_contents("php://input"), true);
    /*
    
    $task = new Task("hmp");

    $task->token = $task->getToken("USR_CETADPOR1", "CETADPOR1");
    $tarefa = $task->buscarTask('CRQ000000413384');

    $idtask = $tarefa->entries[0]->values->{'Task ID'};
    $task->criarLogTask($idtask);
    $task->andamentoTask($idtask);
    $task->fecharTask($idtask);
    */

?>