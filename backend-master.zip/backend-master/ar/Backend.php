<?php

class Backend extends Record {
    
    const TABLENAME = 'backends';
    
}