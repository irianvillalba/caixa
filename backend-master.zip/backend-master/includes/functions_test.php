<?php
  
  // descobrindo o diretório home.
  $homeDir = dirname(__DIR__, 1);
  $matricula = '';

  
  date_default_timezone_set('America/Sao_Paulo');

  function testeSipgc($parametros) {
    try {
      $sipgc = new SipgcClient(endpoint_sipgc);
      return $sipgc->getSipgcComunidade(14159);
      } catch ( Exception $e ) {
      $array = [];
      $array['erro'] = "erro ao executar o test {$e->getMessage()}";
      return $array;
      } finally {
      
    }
  }

  function testeSipapp($parametros) {
    try {
      $sipgc = new SipgcClient(endpoint_sipgc_siapp);
      return $sipgc->getSiappSistema();
      } catch ( Exception $e ) {
      $array = [];
      $array['erro'] = "erro ao executar o test {$e->getMessage()}";
      return $array;
      } finally {
      
    }
  }