<?php

print "teste";