<?php

class Sistema extends Record {
    
    const TABLENAME = 'sistemas';
    
}