<?php
  
  
  function listarGrafico($parametros) {
    try {
      Transaction::open('database');
      $db = Transaction::get();

      $sql = "SELECT * from {$parametros['view']}";

      $registros = $db->query($sql,PDO::FETCH_ASSOC)->fetchAll();
      
      return $registros;
      } catch ( Exception $e ) {
      $array = [];
      $array['erro'] = "erro execucao da query";
      Transaction::close ();
      return $array;
      } finally {
      Transaction::close ();
    }
  }

  function listarUsuarios() {
    try {
      Transaction::open('database');
      $db = Transaction::get();

      $sql = "select u.matricula, u.nome, u.sobrenome, p.perfil, u.id from usuarios u
      inner join perfil p on p.id_perfil = u.id_perfil";

      $registros = $db->query($sql,PDO::FETCH_ASSOC)->fetchAll();
      
      return $registros;
      } catch ( Exception $e ) {
      $array = [];
      $array['erro'] = "erro execucao da query";
      Transaction::close ();
      return $array;
      } finally {
      Transaction::close ();
    }
  }

  function listarLog($parametros) {
    try {
      Transaction::open('database');
      $db = Transaction::get();
      $arrayBindValue = [ ];
      $dataInicio = $parametros['inicio'] . ' 00:00:00';
      $dataFinal = $parametros['fim'] . ' 23:59:59';
      $palavraBuscaGeral = $parametros['palavra'];

      if(is_numeric($palavraBuscaGeral))
      {
        $consultaId = " or id_log::text like '%$palavraBuscaGeral%'";
      } else {
        $consultaId = '';
      }

      $sql = "SELECT * FROM log where metodo = 'POST' and datahora >= '$dataInicio' and datahora <= '$dataFinal' and 
      (dados like '%$palavraBuscaGeral%' or matricula like '%$palavraBuscaGeral%' or acao like '%$palavraBuscaGeral%' " . $consultaId . ") order by datahora desc";

      $statement = $db->prepare($sql);
      foreach ($arrayBindValue as $indice => $valor) {
        $statement->bindValue ( ":{$indice}", $valor );
      }
      
      $statement->execute();
      $registros = $statement->rowCount();
      $arrayRetorno = array();
      $arrayRetorno["registros"] = $registros;
      
      if ($registros == 0) {
        $array['info'] = "não foram encontrados resultados.";
        return $array;
        die;
      }
      
      foreach ($statement as $row ) {
        $arrayLog[] = array (
        'id_log' => $row['id_log'],
        'matricula' => $row['matricula'],
        'datahora' => $row['datahora'],
        'acao' => $row['acao'],
        'dados' => $row['dados'],
        'metodo' => $row['metodo']
        );
      }
      
      $arrayRetorno["dados"] = $arrayLog;
      
      return $arrayRetorno;
      } catch ( Exception $e ) {
      $array = [];
      $array['erro'] = "erro execucao da query";
      Transaction::close ();
      return $array;
      } finally {
      Transaction::close ();
    }
  }

  function listarVersao($parametros) {
    try {
      Transaction::open('database');
      $db = Transaction::get();
      $arrayBindValue = [ ];
      $sql = "SELECT * from versao order by data_atualizacao desc";

      $statement = $db->prepare($sql);
      foreach ($arrayBindValue as $indice => $valor) {
        $statement->bindValue ( ":{$indice}", $valor );
      }
      
      $statement->execute();
      $registros = $statement->rowCount();
      $arrayRetorno = array();
      $arrayRetorno["registros"] = $registros;
      
      if ($registros == 0) {
        $array['info'] = "não foram encontrados resultados.";
        return $array;
        die;
      }
      
      foreach ($statement as $row ) {
        $arrayVersao[] = array (
        'id_versao' => $row['id_versao'],
        'versao' => $row['versao'],
        'readme' => $row['readme'],
        'data' => $row['data_atualizacao']
        );
      }
      
      $arrayRetorno["dados"] = $arrayVersao;
      
      return $arrayRetorno;
      } catch ( Exception $e ) {
      $array = [];
      $array['erro'] = "erro execucao da query";
      Transaction::close ();
      return $array;
      } finally {
      Transaction::close ();
    }
  }

  function listaRegra($parametros) {
    try {
      Transaction::open('database');
      $db = Transaction::get();
      $registros = array();
      $sql = "select * from teste_regra where solicitacao_id = {$parametros['id_regra']}";
      $lista = $db->query($sql, PDO::FETCH_ASSOC)->fetchall(); 

      $registros = $lista;
      
      if (count($lista) == 0) {
        $array['info'] = "não foram encontrados resultados.";
        return $array;
        die;
      }
      
      return $registros;

      } catch ( Exception $e ) {
      $array = [];
      $array['erro'] = "erro execucao da query";
      Transaction::close ();
      return $array;
      } finally {
      Transaction::close ();
    }    
  }

  function infoRegra($parametros) {
    try {

      Transaction::open('database');
      $db = Transaction::get();
      $registros = array();
      $plataforma = "";
      if (isset($parametros['plataforma']))
        $plataforma = " and plataforma = '{$parametros['plataforma']}'";

      $sol = $db->query("select id from solicitacoes_id where id_regras = {$parametros['id_regra']}",PDO::FETCH_ASSOC)->fetch(); 
      
      $serv = $db->query("select servidores_json from servidores where solicitacoes_id = {$sol['id']} {$plataforma}",PDO::FETCH_ASSOC)->fetchall();       
      $bck = $db->query("select DISTINCT b.nome, b.ip, b.porta from backends b 
      inner join solicitacoes_backends sb on sb.id_backend = b.id
      where sb.solicitacoes_id = {$sol['id']}",PDO::FETCH_ASSOC)->fetchAll(); 
      $registros['servidores'] = $serv;
      $registros['backends'] = $bck;
      
      if (count($sol) == 0) {
        $array['info'] = "não foram encontrados resultados.";
        return $array;
        die;
      }
      
      return $registros;

      } catch ( Exception $e ) {
      $array = [];
      $array['erro'] = "erro execucao da query";
      Transaction::close ();
      return $array;
      } finally {
      Transaction::close ();
    }
  }
  
  function listarGrupos($parametros) {
    try {

      Transaction::open('database');
      $db = Transaction::get();
      $registros = array();

      $grp = $db->query("select * from grupos",PDO::FETCH_ASSOC)->fetchAll(); 

      $registros['grupos'] = $grp;
      
      if (count($grp) == 0) {
        $array['info'] = "não foram encontrados resultados.";
        return $array;
        die;
      }
      
      return $registros;

      } catch ( Exception $e ) {
      $array = [];
      $array['erro'] = "erro execucao da query";
      Transaction::close ();
      return $array;
      } finally {
      Transaction::close ();
    }
  }

  function listarTipoNfs($parametros) {
    
    try {
      Transaction::open('database');
      $db = Transaction::get();
      $arrayBindValue = [ ];
      $sql = "SELECT * from tipo_nfs";

      $statement = $db->prepare($sql);
      foreach ($arrayBindValue as $indice => $valor) {
        $statement->bindValue ( ":{$indice}", $valor );
      }
      
      $statement->execute();
      $registros = $statement->rowCount();
      $arrayRetorno = array();
      $arrayRetorno["registros"] = $registros;
      
      if ($registros == 0) {
        $array['info'] = "não foram encontrados resultados.";
        return $array;
        die;
      }
      
      foreach ($statement as $row ) {
        $arraySistemas[] = array (
        'id' => $row['id'],
        'tipo_nfs' => $row['tipo_nfs']
        );
      }
      
      $arrayRetorno["dados"] = $arraySistemas;
      
      return $arrayRetorno;
      } catch ( Exception $e ) {
      $array = [];
      $array['erro'] = "erro execucao da query";
      Transaction::close ();
      return $array;
      } finally {
      Transaction::close ();
    }
  }

  
  function listarPlataforma($parametros) {
    try {
      Transaction::open('database');
      $db = Transaction::get();
      
      $arrayBindValue = [ ];
      $sql = "SELECT * from plataforma ";
      
      foreach ($parametros as $indice => $valor) {
        if ($indice != 'acao') {
          switch ($indice) {
            case 'id':
            case 'tipo':
            $sql .= "AND {$indice} = :{$indice} ";
            break;      
          }
          $arrayBindValue[$indice] = $valor;
        }
      }
      
      $statement = $db->prepare($sql);
      foreach ($arrayBindValue as $indice => $valor) {
        $statement->bindValue ( ":{$indice}", $valor );
      }
      
      $statement->execute();
      $registros = $statement->rowCount();
      $arrayRetorno = array();
      $arrayRetorno["registros"] = $registros;
      
      if ($registros == 0) {
        $array['info'] = "não foram encontrados resultados.";
        return $array;
        die;
      }
      
      foreach ($statement as $row ) {
        $arrayPlataforma[] = array (
        'id_plataforma' => $row['id_plataforma'],
        'plataforma' => $row['plataforma'],
        'versao' => $row['versao']
        );
      }
      
      $arrayRetorno["dados"] = $arrayPlataforma;
      
      return $arrayRetorno;
      } catch ( Exception $e ) {
      $array = [];
      $array['erro'] = "erro execucao da query";
      Transaction::close ();
      return $array;
      } finally {
      Transaction::close ();
    }
  }

    
  
  function getIDSolicitacao($data) {
    try {
      Transaction::open('database');
      $db = Transaction::get();
      $sql = "select id from solicitacoes_infra where to_char(data_solicitacao, 'YYYY-MM-DD HH24:MI:SS') like :DATA";
      $statement = $db->prepare($sql);
      $statement->bindValue ( ':DATA', $data );
      $statement->execute();
      $registros = $statement->rowCount();
      $arrayRetorno = array();
      $arrayRetorno["registros"] = $registros;
      
      if ($registros == 0) {
        $array['info'] = "não foram encontrados resultados.";
        return $array;
        die;
      }
      
      foreach ($statement as $row ) {
        $arraySistemas[] = array (
        'id' => $row['id']
        );
      }
      
      $arrayRetorno["dados"] = $arraySistemas;
      
      return $arrayRetorno;
      } catch ( Exception $e ) {      
      $array = [];
      $array['erro'] = "erro execucao da query";
      Transaction::close ();               
      return $array;
      } finally {
      Transaction::close ();
    }
  }
  
  
 
  
  function consultarCotas($parametros) {
    try {
      Transaction::open('database');
      $db = Transaction::get();
      $arrayBindValue = [ ];

      $sql = "SELECT * from limites_cotas  where id_limites_cotas > 0 and memoria > 0 ";

      
      foreach ($parametros as $indice => $valor) {
        if ($indice != 'acao') {
          $sql .= "AND {$indice} = :{$indice} ";
          $arrayBindValue[$indice] = $valor;
        }
      }
      $sql .= "order by ambiente, classe";
      $statement = $db->prepare($sql);
      foreach ($arrayBindValue as $indice => $valor) {
        $statement->bindValue ( ":{$indice}", $valor );
      }
      
      $statement->execute();
      $registros = $statement->rowCount();
      $arrayResultado = array();
      $arrayResultado["registros"] = $registros;
      
      if ($registros == 0) {
        $array['info'] = "não foram encontrados resultados.";
        return $array;
        die;
      }

      foreach ($statement as $row ) {
        
        $arrayRetorno[] = array (
        'id_limites_cotas' => $row['id_limites_cotas'],
        'ambiente' => $row['ambiente'],
        'memoria' => $row['memoria'],
        'cpu' => $row['cpu'],
        'instancia' => $row['instancia'],
        'tipo' => $row['tipo'],
        'classe' => $row['classe']
        );
      }
      
      $arrayResultado["dados"] = $arrayRetorno;
      
      return $arrayResultado;
      } catch ( Exception $e ) {
      $array = [];
      $array['erro'] = "erro execucao da query";
      Transaction::close ();
      return $array;
      } finally {
      Transaction::close ();
    }    
  }
  
  function listarSolicitacoes($parametros) {
    try {
      Transaction::open('database');
      $db = Transaction::get();
      $arrayBindValue = [ ];

      $sql = " SELECT si.*, s.sigla,
      (select id from servidores sb where sb.sistema = si.modulo and sb.ambiente = si.ambiente and solicitacoes_id is not null limit 1) as solicitado,
      (select plataforma from servidores sb where sb.sistema = si.modulo and sb.ambiente = si.ambiente and solicitacoes_id is not null limit 1) as tipo,
      (select template_name from servidores sb where sb.sistema = si.modulo and sb.ambiente = si.ambiente limit 1) as template_name  
      from solicitacoes_infra si
      inner join sistemas s on si.id_sistema = s.id 
      where si.status = 'ativado'";
      
      foreach ($parametros as $indice => $valor) {
        if ($indice != 'acao') {
          $sql .= "AND {$indice} = :{$indice} ";
          $arrayBindValue[$indice] = $valor;
        }
      }
      $sql .= "  order by si.modulo, si.data_solicitacao asc";
      $statement = $db->prepare($sql);
      foreach ($arrayBindValue as $indice => $valor) {
        $statement->bindValue ( ":{$indice}", $valor );
      }
      
      $statement->execute();
      $registros = $statement->rowCount();
      $arrayResultado = array();
      $arrayResultado["registros"] = $registros;
      
      if ($registros == 0) {
        $array['info'] = "não foram encontrados resultados.";
        return $array;
        die;
      }

      foreach ($statement as $row ) {

        $json = json_decode($row['json_solicitacao'], true);

        if (isset($json['contextos'])) 
          $cont = $json['contextos'];
        else
          $cont = '';

        $sql = "select sp.id_plataforma, p.plataforma from solicitacoes_plataforma as sp
        inner join plataforma p on p.id_plataforma = sp.id_plataforma where sp.id_solicitacao = {$row['id']}";        
        $res = $db->query($sql, PDO::FETCH_ASSOC);
        
        $sql = "select * from vip where id_solicitacao = {$row['id']}";
        $resVIP = $db->query($sql, PDO::FETCH_ASSOC);

        if (isset($row['id_limites_cotas']))
          $cotas = $db->query("select * from limites_cotas where id_limites_cotas = {$row['id_limites_cotas']}", PDO::FETCH_ASSOC)->fetch();
        else
          if (isset($row['id_limites_cotas_personalizado']))
          $cotas = $db->query("select * from solicitacao_limites_cotas where id_solicitacao_limites_cotas = {$row['id_limites_cotas_personalizado']}", PDO::FETCH_ASSOC)->fetch();
        
        $cotas['tipo'] = $row['tipo'];

        $arrayRetorno[] = array (
        'id' => $row['id'],
        'sistema' => $row['sigla'],
        'modulo' => $row['modulo'],
        'solicitado' => $row['solicitado'],
        'plataforma' => $res->fetchAll(),
        'solicitante' => $row['solicitante'],
        'template_name' => $row['template_name'],
        'contexto' => $cont,
        'centralizadora' => $row['centralizadora'],
        'cotas' => $cotas,
        'vip' => $resVIP->fetchAll(),
        'ambiente' => $row['ambiente'],
        'data_solicitacao' => $row['data_solicitacao'],
        'backends' => $json['backends'],
        'evolui' => $row['evolui']
        );
      }
      
      $arrayResultado["dados"] = $arrayRetorno;
      
      return $arrayResultado;
      } catch ( Exception $e ) {
      $array = [];
      $array['erro'] = "erro execucao da query";
      Transaction::close ();
      return $array;
      } finally {
      Transaction::close ();
    }
  }
  
  function listarRelacionamentosInfra($parametros) {
    try {
      Transaction::open('database');
      $db = Transaction::get();
      $arrayBindValue = [ ];
      $sql = "SELECT * from vw_relacionamento_infra ";
      
      foreach ($parametros as $indice => $valor) {
        if ($indice != 'acao') {
          $sqlinicial[] = "{$indice} = :{$indice} ";
          $arrayBindValue[$indice] = $valor;
        }
      }
      
      if (count($parametros) > 1 ) {
        $sql = $sql . ' WHERE '. implode(" AND ", $sqlinicial);
      }
      
      $statement = $db->prepare($sql);
      foreach ($arrayBindValue as $indice => $valor) {
        $statement->bindValue ( ":{$indice}", $valor );
      }
      
      $statement->execute();
      $registros = $statement->rowCount();
      $arrayResultado = array();
      $arrayResultado["registros"] = $registros;
      
      if ($registros == 0) {
        $array['info'] = "não foram encontrados resultados.";
        return $array;
        die;
      }
      
      foreach ($statement as $row ) {
        
        $arrayRetorno[] = array (
        'id' => $row['id'],
        'modulo' => $row['modulo'],
        'solicitante' => $row['solicitante'],
        'localidade' => $row['centralizadora'],
        'ambiente' => $row['ambiente'],
        'tipo' => $row['tipo']
        );
      }
      
      $arrayResultado["dados"] = $arrayRetorno;
      
      return $arrayResultado;
      } catch ( Exception $e ) {
      $array = [];
      $array['erro'] = "erro execucao da query";
      Transaction::close();
      return $array;
      } finally {
      Transaction::close();
      }
  }

  
  function consultarCotasSistemas($parametros) {
    try {
      Transaction::open('database');
      $db = Transaction::get();
      $arrayBindValue = [ ];
      $sql = "SELECT * from solicitacao_limites_cotas where status <> '' "; 

      foreach ($parametros as $indice => $valor) {
        if ($indice != 'acao') {
          switch ($indice) {
            case 'id_solicitacao_limites_cotas':
            case 'status':
            case 'id_regras':
            case 'sistema':
            case 'modulo':
            case 'ambiente':
            case 'plataforma':
            $sqlinicial[] = "{$indice} = :{$indice} ";
            break;     
          }

          $arrayBindValue[$indice] = $valor;
        }
      }
      
      if (count($parametros) > 1 ) {
        $sql = $sql . ' AND '. implode(" AND ", $sqlinicial);
      }
      
      $statement = $db->prepare($sql);
      foreach ($arrayBindValue as $indice => $valor) {
          $statement->bindValue ( ":{$indice}", $valor);
      }
      
      $statement->execute();
      $registros = $statement->rowCount();
      $arrayRetorno = array();
      $arrayRetorno["registros"] = $registros;
      
      if ($registros == 0) {
        $array['info'] = "não foram encontrados resultados.";
        return $array;
        die;
      }
      
      foreach ($statement as $row ) {

        
        $arraySistemas[] = array (
        'id_limites_cotas' => $row['id_solicitacao_limites_cotas'],
        'modulo' => $row['modulo'],
        'ambiente' => $row['ambiente'],
        'memoria' => $row['memoria'],
        'cpu' => $row['cpu'],
        'instancia' => $row['instancia']
        );
      }
      
      $arrayRetorno["dados"] = $arraySistemas;
      
      return $arrayRetorno;
      } catch ( Exception $e ) {
      $array = [];
      $array['erro'] = "erro execucao da query";
      Transaction::close ();
      return $array;
      } finally {
      Transaction::close ();
    }
  }

  

    
  function listarRegraSolicitado($parametros) {
    try {
      Transaction::open('database');
      $db = Transaction::get();

      $sql = "SELECT * from solicitacoes_id where sistema ilike '%{$parametros['sistema']}%' and ambiente = '{$parametros['ambiente']}' order by data_inclusao desc";

      $statement = $db->prepare($sql);
      
      $statement->execute();
      $registros = $statement->rowCount();
      $arrayResultado = array();
      $arrayResultado["registros"] = $registros;
      
      if ($registros == 0) {
        $array['info'] = "não foram encontrados resultados.";
        return $array;
        die;
      }
      
      foreach ($statement as $row ) {
        $arrayRetorno[] = array (
        'id' => $row['id'],
        'id_regras' => $row['id_regras'],
        'id_mudanca' => $row['id_mudanca'],
        'solicitante' => $row['solicitante'],
        'objeto_regra' => $row['json_regra'],
        'data_solicitacao' => $row['data_inclusao']);    

      }
      
      $arrayResultado["dados"] = $arrayRetorno;
      
      return $arrayResultado;
      } catch ( Exception $e ) {
      $array = [];
      $array['erro'] = "erro execucao da query";
      Transaction::close();
      return $array;
      } finally {
      Transaction::close();
      }
  }
  

  function consultarFQDN($parametros) {
    try {
      Transaction::open('database');
      $db = Transaction::get();
      $arrayBindValue = [ ];

      $sql = "SELECT * from solicitacao_fqdn where id_fqdn > 0 ";

      
      foreach ($parametros as $indice => $valor) {
        if ($indice != 'acao') {
          $sql .= "AND {$indice} = :{$indice} ";
          $arrayBindValue[$indice] = $valor;
        }
      }
      
      $statement = $db->prepare($sql);
      foreach ($arrayBindValue as $indice => $valor) {
        $statement->bindValue ( ":{$indice}", $valor );
      }
      
      $statement->execute();
      $registros = $statement->rowCount();
      $arrayResultado = array();
      $arrayResultado["registros"] = $registros;
      
      if ($registros == 0) {
        $array['info'] = "não foram encontrados resultados.";
        return $array;
        die;
      }

      foreach ($statement as $row ) {
        
        $arrayRetorno[] = array (
        'id_fqdn' => $row['id_fqdn'],
        'sistema' => $row['sistema'],
        'fqdn' => $row['fqdn'],
        'status' => $row['status'],
        'data_cadastro' => $row['data_cadastro'],
        'ip_real' => $row['ip_real']
        );
      }
      
      $arrayResultado["dados"] = $arrayRetorno;
      
      return $arrayResultado;
      } catch ( Exception $e ) {
      $array = [];
      $array['erro'] = "erro execucao da query";
      Transaction::close ();
      return $array;
      } finally {
      Transaction::close ();
    }    
  }

  function listarModulos($parametros) {
    try {
      Transaction::open('database');
      $db = Transaction::get();
      $param = '';
      
      if($parametros['ambiente'] != '')
        $param .= "and s.ambiente = '{$parametros['ambiente']}'";

      if($parametros['sistema'] != '')
        $param .= "and s.sistema ilike '%{$parametros['sistema']}%'";

      if($parametros['plataforma'] != '')
        $param .= "and s.plataforma = '{$parametros['plataforma']}'";

      $sql = "select distinct s.sistema, s.ambiente, s.plataforma from servidores s
      where s.status = 'ativado' $param order by s.sistema";

      $statement = $db->prepare($sql);

      $statement->execute();
      $registros = $statement->rowCount();
      $arrayResultado = array();
      $arrayResultado["registros"] = $registros;
      
      if ($registros == 0) {
        $array['info'] = "não foram encontrados resultados.";
        return $array;
        die;
      }

      foreach ($statement as $row ) {
        $arrayRetorno[] = array (
        'sistema' => $row['sistema'],
        'ambiente' => $row['ambiente'],
        'plataforma' => $row['plataforma']
        );
      }
      
      $arrayResultado["dados"] = $arrayRetorno;
      
      return $arrayResultado;
      } catch ( Exception $e ) {
      $array = [];
      $array['erro'] = "erro execucao da query";
      Transaction::close ();
      return $array;
      } finally {
      Transaction::close ();
    }
  }

  function listarSistema($parametros) {
    try {
      Transaction::open('database');
      $db = Transaction::get();
      $param = '';
      if(isset($parametros['ambiente']) && $parametros['ambiente'] != '')
        $param .= "and si.ambiente = '{$parametros['ambiente']}' and s.ambiente = '{$parametros['ambiente']}'";

      $sis = strtolower(substr($parametros['sistema'], 0,5));
      if($parametros['sistema'] != '')
        $param .= "and substring(si.modulo from 1 for 5) = '{$sis}'";

      $sql = "select distinct substring(si.modulo from 1 for 5) as sistema, si.ambiente, s.plataforma  from solicitacoes_infra si
      inner join servidores s on si.modulo = s.sistema
      where si.status = 'ativado' and s.status = 'ativado' $param
      order by substring(si.modulo from 1 for 5)";

      $statement = $db->prepare($sql);

      $statement->execute();
      $registros = $statement->rowCount();
      $arrayResultado = array();
      $arrayResultado["registros"] = $registros;
      $arrayRetorno = array();
      if ($registros == 0) {
        //se pedir na requisição para verificar na base do siapp 
        if(isset($parametros['siapp']) && $parametros['siapp']=='true'){
          $sipgc = new SipgcClient(endpoint_sipgc_siapp);
          $siappret = $sipgc->getSiappSistema($sis);
          
        
          if(count($siappret) > 0){
            foreach ($siappret as $row ) {
              $arrayRetorno[] = array (
              'sistema' => strtolower($row->sigla),
              'ambiente' => isset($parametros['ambiente']) ? $parametros['ambiente'] : 'prd',
              'plataforma' => 'siapp'
              );
            }            
          }else{
            $array['info'] = "não foram encontrados resultados.";
            return $array;
          }
        }
       
        
      }else{
        foreach ($statement as $row ) {
          $arrayRetorno[] = array (
          'sistema' => $row['sistema'],
          'ambiente' => isset($row['ambiente']) ? $row['ambiente'] : 'prd',
          'plataforma' => $row['plataforma']
          );
        }

      }
      $arrayResultado["dados"] = $arrayRetorno;
      
      return $arrayResultado;
      } catch ( Exception $e ) {
      $array = [];
      $array['erro'] = "erro execucao da query";
      Transaction::close ();
      return $array;
      } finally {
      Transaction::close ();
    }
  }

  function possoAjudar($parametros) {
    try {
      Transaction::open('database');
      $db = Transaction::get();
      $arrayBindValue = [ ];

      $sql = "SELECT * from manual where id_manual > 0 ";
      
      foreach ($parametros as $indice => $valor) {
        if ($indice != 'acao') {
          $sql .= "AND {$indice} = :{$indice} ";
          $arrayBindValue[$indice] = $valor;
        }
      }

      $statement = $db->prepare($sql);
      foreach ($arrayBindValue as $indice => $valor) {
        $statement->bindValue ( ":{$indice}", $valor );
      }

      $statement->execute();
      $registros = $statement->rowCount();
      $arrayResultado = array();
      $arrayResultado["registros"] = $registros;
      
      if ($registros == 0) {
        $array['info'] = "não foram encontrados resultados.";
        return $array;
        die;
      }

      foreach ($statement as $row ) {
        $arrayRetorno[] = array (
        'id' => $row['id_manual'],
        'conteudo' => $row['texto'],
        'pagina' => $row['pagina']
        );
      }
      
      $arrayResultado["dados"] = $arrayRetorno;
      
      return $arrayResultado;
      } catch ( Exception $e ) {
      $array = [];
      $array['erro'] = "erro execucao da query";
      Transaction::close ();
      return $array;
      } finally {
      Transaction::close ();
    }
  }

  function listarModulosQuestionario($parametros) {

    try {
      Transaction::open('database');
      $db = Transaction::get();
      $arrayBindValue = [ ];
      $sql = "SELECT distinct s.id, s.* , tb.type_question , req.requisicao, req.registropai, req.mensagem , req.data_criacao
      FROM public.sistemas as s
      inner join tb_modulos tb on tb.sistema_id = s.id
      left join tb_requisicao req on s.id = req.sistema_id
      where s.sigla != '' order by s.id desc"; 
     
    
      $statement = $db->prepare($sql);
      $statement->execute();
      $arrayRetorno = array();

     

      foreach ($statement as $row =>  $sigla ) {


        if(isset($sigla['requisicao'])){
          $sigla['nome'] = 'SIM';
        } else{
          $sigla['nome'] = 'NÃO';
        }


        $arraySigla[] = array(
            'id' => $sigla["id"], 
            'nome_sistema' => $sigla['sigla'],
            'status' => $sigla['status'],
            'regras' => $sigla['nome'],
            'tipo_sistema' => $sigla['type_question'],
            'requisicao' => $sigla['requisicao'],
            'registropai' => $sigla['registropai'],
            'mensagem' => $sigla['mensagem'],
            'data_criacao' =>$sigla['data_criacao']
            
        );
        
      }

      $arrayRetorno["dados"] = $arraySigla;

      
      return $arrayRetorno;
      } catch ( Exception $e ) {
        var_dump($e->getMessage());
        die();
      $array = [];
      $array['erro'] = "erro execucao da query";
      Transaction::close ();
      return $array;
      } finally {
      Transaction::close ();
    }

  }

 function listarRequisicaoVip($parametros){

   
    $sistema = $parametros["sistema"];
    $tipo = $parametros["ambiente"];

    try {
      Transaction::open('database');
      $db = Transaction::get();

      $sql = "SELECT * from vip where sistema like '{$sistema}%' and tipo = '{$tipo}' and requisicao notnull;";
      


      $statement = $db->prepare($sql);
      $statement->execute();
      $arrayRetorno = array();

  
    
      foreach ($statement as $id =>  $row ) {
        $arrayRetorno[] = array (
        'sistema' => $row['sistema'],
        'requisicao' => $row['requisicao'],
        'site' => $row['site'],
        'ip' => $row['ip'],
        'data_solicitacao' => $row['data_cadastro'] ,     
        'tipo' => $row['tipo'] ,     
        'mensagem' => $row['mensagem_gsc']); 
      }
      
      $arrayResultado["dados"] = $arrayRetorno;

      return $arrayResultado;
      } catch ( Exception $e ) {
      $array = [];
      $array['erro'] = "erro execucao da query";
      Transaction::close();
      return $array;
      } finally {
      Transaction::close();
      }
  }

  function listarServidoresCadastradosQuestionario($parametros) {

  
    try {
      Transaction::open('database');
      $db = Transaction::get();
      $arrayBindValue = [ ];
      $sql = "SELECT id, sistema, ambiente, plataforma, versao_plataforma, produto, servidores_json, data_inclusao, solicitacoes_id, status, ipbackup, id_limites_cotas, site from servidores where status <> '' "; 
      $s = "";
      foreach ($parametros as $indice => $valor) {
        if ($indice != 'acao') {
          switch ($indice) {
            case 'id':
            case 'status':
            case 'id_regras':
            case 'site':
            case 'ambiente':
            case 'plataforma':
            $sqlinicial[] = "{$indice} = :{$indice} ";
            break;     
          }

          $arrayBindValue[$indice] = $valor;
        }
      }
      if (array_key_exists('sistema', $parametros)) {
        $s = "sistema ilike '%{$parametros['sistema']}%'";
        $sql .= " and $s";
        unset($parametros['sistema']);
        unset($arrayBindValue['sistema']);
      }

      if (count($parametros) > 1 ) {
        $sql = $sql . ' AND '. implode(" AND ", $sqlinicial);
      }
        
      $statement = $db->prepare($sql);
      foreach ($arrayBindValue as $indice => $valor) {
        $statement->bindValue ( ":{$indice}", $valor);
      }
      
      $statement->execute();
      $registros = $statement->rowCount();
      $arrayRetorno = array();
      
      if ($registros == 0) {
        $array['info'] = "não foram encontrados resultados.";
        return $array;
        die;
      }
      $qtd_apache = 0;
      $amb = "";

      foreach ($statement as $row ) {
        
        $arraySistemas[] = array (
        'id' => $row['id'],
        'status' => $row['status'],
        'sistema' => $row['sistema'],
        'ambiente' => $row['ambiente'],
        'plataforma' => $row['plataforma'],
        'produto' => $row['produto'],
        'site' => $row['site'],
        'ipbackup' => $row['ipbackup'],
        'versao_plataforma' => $row['versao_plataforma'],
        'solicitacoes_id' => $row['solicitacoes_id'],
        'servidores_json' => json_decode($row['servidores_json'], true),
        'inclusao' => $row['data_inclusao']
        );
        if ($row['produto'] == 'apache')
          $qtd_apache++;
      }
    
      $arrayRetorno["registros"] = $registros;
      $arrayRetorno["dados"] = $arraySistemas;
      
      return $arrayRetorno;
      } catch ( Exception $e ) {
      $array = [];
      $array['erro'] = "erro execucao da query";
      Transaction::close ();
      return $array;
      } finally {
      Transaction::close ();
    }
  }

  function listarRegraError() {
    try {
      Transaction::open('database');
      $db = Transaction::get();

      $sql = "SELECT * from solicitacoes_id where id_mudanca isnull";


      $statement = $db->prepare($sql);
      
      $statement->execute();
      $registros = $statement->rowCount();
      $arrayResultado = array();
      $arrayResultado["registros"] = $registros;

      
      if ($registros == 0) {
        $array['info'] = "não foram encontrados resultados.";
        return $array;
        die;
      }
      
      foreach ($statement as $row ) {
        $arrayRetorno[] = array (
        'id' => $row['id'],
        'id_regras' => $row['id_regras'],
        'id_mudanca' => $row['id_mudanca'],
        'sistema' => $row['sistema'],
        'ambiente' => $row['ambiente'],
        'solicitante' => $row['solicitante'],
        'objeto_regra' => $row['json_regra'],
        'data_solicitacao' => $row['data_inclusao']);    

      }
      
      $arrayResultado["dados"] = $arrayRetorno;
      
      return $arrayResultado;
      } catch ( Exception $e ) {
        var_dump($e->getMessage());
        die();
      $array = [];
      $array['erro'] = "erro execucao da query";
      Transaction::close();
      return $array;
      } finally {
      Transaction::close();
      }
  }

  

  function listarContato($parametros) {
    
    try {
      Transaction::open('database');
      $db = Transaction::get();
      $arrayBindValue = [ ];
      $sql = "SELECT * from contato order by data_hora ";
      
      $statement = $db->prepare($sql);
      foreach ($arrayBindValue as $indice => $valor) {
        if ($indice != 'acao' && $indice != 'status')
          $statement->bindValue ( ":{$indice}", $valor );
      }

      $statement->execute();
      $registros = $statement->rowCount();
      $arrayRetorno = array();
      $arrayRetorno["registros"] = $registros;
      
      if ($registros == 0) {
        $array['info'] = "não foram encontrados resultados.";
        return $array;
        die;
      }
      
      foreach ($statement as $row ) {
        $arraySistemas[] = array (
        'id' => $row['id_contato'],
        'matricula' => $row['matricula'],
        'texto' => $row['texto'],
        'datahora' => $row['data_hora'],
        'tipo' => $row['tipo']
        );
      }
      
      $arrayRetorno["dados"] = $arraySistemas;
      
      return $arrayRetorno;
      } catch ( Exception $e ) {
      $array = [];
      $array['erro'] = "erro execucao da query";
      Transaction::close ();
      return $array;
      } finally {
      Transaction::close ();
    }
  } 

  
// listar comunidades pelo banco 

function listaBancoDadosQuestions()
{

  Transaction::open('database');
  $db = Transaction::get();

  $sql = "select * from tipo_backend where status = 'ativado' and caract = 'BANCO';";
  return $db->query($sql, PDO::FETCH_ASSOC)->fetchAll();
}


function listarSistemasAutoComplete($parametros) {
  try {
    Transaction::open('database');
    $db = Transaction::get();
    $param = '';
    
   

   
    $sql = "select distinct substring(si.modulo from 1 for 5) as sistema from solicitacoes_infra si
    inner join servidores s on si.modulo = s.sistema
    where si.status = 'ativado' and s.status = 'ativado'
    order by substring(si.modulo from 1 for 5)";

    $statement = $db->prepare($sql);

    $statement->execute();
    $registros = $statement->rowCount();
    $arrayResultado = array();
    $arrayResultado["registros"] = $registros;
    
    if ($registros == 0) {
      $array['info'] = "não foram encontrados resultados.";
      return $array;
      die;
    }

    foreach ($statement as $row ) {
      $arrayRetorno[] = $row['sistema'];
    }
    
    $arrayResultado["dados"] = $arrayRetorno;
    
    return $arrayResultado;
    } catch ( Exception $e ) {
    $array = [];
    $array['erro'] = "erro execucao da query";    
    return $array;
    } finally {
    Transaction::close ();
  }
}

function listaResourcesGroups()
{

  Transaction::open('database');
  $db = Transaction::get();

  $sql = "select * from tb_resources_group where status = 'ativo'";
  return $db->query($sql, PDO::FETCH_ASSOC)->fetchAll();
}


// listaSubscription

function listaSubscription()
{

  Transaction::open('database');
  $db = Transaction::get();

  $sql = "select * from tb_subscription where status = 'ativo'";
  return $db->query($sql, PDO::FETCH_ASSOC)->fetchAll();
}

function listaVNET_CLOUD()
{

  Transaction::open('database');
  $db = Transaction::get();

  $sql = "select * from tb_VNET_CLOUD where status = 'ativo'";
  return $db->query($sql, PDO::FETCH_ASSOC)->fetchAll();
}

function listarRequisicaoNuvemPublica() {


  try {
    Transaction::open('database');
    $db = Transaction::get();
   
    $sql = "select  *
    FROM tb_nuvem_publica as nv
    left join tb_requisicao req on nv.id = req.sistema_id
    where req.requisicao != '' and tipo_requisicao = 'NUVEM_PUBLICA' order by nv.id desc"; 
   
  
    $statement = $db->prepare($sql);
    $statement->execute();
    $arrayRetorno = array();

   

    foreach ($statement as $row =>  $sigla ) {


      $arraySigla[] = array(
          'id' => $sigla["id"], 
          'nome_vm' => $sigla['nome_vm'],
          'nome_projeto' => $sigla['nome_projeto'],
          'camada' => $sigla['camada'],
          'ambiente' => $sigla['ambiente'],
          'resource_group' => $sigla['resource_group'],
          'subscription' => $sigla['subscription'],
          'so' => $sigla['so'],
          'disco' =>$sigla['disco'],
          'capacidade' =>$sigla['capacidade'],
          'tamanho' =>$sigla['tamanho'],
          'requisicao' =>$sigla['requisicao'],
          'mensagem' =>$sigla['mensagem'],
          'data_criacao' =>$sigla['data_criacao'],
          
      );
      
    }

    $arrayRetorno["dados"] = $arraySigla;

    
    return $arrayRetorno;
    } catch ( Exception $e ) {
      var_dump($e->getMessage());
      die();
    $array = [];
    $array['erro'] = "erro execucao da query";
    Transaction::close ();
    return $array;
    } finally {
    Transaction::close ();
  }

}

function listarRequisicaoBancoDados($parametros) {
  try {
    Transaction::open('database');
    $db = Transaction::get();
    $whereSistema = "";

    if(isset($parametros['sistema'])) {
      $whereSistema = "and bd.sistema = '{$parametros['sistema']}' and bd.ambiente = '{$parametros['ambiente']}'";
    } 
   
    $sql = "select  *
    FROM banco_dados as bd
    left join tb_requisicao req on bd.id_banco_dados = req.sistema_id
    where req.requisicao != '' and tipo_requisicao = 'BANCO_DADOS'" . $whereSistema . " order by bd.id_banco_dados desc"; 
  
    $statement = $db->prepare($sql);
    $statement->execute();
    $arrayRetorno = array();

    $arrayBd = [];

    foreach ($statement as $row =>  $Bd ) {
      $arrayBd[] = array(
          'id' => $Bd["id_banco_dados"], 
          'sistema' => $Bd['sistema'],
          'ambiente' => $Bd['ambiente'],
          'instancia' => $Bd['nome_instancia'],
          'sgbd' => $Bd['sgbd'],
          'tamanhoInicial' => $Bd['tamanho_inicial'],
          'taxaCrescimento' => $Bd['taxa_crescimento'],
          'requisicao' =>$Bd['requisicao'],
          'mensagem' =>$Bd['mensagem'],
          'dataCriacao' =>$Bd['data_criacao'],
      );
      
    }

    $arrayRetorno["dados"] = $arrayBd;

    return $arrayRetorno;
    } catch ( Exception $e ) {
      var_dump($e->getMessage());
      die();
    $array = [];
    $array['erro'] = "erro execucao da query";
    Transaction::close ();
    return $array;
    } finally {
    Transaction::close ();
  }

}

function listarRouters() {
    
  try {
    Transaction::open('database');
    $db = Transaction::get();
    $arrayBindValue = [ ];
    $sql = "SELECT * from routers order by id_router ";
    
    $statement = $db->prepare($sql);
    $statement->execute();
    $registros = $statement->rowCount();
    $arrayRetorno = array();
    $arrayRetorno["registros"] = $registros;
    
    if ($registros == 0) {
      $array['info'] = "não foram encontrados resultados.";
      return $array;
      die;
    }
    
    foreach ($statement as $row ) {
      //recupera os ips
      $ips = array();
      $sql = "SELECT * FROM router_ips where id_router = {$row['id_router']}";
      $stmIps = $db->prepare($sql);
      $stmIps->execute();
      foreach ($stmIps as $key => $ip) {
        array_push($ips,$ip['ip']);
      }
      $arraySistemas[] = array (
      'id' => $row['id_router'],
      'nome' => $row['nome'],
      'cluster' => $row['cluster'],
      'ambiente' => $row['ambiente'],
      'tipo' => $row['tipo'],
      'porta' => $row['porta'],
      'ips' => $ips
      );
    }
    
    $arrayRetorno["dados"] = $arraySistemas;
    
    return $arrayRetorno;
    } catch ( Exception $e ) {
    $array = [];
    $array['erro'] = "erro execucao da query";
    Transaction::close ();
    return $array;
    } finally {
    Transaction::close ();
  }
}
