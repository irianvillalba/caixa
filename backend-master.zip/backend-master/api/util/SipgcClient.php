<?php
class SipgcClient {
    
    private $ch;
    private $endpoint;
    
    function __construct(String $endpoint)
    {
        $this->ch = curl_init();
        $this->endpoint = $endpoint;        
    }

    function __destruct()
    {
        $this->logoff();
    }

    
    public function logoff():bool {
        try{    
        curl_close($this->ch);        
        return true;
    }catch(Exception $e){
        return false;
    }
}

    public function getSipgcComunidade(int $id=null,int $carteira=null,int $capitulo=null,string $matricula=null,int $papel=null,string $tipo=null) {
        try{
         $path = "/comunidade";
         $params = array("id"=>$id,"carteira"=>$carteira,"capitulo"=>$capitulo,"matricula"=>$matricula,"papel"=>$papel,"tipo"=>$tipo);
        $queryString = http_build_query($params);
        if(strlen($queryString) > 0){
            $path .= "?".$queryString;
        }
        $options = array(
                    CURLOPT_URL =>  $this->endpoint . $path,
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_ENCODING => "",
                    CURLOPT_MAXREDIRS => 10,
                    CURLOPT_TIMEOUT => 5,
                    CURLOPT_FOLLOWLOCATION => true,
                    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                    CURLOPT_CUSTOMREQUEST => "GET",
                    CURLOPT_HTTPHEADER =>       array(
                        "Content-Type:application/json",                        
                    )
                );
                curl_setopt_array($this->ch, $options);
                $result = curl_exec($this->ch);
                if(curl_errno($this->ch)){
                    return  json_decode('{"error":"Falha ao executar o comando."}');
                }   
                
                $status = curl_getinfo($this->ch,CURLINFO_HTTP_CODE);
                switch ($status) {
                    case 200:                       
                       return json_decode($result);
                        break;                
                    default:
                        return json_decode('{"error":"Response code: '.$status.'"}');
                        break;
                }
        }catch(Exception $e){
            return json_decode('{"error":"'.$e->getMessage().'"}');
        }
        
    }

    public function getSiappSistema(string $sigla=null,string $apelido=null,string $descricao=null,string $objetivo=null,string $status=null,string $situacao=null,
    string $disponibilidade=null,string $categoria=null,string $contingencia=null,string $aglutinador=null,string $criticidadeAbrangencia=null,string $criticidadeAplicativo=null,
    string $criticidadeNegocio=null,string $criticidadeTecnica=null,string $gerenciaExecutiva=null,string $unidade=null,string $dataAlteracao=null,string $usuario=null) {
        try{
         $path = "/sistema";
        $params = array("sigla"=>$sigla,"apelido"=>$apelido,"descricao"=>$descricao,"objetivo"=>$objetivo,"status"=>$status,"situacao"=>$situacao,
        "disponibilidade"=>$disponibilidade,"categoria"=>$categoria,"contingencia"=>$contingencia,"aglutinador"=>$aglutinador,"criticidadeAbrangencia"=>$criticidadeAbrangencia,"criticidadeAplicativo"=>$criticidadeAplicativo,
        "criticidadeNegocio"=>$criticidadeNegocio,"criticidadeTecnica"=>$criticidadeTecnica,"gerenciaExecutiva"=>$gerenciaExecutiva,"unidade"=>$unidade,"dataAlteracao"=>$dataAlteracao,"usuario"=>$usuario);
        $queryString = http_build_query($params);
        if(strlen($queryString) > 0){
            $path .= "?".$queryString;
        }
        $options = array(
                    CURLOPT_URL =>  $this->endpoint .$path,
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_ENCODING => "",
                    CURLOPT_MAXREDIRS => 10,
                    CURLOPT_TIMEOUT => 5,
                    CURLOPT_FOLLOWLOCATION => true,
                    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                    CURLOPT_CUSTOMREQUEST => "GET",
                    CURLOPT_HTTPHEADER =>       array(
                        "Content-Type:application/json",                        
                    )
                );
                curl_setopt_array($this->ch, $options);
                $result = curl_exec($this->ch);
                if(curl_errno($this->ch)){
                    return  json_decode('{"error":"Falha ao executar o comando."}');
                }   
                
                $status = curl_getinfo($this->ch,CURLINFO_HTTP_CODE);
                switch ($status) {
                    case 200:                       
                       return json_decode($result);
                        break;                
                    default:
                        return json_decode('{"error":"Response code: '.$status.'"}');
                        break;
                }
        }catch(Exception $e){
            return json_decode('{"error":"'.$e->getMessage().'"}');
        }
        
    }
    
}