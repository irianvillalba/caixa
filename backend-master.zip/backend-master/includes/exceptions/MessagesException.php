<?php 
class MessagesException extends Exception {   

    public $messages = [
        0001=>"O sistema no  ambiente informado já possuiu uma solicitação de NFS."
    ];
    
}