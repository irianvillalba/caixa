<?php

function cadastrarNovidade($json_post){
    Transaction::open('database');
    try{
    $json_post_encoded = json_decode($json_post, true);    
    $db = Transaction::get();

    //verifica se existe uma novidade com o mesmo titulo
    $sql = "select * from novidades where titulo = '{$json_post_encoded['titulo']}'";
    $statement = $db->query($sql,PDO::FETCH_ASSOC);
    $count = 0;
    if($statement !== false){
        $count= $statement->rowCount();
    }
    if($count > 0 ){
        return Utils::apiReturn('erro',"Novidade já cadastrada com esse título.");
    }
    $sql = "INSERT INTO novidades (titulo,texto,data_publicacao) values('{$json_post_encoded['titulo']}','{$json_post_encoded['texto']}','{$json_post_encoded['data_publicacao']}')";
    $ret = $db->exec($sql);
    if($ret === false){
        return Utils::apiReturn('erro',"erro ao cadastrar a novidade!");
    }
    return Utils::apiReturn('sucesso',"Novidade cadastrada com sucesso!");
    }catch(Exception $e){
        Transaction::rollback();
        return Utils::apiReturn('erro',$e->getMessage());
    }finally {
    Transaction::close();  
    }
    
}

function alterarNovidade($json_post){
    Transaction::open('database');
    try{
    $json_post_encoded = json_decode($json_post, true);    
    $db = Transaction::get();

    //verifica se existe uma novidade com o mesmo titulo
    $sql = "select * from novidades where titulo = '{$json_post_encoded['titulo']}' and id != {$json_post_encoded['id']}";
    $statement = $db->query($sql,PDO::FETCH_ASSOC);
    $count = 0;
    if($statement !== false){
        $count= $statement->rowCount();
    }
    if($count > 0 ){
        return Utils::apiReturn('erro',"Novidade já cadastrada com esse título.");
    }
    $sql = "UPDATE novidades SET titulo = '{$json_post_encoded['titulo']}', texto = '{$json_post_encoded['texto']}', data_publicacao = '{$json_post_encoded['data_publicacao']}' WHERE id = '{$json_post_encoded['id']}'";
    $ret = $db->exec($sql);
    if($ret === false){
        return Utils::apiReturn('erro',"erro ao alterar a novidade!");
    }
    return Utils::apiReturn('sucesso',"Novidade alterada com sucesso!");
    }catch(Exception $e){
        Transaction::rollback();
        return Utils::apiReturn('erro',$e->getMessage());
    }finally {
    Transaction::close();  
    }
    
}

function excluirNovidade($paramentros){
    Transaction::open('database');
    try{
    $id = json_decode($paramentros['id'], true);    
    $db = Transaction::get();
    
    $sql = "DELETE FROM novidades  WHERE id = {$id}";
    $ret = $db->exec($sql);
    if($ret === false){
        return Utils::apiReturn('erro',"erro ao excluir a novidade!");
    }
    return Utils::apiReturn('sucesso',"Novidade excluída com sucesso!");
    }catch(Exception $e){
        Transaction::rollback();
        return Utils::apiReturn('erro',$e->getMessage());
    }finally {
    Transaction::close();  
    }
    
}

function listarNovidades(){
    Transaction::open('database');
    try{
    
    $db = Transaction::get();
    
    $sql = "select * from novidades order by data_publicacao desc";
    $registros = $db->query($sql,PDO::FETCH_ASSOC)->fetchAll();      
      return array("registros"=>count($registros), "dados"=>$registros);    
    
    }catch(Exception $e){
        Transaction::rollback();
        return Utils::apiReturn('erro',$e->getMessage());
    }finally {
    Transaction::close();  
    }
    
}

function listarNovidadesPaginada($parametros){
    Transaction::open('database');
    try{
    $i = $parametros['limit'];
    $f = $parametros['offset'];

    $db = Transaction::get();
    
    $sql = "select * from novidades where data_publicacao <= '".Date("Y/m/d")."' order by data_publicacao desc limit $i offset $f";
    $registros = $db->query($sql,PDO::FETCH_ASSOC)->fetchAll();      
      return array("registros"=>count($registros), "dados"=>$registros);    
    
    }catch(Exception $e){
        Transaction::rollback();
        return Utils::apiReturn('erro',$e->getMessage());
    }finally {
    Transaction::close();  
    }
    
}