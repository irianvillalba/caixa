<?php

class Servidor extends Record {
    
    const TABLENAME = 'servidores';
    
}
