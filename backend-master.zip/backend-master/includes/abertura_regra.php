<?php

//relacionamento dos tipos de backends que serão usados para abertura de regra
function relacionarSolicitacaoTipoBackend($id_solicitacao, $id_tipo_backend, $data_inclusao, $ambiente, $tipo="novo", $sid=0, $status = "pendente")
{
  try {
    Transaction::open('database');
    $solicitacoes_backends = new SolicitacoesTipoBackends();
    $solicitacoes_backends->id_solicitacao = $id_solicitacao;
    $solicitacoes_backends->id_tipo_backend = $id_tipo_backend;
    $solicitacoes_backends->data_inclusao = $data_inclusao;
    $solicitacoes_backends->ambiente = $ambiente;
    $solicitacoes_backends->status = $status;
    $solicitacoes_backends->tipo = $tipo;
    $solicitacoes_backends->solicitacoes_id = $sid;
    $solicitacoes_backends->store();
  } catch (Exception $e) {
    $array_json["retorno"]["status"] = "erro";
    $array_json["retorno"]["mensagem"] = "Erro ao criar solicitacao. Descrição: {$e->getMessage()}";
  } finally {
    Transaction::close();
  }
}

//relacionamento dos backends escolhidos para a abertura de regra
function relacionarBackend($json, $id_solicitacao)
{

  $mensagem = "xxx";
  Transaction::open('database');
  $db = Transaction::get();
  try {
    foreach ($json as $info) {

      $dt_inclusao = date('Y-m-d H:i:s');

      $db->exec("insert into solicitacoes_backends 
            (id_solicitacoes_tipo_backends, id_backend, solicitacoes_id, data_inclusao) values 
            ({$info['stb_id']},{$info['bck_id']}, {$id_solicitacao}, '{$dt_inclusao}')");

            $mensagem = "Relacionamento realizado.";
            http_response_code(201);
          }

        } catch (Exception $e) {
          $mensagem = "Descricao: {$e->getMessage()}";
        } finally {
          Transaction::close();
      }
    return($mensagem);
}  

function formularioObjeto($post = '') {
  $dt_cadastro = date('Y-m-d H:i:s');
  $endpointFormulario = endpoint_regrasbr."/AlteracaoObjetoNetwork";
  $dados = json_decode($post, true);
  $curl = curl_init($endpointFormulario);
  Transaction::open('database');
  $db = Transaction::get();

  curl_setopt($curl, CURLOPT_POST, 1);
  curl_setopt($curl, CURLOPT_SSL_VERIFYHOST,0);
  curl_setopt($curl, CURLOPT_SSL_VERIFYPEER,0);
  curl_setopt($curl, CURLOPT_USERPWD, usuario_mudanca.":".senha_usuario_mudanca);
  curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-Type: application/json')); 
  curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, 30);
  curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($curl, CURLOPT_FOLLOWLOCATION, 0);
  
  if ($dados['ambiente'] == 'prd')
    $ambienteObjeto = 'PRD';
  else
    $ambienteObjeto = 'NPRD';

  foreach($dados['backends'] as $bck) {
    $tipo = str_replace(' ', '_', $bck['tipo']);
    $objeto = "{$dados['sistema']}_{$bck['ambiente']}_{$tipo}_backend";
    $obj = APIRegras('{
          "registro": {
          "objeto": "'.$objeto.'"
          },
          "acao": "ListarObjetoNetworkNome"
      }');

    if ($obj->success == 'true') {
      echo "atualizar objeto \n";
    }
    else {
      echo "criar objeto \n";
    }


    $ips = explode(',', $bck['ip']);
    $d = array();
    foreach($ips as $i) {
      array_push($d, array("Tipo" => "HOST", "IP" => $i));
    }

    /*$formulario = array(
      "AmbienteObjeto" =>       $ambienteObjeto,
      "CaixaPostal" =>          "CETAD02",
      "Unidade" =>              "CETAD",
      "Justificar" =>           "Solicitação feita pelo infradevops",
      "MatriculaGestor" =>      $dados['matrResponsavel'],
      "Gestor" =>               "a",
      "MatriculaResponsavel" => $dados['matrResponsavel'],
      "Responsavel" =>          "b",
      "MatriculaSolicitante" => $dados['matrSolicitante'],
      "Solicitante" =>          "c",
      "Objeto" =>               $objeto,
      "Sistema" =>              $dados["sistema"],
      "usuario" =>              usuario_regrasbr,
      "senha" =>                senha_usuario_regrasbr,
      "Dados" =>                $d
    );

    $form = json_encode($formulario);

    curl_setopt($curl, CURLOPT_POSTFIELDS, $form);
    
    //Execute the request
    $res = curl_exec($curl);
    $retorno = preg_replace('/[\x00-\x1F\x80-\xFF]/', '', $res);
    
    $ret = json_decode($retorno);

    $retorno = mudancaObjeto($ret->id);
    
    //guarda o id das regras para a solicitação
    $sql = "INSERT INTO solicitacoes_id (id_regras, id_mudanca, data_inclusao) values ('{$retorno->Retorno->NumeroPedido}','{$retorno->Retorno->NumeroMudanca}',  '{$dt_cadastro}')";
    $res = $db->exec($sql);

    $res = $db->query("select max(id) as id from solicitacoes_id",PDO::FETCH_ASSOC)->fetch(); 

     //atualiza solicitante
     $db->exec("UPDATE solicitacoes_infra SET solicitante = '{$json_post_decoded["dados"]["matricula_regra"]}' where id = {$json_post_decoded["dados"]['id']}");*/
  }
}
//montagem do formulário para alteração do objeto de regra
function formularioObjetoOrigem($post = '')
{
  $dt_cadastro = date('Y-m-d H:i:s');
  
  $endpointFormulario = endpoint_regrasbr."/AlteracaoObjetoNetwork";
  $dados = json_decode($post, true);
  $curl = curl_init($endpointFormulario);
  Transaction::open('database');
  $db = Transaction::get();

  curl_setopt($curl, CURLOPT_POST, 1);
  curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 0);
  curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);
  curl_setopt($curl, CURLOPT_USERPWD, usuario_mudanca.":".senha_usuario_mudanca);
  curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
  curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, 30);
  curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($curl, CURLOPT_FOLLOWLOCATION, 0);

  if ($dados['ambiente'] == 'prd')
    $ambienteObjeto = 'PRD';
  else
    $ambienteObjeto = 'NPRD';

  $info_origem = alocaIP(json_encode(['caminho' => 'ConsultarRede', 'ip' => $dados['ip']]));
  $camada = strtoupper(substr($info_origem['data']['Classificacao'][0]["Ambiente"], 0, 4));
  $vertical = strtoupper(substr($info_origem['data']['Classificacao'][0]["Vertical"], 0, 4));
  $objeto_origem = strtoupper("{$dados['sistema']}_{$dados['ambiente']}_servidor_{$camada}_{$vertical}");

  $obj = APIRegras('{
    "registro": {
    "objeto": "' . $objeto_origem . '"
    },
    "acao": "ListarObjetoNetworkNome"
  }');

  if ($obj->success == 'true') {
    $d = array();
    array_push($d, array("Tipo" => "HOST", "IP" => $dados['ip']));

    $formulario = array(
        "AmbienteObjeto" =>       $ambienteObjeto,
        "CaixaPostal" =>          "CETAD02",
        "Unidade" =>              "CETAD",
        "Justificar" =>           "Solicitação feita pelo infradevops",
        "MatriculaGestor" =>      $dados['matrResponsavel'],
        "Gestor" =>               "a",
        "MatriculaResponsavel" => $dados['matrResponsavel'],
        "Responsavel" =>          "b",
        "MatriculaSolicitante" => $dados['matrSolicitante'],
        "Solicitante" =>          "c",
        "Objeto" =>               $objeto_origem,
        "Sistema" =>              $dados["sistema"],
        "usuario" =>              usuario_regrasbr,
        "senha" =>                senha_usuario_regrasbr,
        "Dados" =>                $d
      );

      $form = json_encode($formulario);

      curl_setopt($curl, CURLOPT_POSTFIELDS, $form);
      
      //Execute the request
      $res = curl_exec($curl);
      $retorno = preg_replace('/[\x00-\x1F\x80-\xFF]/', '', $res);
      
      $ret = json_decode($retorno);

      $retorno = mudancaObjeto($ret->id);
      
      //guarda o id das regras para a solicitação
      $sql = "INSERT INTO solicitacoes_id (id_regras, id_mudanca, data_inclusao) values ('{$retorno->Retorno->NumeroPedido}','{$retorno->Retorno->NumeroMudanca}',  '{$dt_cadastro}')";
      $res = $db->exec($sql);   
  } else {
    echo "Objeto de Origem não existe no regras.cetad";
  }
 
}


//solicitação da abertura da mudança de acordo com o formulário de alteração do objeto enviado
function mudancaObjeto($numeroFormulario)
{
  $endpointMudanca = endpoint_regrasbr."/CriaFormularioMudancaObjeto";

  $curl = curl_init($endpointMudanca);

  $formulario = array(
    "usuario" => usuario_regrasbr,
    "senha" => senha_usuario_regrasbr,
    "numero_formulario" => $numeroFormulario,
    "nome" => "Contato Para testes",
    "telefone" => "1111-11111"
  );

  $form = json_encode($formulario);

  curl_setopt($curl, CURLOPT_POST, 1);
  curl_setopt($curl, CURLOPT_POSTFIELDS, $form);
  curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 0);
  curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);
  curl_setopt($curl, CURLOPT_USERPWD, usuario_mudanca.":".senha_usuario_mudanca);
  curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
  curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, 30);
  curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($curl, CURLOPT_FOLLOWLOCATION, 0);

  //Execute the request
  $res = curl_exec($curl);
  $retorno = preg_replace('/[\x00-\x1F\x80-\xFF]/', '', $res);

  return json_decode($retorno);
}

//solicitação de criação do formulários de regras no regras.cetad.caixa
function postAPIRegras($endpoint, $payload)
{

  Transaction::open('database');
  $db = Transaction::get();
  $curl = curl_init($endpoint);
  $ambienteObjeto = "";
  $objetos = array();
  $adicionar = array();
  $info_origem = alocaIP(json_encode(['caminho' => 'ConsultarRede', 'ip' => $payload['origem'][0]]));
  $camada = strtoupper(substr($info_origem['data']['Classificacao'][0]["Ambiente"], 0, 4));
  $vertical = strtoupper(substr($info_origem['data']['Classificacao'][0]["Vertical"], 0, 4));
  $objeto_origem = strtoupper("{$payload['sistema']['sistema']}_{$payload['sistema']['ambiente']}_servidor_{$camada}_{$vertical}");


  if ($payload['sistema']['ambiente'] == 'prd')
    $ambienteObjeto = 'PRD';
  else
    $ambienteObjeto = 'NPRD';

  //informações de abertura de regra para o formulário
  $formulario['objeto'] = array("usuario" => usuario_regrasbr, "senha" => senha_usuario_regrasbr);
  $formulario['objeto']['regra'] =
    array(
      "matriculaMudanca" => "USR_CETADPOR1",
      "matriculaSolicitacao" => $payload["usuario"]["matricula"],
      "matriculaGestorRegra" => $payload["usuario"]["matricula_regra"],
      "justificativa" => "Solicitação de regras através do portal infradevops",
      "tipoFormulario" => "incluir",
      "unidade" => "CETAD"
    );

  //ips a serem adicionados como objeto de origem

  foreach ($payload['origem'] as $origem) {
    $objOrigem = [
      "tipo" => "Network",
      "ambienteObjeto" => $ambienteObjeto,
      "objeto" => $objeto_origem,
      "ip" => $origem,
      "mascara" => "32",
      "camadaObjeto" => $info_origem['data']['Classificacao'][0]["Ambiente"],
      "verticalObjeto" => $info_origem['data']['Classificacao'][0]["Vertical"]
    ];
    array_push($adicionar, $objOrigem);
  }

  //cria objetos de destino (ip e porta) a serem adicionados
  $x = 0;
  foreach ($payload['destino'] as $c => $v) {
    $token = strtoupper(substr(bin2hex(random_bytes(3)), 1));
    $objeto_destino = str_replace(' ', '_', strtoupper("{$payload["sistema"]["sistema"]}_{$payload['sistema']['ambiente']}_{$c}_{$token}_backend"));
    $objeto_porta = str_replace(' ', '_', strtoupper("SVC_{$c}"));
    //$objeto_porta = strtoupper("SVC_{$c}");  
    $x++;
    array_push($objetos, [
      "objetoOrigem" => $objeto_origem,
      "objetoDestino" => $objeto_destino,
      "objetoService" => $objeto_porta,
      "linha" => $x
    ]);

    foreach ($v['ip'] as $ip) {
      $info_destino = alocaIP(json_encode(['caminho' => 'ConsultarRede', 'ip' => $ip]));
      $objDestino = [
        "tipo" => "Network",
        "ambienteObjeto" => $ambienteObjeto,
        "objeto" => $objeto_destino,
        "ip" => $ip,
        "mascara" => "32",
        "camadaObjeto" => $info_destino['data']['Classificacao'][0]["Ambiente"],
        "verticalObjeto" => $info_destino['data']['Classificacao'][0]["Vertical"]
      ];
      array_push($adicionar, $objDestino);
    }

    foreach ($v['porta'] as $porta) {
      $objPorta = [
        "tipo" => "Service",
        "protocolo" => 'TCP',
        "objeto" => $objeto_porta,
        "portaInicial" => $porta,
        "portaFinal" => ""
      ];
      array_push($adicionar, $objPorta);
    }
  }

  $dados = array();
  $dados['dados'] = $objetos;

  $formulario['objeto']['regra']['dados'] = $dados['dados'];
  $formulario['objeto']['adiciona'] = $adicionar;

  $form = json_encode($formulario);

  setLog('FormularioObjetoEnvio', 'C000000', $form, 'POST');

  curl_setopt($curl, CURLOPT_POST, 1);
  curl_setopt($curl, CURLOPT_POSTFIELDS, $form);
  curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 0);
  curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);
  curl_setopt($curl, CURLOPT_USERPWD, usuario_mudanca.":".senha_usuario_mudanca);
  curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
  curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, 30);
  curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($curl, CURLOPT_FOLLOWLOCATION, 0);

  //Execute the request
  $res = curl_exec($curl);

  $retorno = preg_replace('/[\x00-\x1F\x80-\xFF]/', '', $res);
  setLog('FormularioObjetoRetorno', 'C000000', $retorno, 'POST');
  $ret = json_decode($retorno);
  $ret->objetoregra = $form;
  return $ret;
}

//criação do formulário e atualização do portal com as informações do regras.cetad.caixa
function criarFormularioRegras($json_post = "")
{

  $json_post_decoded = json_decode($json_post, true);
  $json_post_decoded["data_solicitacao"] = date('Y-m-d H:i:s');

  Transaction::open('database');
  $db = Transaction::get();

  //retorna o número do formulário da API do regras.cetad
  $retorno = postAPIRegras(endpoint_regrasbr."/GravaFormulario", $json_post_decoded);

  if ($retorno->success) {

    $mudanca = solicitarMudanca($retorno->data->pedido);

    //$mudanca['Retorno']['NumeroMudanca']="CRQ000000101111";

    if (isset($mudanca['Retorno']['NumeroMudanca'])) {
      //caso retorne o número da mudança do GSC
      $crq = $mudanca['Retorno']['NumeroMudanca'];
      $retorno->crq = $crq;

      //guarda o id das regras e a mudança(CRQ) para a solicitação
      $sql = "INSERT INTO solicitacoes_id (id_regras, id_mudanca, data_inclusao, sistema, solicitante, ambiente) values ('{$retorno->data->pedido}', '{$crq}', '{$json_post_decoded["data_solicitacao"]}', '{$json_post_decoded["sistema"]["sistema"]}', '{$json_post_decoded["usuario"]["matricula_regra"]}', '{$json_post_decoded["sistema"]["ambiente"]}')";
      $res = $db->exec($sql);

      $res = $db->query("select max(id) as id from solicitacoes_id", PDO::FETCH_ASSOC)->fetch();

      //atualiza servidor com o id da solicitação executada
      $db->exec("UPDATE servidores SET solicitacoes_id={$res['id']} 
        WHERE sistema ilike '%{$json_post_decoded["sistema"]["sistema"]}%' and status = 'ativado' and 
        ambiente ='{$json_post_decoded["sistema"]["ambiente"]}' and solicitacoes_id is null 
        and plataforma = '{$json_post_decoded["sistema"]["plataforma"]}'");

      //criação de solicitacoes dos tipos de backends (tabela: solicitacoes_tipo_backend) em todos os modulos do sistema
      $sql = "select distinct si.id from solicitacoes_infra si 
        inner join servidores s on s.sistema = si.modulo
        where si.modulo ilike '%{$json_post_decoded["sistema"]["sistema"]}%' and si.status = 'ativado' 
        and s.status = 'ativado' and si.ambiente = '{$json_post_decoded["sistema"]["ambiente"]}' 
        and s.plataforma = '{$json_post_decoded["sistema"]["plataforma"]}'";

      $mod = $db->query($sql, PDO::FETCH_ASSOC)->fetchAll();

      foreach ($mod as $m) {
        foreach ($json_post_decoded['tipo_ids'] as $t)
        relacionarSolicitacaoTipoBackend(
            $m['id'],
            $t,
            $json_post_decoded["data_solicitacao"],
            $json_post_decoded["sistema"]["ambiente"],
            'novo',
            $res['id'],
            "relacionado"
          );
      }

      //criação das solicitações de backend (tabela: solicitacoes_backends) em todos os modulos
      $bck = implode(",", $json_post_decoded['destino_ids']);

      $sql = "select b.id bck_id, stb.id as stb_id from backends b 
        inner join solicitacoes_tipo_backends stb on stb.id_tipo_backend = b.tipo
        inner join solicitacoes_infra si on si.id = stb.id_solicitacao
        where b.id in ({$bck}) and si.modulo ilike '%{$json_post_decoded["sistema"]["sistema"]}%'  and stb.status = 'relacionado' and stb.tipo = 'novo'";
      $stb = $db->query($sql, PDO::FETCH_ASSOC)->fetchAll();

      relacionarBackend($stb, $res['id']);
    } else {
      $sql = "INSERT INTO solicitacoes_id (id_regras, data_inclusao, sistema, solicitante, ambiente, json_regra) 
        values ('{$retorno->data->pedido}', '{$json_post_decoded["data_solicitacao"]}', '{$json_post_decoded["sistema"]["sistema"]}', '{$json_post_decoded["usuario"]["matricula_regra"]}', '{$json_post_decoded["sistema"]["ambiente"]}','{$retorno->objetoregra}')";
      $res = $db->exec($sql);
      $crq = "CRQ000000101111";
    }
  } else {
    $sql = "INSERT INTO solicitacoes_id (data_inclusao, sistema, solicitante, ambiente) values ('{$json_post_decoded["data_solicitacao"]}', '{$json_post_decoded["sistema"]["sistema"]}', '{$json_post_decoded["usuario"]["matricula_regra"]}', '{$json_post_decoded["sistema"]["ambiente"]}')";
    $res = $db->exec($sql);
    $retorno->crq = "vazio";
  }
  Transaction::close();
  return $retorno;
}

//solicitação da mudança com o formulário gerado
function solicitarMudanca($num_formulario)
{

  $endpoint = endpoint_mudanca.'/CriaFormularioMudanca';

  $post_string = '{"numero_formulario":"' . $num_formulario . '"}';

  $curl = curl_init($endpoint);

  //Tell cURL that we want to send a POST request.
  curl_setopt($curl, CURLOPT_POST, 1);

  //Attach our encoded JSON string to the POST fields.
  curl_setopt($curl, CURLOPT_POSTFIELDS, $post_string);

  curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 0);
  curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);
  curl_setopt($curl, CURLOPT_USERPWD, usuario_mudanca.":".senha_usuario_mudanca);

  curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));

  curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, 30);

  curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
  curl_setopt($curl, CURLOPT_FOLLOWLOCATION, 1);

  //Execute the request
  $result = curl_exec($curl);
  $retorno = preg_replace('/[\x00-\x1F\x80-\xFF]/', '', $result);
  $json_mudanca = json_decode($retorno, true);

  Transaction::open('database');
  $db = Transaction::get();

  return $json_mudanca;
}

function adicionarSolicitacaoBackend($json)
{
  try {
    $array_json = json_decode($json, true);
    $array_json["data_solicitacao"] = date('Y-m-d H:i:s');

    foreach ($array_json['backends'] as $bck) {
      relacionarSolicitacaoTipoBackend($array_json["id_solicitacao"], $bck, $array_json["data_solicitacao"], $array_json["ambiente"], "adicional");
    }

    $arrayResultado["dados"] = "";

    return $arrayResultado;
  } catch (Exception $e) {
    $array = [];
    $array['erro'] = "erro execucao da query";
    Transaction::close();
    return $array;
  } finally {
    Transaction::close();
  }
}

//consulta a API de regras.cetad
function APIRegras($json)
{
  
  $dados = json_decode($json, true);

  $post  = json_encode($dados['registro']);

  $curl = curl_init();

  curl_setopt_array($curl, array(
    CURLOPT_URL => endpoint_regrasbr ."/". $dados['acao'],
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => "",
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 0,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => "POST",
    CURLOPT_POSTFIELDS => $post,
    CURLOPT_HTTPHEADER => array(
      "Authorization: Basic ".usuario_regrasbr.":".senha_usuario_regrasbr,
      "Content-Type: application/json",
    ),
  ));

  $response = curl_exec($curl);

  curl_close($curl);
  $retorno = preg_replace('/[\x00-\x1F\x80-\xFF]/', '', $response);
  return json_decode($retorno);
}

//consulta a API do alocaip
function alocaIP($json)
{
  $json_post = json_decode($json, true);
  $dt_cadastro = date('Y-m-d H:i:s');

     $endpoint = endpoint_mudanca.'/' . $json_post['caminho'];
    
    $curl = curl_init($endpoint);


    curl_setopt_array($curl, array(
      CURLOPT_URL => $endpoint,
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_ENCODING => '',
      CURLOPT_MAXREDIRS => 10,
      CURLOPT_TIMEOUT => 0,
      CURLOPT_FOLLOWLOCATION => true,
      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
      CURLOPT_CUSTOMREQUEST => 'POST',
      CURLOPT_POSTFIELDS => $json,
      CURLOPT_HTTPHEADER => array('Content-Type: application/json')
    ));

    //Execute the request
    $result = curl_exec($curl);
    $retorno = preg_replace('/[\x00-\x1F\x80-\xFF]/', '', $result);


    $resultado = json_decode($retorno, true);

    if (!isset($resultado)) {
      $resultado = [
        "title" => 'ERRO',
        "text" => 'Não é possível Solicitar o VIP, pois existe um erro na cominicação da api, Tente Novamente mais tarde'
      ];

      return $resultado;
    }

    if (isset($resultado['success'])) {
      if ($resultado['success'] == "false") {
        $resultado = [
          "title" => 'ERRO',
          "text" => 'Retorno "ApiAlocaIP" , ' . $resultado['data']
        ];

        return $resultado;
      }

      if (isset($resultado['success']) == "true") {
        if ($json_post['caminho'] == 'AlocarVIP') {

          Transaction::open('database');
          $db = Transaction::get();
          try {

            $sql = "INSERT INTO vip (id_solicitacao, site, ambiente, vertical, unidade, ip, ip10, mascara, data_cadastro, sistema , tipo) VALUES
          ({$json_post['idsol']}, '{$json_post['site']}', '{$json_post['ambiente']}' ,'{$json_post['vertical']}','{$json_post['unidade']}', '{$resultado['Gerar'][0]}', '{$resultado['Gerar'][1]}', '{$resultado['Gerar'][2]}', '{$dt_cadastro}' , '{$json_post['sistema']}' , '{$json_post['tipo']}')";
            $db->exec($sql);
          } catch (Exception $e) {
            $resultado = [
              "title" => 'ERRO',
              "text" => "Erro na execução de query em banco: {$e->getMessage()}"
            ];
            Transaction::close();
            return $resultado;
          } finally {
            Transaction::close();
          }
        }

        return $resultado;
      }
    }
  
}


function verde($json)
{


  
  Transaction::open('database');
  $db = Transaction::get();
  $res = $db->query("select id, id_regras from solicitacoes_id where sistema is null and id_regras is not null", PDO::FETCH_ASSOC);
  foreach ($res as $reg) {
    $str = '{
        "usuario": "'.usuario_regrasbr.'",
        "senha": "'.senha_usuario_regrasbr.'",
        "idFormulario": ' . $reg['id_regras'] . '
      }';

    $curl = curl_init();

    curl_setopt_array($curl, array(
      CURLOPT_URL => endpoint_regrasbr . "/ConsultarFormulario",
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_ENCODING => "",
      CURLOPT_MAXREDIRS => 10,
      CURLOPT_TIMEOUT => 0,
      CURLOPT_FOLLOWLOCATION => true,
      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
      CURLOPT_CUSTOMREQUEST => "POST",
      CURLOPT_POSTFIELDS => $str,
      CURLOPT_HTTPHEADER => array(
        "Authorization: Basic ".usuario_regrasbr.":".senha_usuario_regrasbr,
        "Content-Type: application/json",
      ),
    ));

    $response = curl_exec($curl);

    curl_close($curl);
    $retorno = strtolower(preg_replace('/[\x00-\x1F\x80-\xFF]/', '', $response));
    $obj = json_decode($retorno, true);
    if (isset($obj['data']['regra'][0])) {
      $origem = explode('_', $obj['data']['regra'][0]["hostnameorigem"]);
      $sis = substr($origem[0], 0, 5);
      if (isset($origem[1]))
        if (strlen($origem[1]) == 3) {
          echo "{$reg['id']} {$sis} - {$origem[1]} \n";
          $sql = "UPDATE solicitacoes_id SET sistema = '{$sis}', ambiente = '{$origem[1]}', solicitante = 'c000000' where id = {$reg['id']}";
          $db->exec($sql);
        }
    }
  }
  Transaction::close();
}
