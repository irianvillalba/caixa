<?php
class NegocioException extends MessagesException {

    
    public function __construct($code=0,Throwable $previous = null){
        parent::__construct($this->messages[$code],$code,$previous);
    }
    
    public function __toString(): string
    {
        return __CLASS__.":[{$this->code}]: {$this->message}\n";
    }
    
}