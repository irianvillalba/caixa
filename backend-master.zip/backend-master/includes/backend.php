<?php
function cadastrarBackend($json_post)
{

  $json_post_encoded["dados"] = json_decode($json_post, true);
  $json_post_encoded["dados"]["data_cadastro"] = date('Y-m-d H:i:s');
  $json_post_encoded["dados"]["status"] = "ativado";

  try {
    Transaction::open('database');
    $criteria = new Criteria();
    $criteria->add(new Filter('nome', '=', $json_post_encoded["dados"]["nome"]));
    $criteria->add(new Filter('status', '=', 'ativado'));
    $criteria->add(new Filter('ambiente', '=', $json_post_encoded["dados"]["ambiente"]));
    $backend = Backend::all($criteria);
    if ((empty($backend)) or ($backend === NULL)) {

      $backend = new Backend();
      $backend->nome = $json_post_encoded["dados"]["nome"];
      $backend->tipo = $json_post_encoded["dados"]["tipo"];
      $backend->ambiente = $json_post_encoded["dados"]["ambiente"];
      $backend->ip = $json_post_encoded["dados"]["ip"];
      $backend->porta = $json_post_encoded["dados"]["porta"];
      $backend->servidores = $json_post_encoded["dados"]["servidores"];
      $backend->data_cadastro = $json_post_encoded["dados"]["data_cadastro"];
      $backend->status = $json_post_encoded["dados"]["status"];
      $backend->matricula = $json_post_encoded["dados"]["matricula"];
      $backend->store();

      $json_post_encoded["retorno"]["status"] = "sucesso";
      $json_post_encoded["retorno"]["mensagem"] = "cadastro realizado com sucesso!";
      http_response_code(201);
    } else {
      $json_post_encoded["retorno"]["status"] = "erro";
      $json_post_encoded["retorno"]["mensagem"] = "Erro ao salvar: item já cadastrado na base!";
    }
  } catch (Exception $e) {
    $json_post_encoded["retorno"]["status"] = "erro";
    $json_post_encoded["retorno"]["mensagem"] = "Erro ao salvar o item. Descrição: {$e->getMessage()}";
  } finally {
    Transaction::close();
  }

  return ($json_post_encoded);
}

function editarBackend($json_post)
{

  $json_post_encoded["dados"] = json_decode($json_post, true);
  $json_post_encoded["dados"]["data_cadastro"] = date('Y-m-d H:i:s');

  try {
    Transaction::open('database');
    $db = Transaction::get();

    if (is_numeric($json_post_encoded['dados']['tipo']))
      $tipo = "tipo = '{$json_post_encoded['dados']['tipo']}',";
    else
      $tipo = "";

    $db->exec("UPDATE backends SET 
      nome = '{$json_post_encoded['dados']['nome']}',
      $tipo
      ambiente = '{$json_post_encoded['dados']['ambiente']}',
      status = '{$json_post_encoded['dados']['status']}',
      ip = '{$json_post_encoded['dados']['ip']}',
      porta = '{$json_post_encoded['dados']['porta']}',
      servidores = '{$json_post_encoded['dados']['servidores']}'
      where id = {$json_post_encoded['dados']['id']}");

    $json_post_encoded["retorno"]["status"] = "sucesso";
    $json_post_encoded["retorno"]["mensagem"] = "cadastro realizado com sucesso!";
    http_response_code(201);
  } catch (Exception $e) {
    $json_post_encoded["retorno"]["status"] = "erro";
    $json_post_encoded["retorno"]["mensagem"] = "Erro ao salvar o item. Descrição: {$e->getMessage()}";
  } finally {
    Transaction::close();
  }

  return ($json_post_encoded);
}

function cadastrarTipo($json_post)
{

  $json_post_encoded["dados"] = json_decode($json_post, true);
  $json_post_encoded["dados"]["data_inclusao"] = date('Y-m-d H:i:s');

  try {
    Transaction::open('database');
    $criteria = new Criteria();
    $criteria->add(new Filter('tipo', '=', $json_post_encoded["dados"]["tipo"]));
    $tipo = Tipo::all($criteria);
    if ((empty($plataforma)) or ($tipo === NULL)) {

      $tipo = new Tipo();
      $tipo->tipo = $json_post_encoded["dados"]["tipo"];
      $tipo->portas = $json_post_encoded["dados"]["portas"];
      $tipo->data_inclusao = $json_post_encoded["dados"]["data_inclusao"];
      $tipo->status = "ativado";
      $tipo->store();

      $json_post_encoded["retorno"]["status"] = "sucesso";
      $json_post_encoded["retorno"]["mensagem"] = "cadastro realizado com sucesso!";
      http_response_code(201);
    } else {
      $json_post_encoded["retorno"]["status"] = "erro";
      $json_post_encoded["retorno"]["mensagem"] = "item já cadastrado na base!";
    }
  } catch (Exception $e) {
    $json_post_encoded["retorno"]["status"] = "erro";
    $json_post_encoded["retorno"]["mensagem"] = "Erro salvar o item. Descrição: {$e->getMessage()}";
  } finally {
    Transaction::close();
  }

  return ($json_post_encoded);
}

function atualizarBackend($json)
{

  $arrayJson = json_decode($json, true);

  $nome = $arrayJson['nome'];

  try {
    Transaction::open('database');
    $criteria = new Criteria();
    $criteria->add(new Filter('nome', '=', $nome));
    $backend_criteria = Backend::all($criteria);

    if ((empty($backend_criteria)) or ($backend_criteria === NULL)) {
      $mensagem = "O backend com nome {$arrayJson["nome"]} não foi encontrado.";
      http_response_code(400);
    } else {
      $backend = $backend_criteria[0];

      foreach ($arrayJson as $chave => $valor) {

        switch ($chave) {
          case 'ip':
          case 'porta':
          case 'servidores':
          case 'descricao':
            $backend->$chave = $valor;
            break;
        }
      }
      $backend->data_atualizacao = date('Y-m-d H:i:s');
      $backend->store();
      $mensagem = "Informacoes atualizadas para o backend {$nome}.";
      http_response_code(201);
    }
  } catch (Exception $e) {
    $mensagem = "Ao gravar dados do Host: {$nome}. Descricao: {$e->getMessage()}";
  } finally {
    Transaction::close();
  }

  return ($mensagem);
}

function removerBackend($json)
{

  $arrayJson = json_decode($json, true);

  $id = $arrayJson['id'];
  $nome = $arrayJson['nome'];

  try {
    Transaction::open('database');
    $criteria = new Criteria();
    $criteria->add(new Filter('id', '=', $id));
    $backend_criteria = Backend::all($criteria);

    if ((empty($backend_criteria)) or ($backend_criteria === NULL)) {
      $mensagem = "O backend com nome {$arrayJson['nome']} não foi encontrado.";
      http_response_code(400);
    } else {
      $backend = $backend_criteria[0];
      $backend->status = "desativado";
      $backend->data_atualizacao = date('Y-m-d H:i:s');
      $backend->store();
      $mensagem = "O backend {$nome} foi desabilitado.";
      http_response_code(201);
    }
  } catch (Exception $e) {
    $mensagem = "Ao gravar dados do Host: {$nome}. Descricao: {$e->getMessage()}";
  } finally {
    Transaction::close();
  }

  return ($mensagem);
}

function removerBackendAdicional($json)
{

  $arrayJson = json_decode($json, true);
  $nome = "";

  try {
    Transaction::open('database');
    $db = Transaction::get();
    $db->exec("delete from solicitacoes_tipo_backends where id = {$arrayJson['id']}");
    $mensagem = "backend adicional excluido";
  } catch (Exception $e) {
    $mensagem = "Ao gravar dados do Host: {$nome}. Descricao: {$e->getMessage()}";
  } finally {
    Transaction::close();
  }

  return ($mensagem);
}

function removerTipo($json)
{

  $arrayJson = json_decode($json, true);

  $id = $arrayJson['id'];
  $nome = $arrayJson['tipo'];

  try {
    Transaction::open('database');
    $db = Transaction::get();
    $db->exec("delete from tipo_backend where id = {$id}");
    $mensagem = "tipo excluido com sucesso";
  } catch (Exception $e) {
    $mensagem = "Ao excluir o servidor: {$nome}. Descricao: {$e->getMessage()}";
  } finally {
    Transaction::close();
  }

  return ($mensagem);
}

function solicitarWOBackend($json)
{
  try {
    Transaction::open('database');
    $db = Transaction::get();
    $wo = new WO("hmp");

    //formatando dados para a WO
    $array_json = json_decode($json, true);
    $array_json["data_solicitacao"] = date('Y-m-d H:i:s');
    $objeto_porta = strtoupper("\"{$array_json["sistema"]}_{$array_json["ambiente"]}\"");
    $objeto_destino = strtoupper("\"{$array_json["sistema"]}_{$array_json["ambiente"]}_backend\"");
    $ip = "";
    $porta = "";
    foreach ($array_json['backends'] as $bck) {
      $ip .= "{$bck['ip']}, ";
      $porta .= "{$bck['porta']}, ";
    }
    $dtE = date("Y-m-d") . "T19:00:00-03:00";
    $dtF = date("Y-m-d", strtotime('+1 day')) . "T19:00:00-03:00";
    $descricaowo = "À\nCETAD/REDES\n\n1. Solicitamos incluir os 
      IPs: {$ip} no objeto de firewall 
      network: {$objeto_destino}.\n1.1 
      Acrescentar a porta: TCP {$porta} ao objeto de firewall 
      service: {$objeto_porta}\n\nAt.te\n\nCETAD36";

    //GERANDO WO
    //$wo->token = $wo->getToken("USR_CETADPOR1", "CETADPOR1");
    $wo->token = $wo->getToken("USR_CETADAUT2", "CETADAUT2");
    $req = $wo->getREQ();

    $wo->setQuestionario($req, $dtE, $dtF, $descricaowo);
    $wo->processarREQ($req);
    $busca =  $wo->buscarREQ($req);
    sleep(10);

    $numwo = $wo->buscarNumWO($busca->entries[0]->values->GSC_chrNumeroRequisicao);

    //RETORNANDO WO  e salvado no banco de dados
    $retorno = [
      "requisicao" => $busca->entries[0]->values->GSC_chrNumeroRequisicao,
      "wo" => $numwo->entries[0]->values->{'Work Order ID'}
    ];

    //inserir as ids de WO e REQUISIÇÃO no banco de dados
    $statement = $db->prepare("INSERT INTO solicitacoes_id (id_mudanca, id_req, data_inclusao) values (:id_mudanca, :id_req, :inclusao)");
    $statement->bindValue(":id_mudanca", $retorno['wo']);
    $statement->bindValue(":id_req", $retorno['requisicao']);
    $statement->bindValue(":inclusao", $array_json["data_solicitacao"]);
    $statement->execute();
    $res = $db->query("select max(id) as id from solicitacoes_id", PDO::FETCH_ASSOC)->fetch();

    //atualizar backends 
    $statement = $db->prepare("update solicitacoes_backends  SET solicitacoes_id = :sol_id FROM solicitacoes_tipo_backends stb
      where stb.id = solicitacoes_backends.id_solicitacoes_tipo_backends and stb.id_solicitacao =:id and stb.tipo='adicional' and stb.status='relacionado' ");
    $statement->bindValue(":sol_id", $res['id']);
    $statement->bindValue(":id",  $array_json['id']);
    $statement->execute();

    //atualiza o tipo de backends da solicitação
    $statement = $db->prepare("UPDATE solicitacoes_tipo_backends SET solicitacoes_id=:sol_id WHERE id_solicitacao=:id and tipo='adicional' and status='relacionado' and solicitacoes_id is null");
    $statement->bindValue(":id", $array_json['id']);
    $statement->bindValue(":sol_id", $res['id']);
    $statement->execute();

    return "enviado com sucesso";
  } catch (Exception $e) {
    $array = [];
    $array['erro'] = "erro execucao da query";
    Transaction::close();
    return $array;
  } finally {
    Transaction::close();
  }
}

function listarBackend($parametros) {
    
    try {
      Transaction::open('database');
      $db = Transaction::get();
      $arrayBindValue = [ ];
      $sql = "SELECT b.id, b.nome, b.ip, b.porta, b.data_cadastro, b.status, tb.tipo, tb.id as id_tipo, 
      b.ambiente, b.servidores, b.descricao, b.endpoint, b.targetpoint, b.matricula,
      (select tipo_nfs from tipo_nfs where id = b.id_tipo_nfs) tipo_nfs,
      (select id from tipo_nfs where id = b.id_tipo_nfs) id_tipo_nfs,
      (select solicitacoes_id from solicitacoes_backends sb where sb.id_backend = b.id limit 1) as solicitado
      from backends b 
      join tipo_backend tb on b.tipo = tb.id where b.status = 'ativado' ";
      

      foreach ($parametros as $indice => $valor) {
        if ($indice != 'acao' || $indice !='status') {
          switch ($indice) {
            case 'nome':
            case 'ip':
            case 'porta':
            case 'ambiente':
            case 'matricula':
            $sql .= "AND b.{$indice} ilike :{$indice} ";
            break;
            case 'tipo':
            $sql .= "AND tb.{$indice} ilike :{$indice} ";
            break;            
          }
          $arrayBindValue[$indice] = $valor;
        }

        if ($indice == 'status' and $valor = 'todos')
          $sql .= " or b.status ilike '%' ";
      }

      $statement = $db->prepare($sql);
      foreach ($arrayBindValue as $indice => $valor) {
        if ($indice != 'acao' && $indice != 'status')
          $statement->bindValue ( ":{$indice}", $valor );
      }

      $statement->execute();
      $registros = $statement->rowCount();
      $arrayRetorno = array();
      $arrayRetorno["registros"] = $registros;
      
      if ($registros == 0) {
        $array['info'] = "não foram encontrados resultados.";
        return $array;
        die;
      }
      
      foreach ($statement as $row ) {
        $arraySistemas[] = array (
        'id' => $row['id'],
        'id_tipo' => $row['id_tipo'],
        'tipo_nfs' => $row['tipo_nfs'],
        'id_tipo_nfs' => $row['id_tipo_nfs'],
        'nome' => $row['nome'],
        'ambiente' => $row['ambiente'],
        'endpoint' => $row['endpoint'],
        'targetpoint' => $row['targetpoint'],
        'ip' => $row['ip'],
        'solicitado' => $row['solicitado'],
        'porta' => $row['porta'],
        'descricao' => $row['descricao'],
        'tipo' => $row['tipo'],
        'ambiente' => $row['ambiente'],
        'servidores' => $row['servidores'],
        'status' => $row['status'],
        'matricula' => $row['matricula']
        );
      }
      
      $arrayRetorno["dados"] = $arraySistemas;
      
      return $arrayRetorno;
      } catch ( Exception $e ) {
      $array = [];
      $array['erro'] = "erro execucao da query";
      Transaction::close ();
      return $array;
      } finally {
      Transaction::close ();
    }
  }   

  function listarBackendsARelacionar($parametros) {
    
    try {
      Transaction::open('database');
      $db = Transaction::get();
      $arrayBindValue = [ ];
      
      if (isset($parametros['tipo']))
        $tipo = "and stb.tipo = '{$parametros['tipo']}'";
      else
        $tipo = "";

      $sql = "SELECT stb.id as id_solicitacao_tipo_backend, b.id, b.nome, b.ip, b.porta, tb.tipo, stb.tipo as tipo_bck from backends b
      inner join solicitacoes_tipo_backends stb on stb.id_tipo_backend = b.tipo
      join tipo_backend tb on b.tipo = tb.id
      where b.status = 'ativado' and stb.id_solicitacao = {$parametros['id']} and b.ambiente = '{$parametros['ambiente']}'  and stb.solicitacoes_id is null and stb.status = 'pendente' $tipo";

      $statement = $db->prepare($sql);
      foreach ($arrayBindValue as $indice => $valor) {
        $statement->bindValue ( ":{$indice}", $valor );
      }
      
      $statement->execute();
      $registros = $statement->rowCount();
      $arrayRetorno = array();
      $arrayRetorno["registros"] = $registros;
      
      if ($registros == 0) {
        $array['info'] = "não foram encontrados resultados.";
        return $array;
        die;
      }
      
      foreach ($statement as $row ) {
        $arraySistemas[] = array (
        'id' => $row['id'],
        'nome' => $row['nome'],
        'porta' => $row['porta'],
        'ip' => $row['ip'],
        'tipo' => $row['tipo'],
        'tipobck' => $row['tipo_bck'],
        'id_solicitacao_tipo_backend' => $row['id_solicitacao_tipo_backend']
        );
      }
      
      $arrayRetorno["dados"] = $arraySistemas;
      
      return $arrayRetorno;
      } catch ( Exception $e ) {
      $array = [];
      $array['erro'] = "erro execucao da query";
      Transaction::close ();
      return $array;
      } finally {
      Transaction::close ();
    }
  }

  function listarBackendsARelacionarSistema($parametros) {
    
    try {
      Transaction::open('database');
      $db = Transaction::get();

      if ($parametros['ambiente'] == 'des' || $parametros['ambiente'] == 'tqs')
        $amb = "(b.ambiente = 'des' or b.ambiente = 'tqs')";
      else
        $amb = "b.ambiente = '{$parametros['ambiente']}'";

      $sql = "SELECT b.id, tb.id as id_tipo, tb.tipo, b.nome, b.ip, b.porta from backends b
      join tipo_backend tb on b.tipo = tb.id
      where b.status = 'ativado' and b.tipo in ({$parametros['ids']}) and {$amb} and ip is not null
      order by b.nome";

      $statement = $db->prepare($sql);
      $statement->execute();
      $registros = $statement->rowCount();
      $arrayRetorno = array();
      $arrayRetorno["registros"] = $registros;
      
      if ($registros == 0) {
        $array['info'] = "não foram encontrados resultados.";
        return $array;
        die;
      }
      
      foreach ($statement as $row ) {
        $arraySistemas[] = array (
        'id' => $row['id'],
        'id_tipo' => $row['id_tipo'],
        'nome' => $row['nome'],
        'porta' => $row['porta'],
        'ip' => $row['ip'],
        'tipo' => $row['tipo']
        );
      }
      
      $arrayRetorno["dados"] = $arraySistemas;
      
      return $arrayRetorno;
      } catch ( Exception $e ) {
      $array = [];
      $array['erro'] = "erro execucao da query";
      Transaction::close ();
      return $array;
      } finally {
      Transaction::close ();
    }
  }

  function listarBackendSolicitado($parametros) {
    
    try {
      Transaction::open('database');
      $db = Transaction::get();
      $arrayBindValue = [ ];
      $sql = "select distinct bck.nome, bck.ip, bck.porta, bck.servidores, tb.tipo as tpbackend,
      (select endpoint from point where id_solicitacao = stb.id and id_backend = bck.id limit 1) endpoint, 
      (select mountpoint from point where id_solicitacao = stb.id  and id_backend = bck.id limit 1) mountpoint,
      (select tipo_nfs from tipo_nfs where id = bck.id_tipo_nfs) tipo_nfs
      from solicitacoes_backends sb
      inner join backends bck on sb.id_backend = bck.id
      inner join solicitacoes_tipo_backends stb on stb.id = sb.id_solicitacoes_tipo_backends
      inner join tipo_backend tb on tb.id = stb.id_tipo_backend
      inner join solicitacoes_infra si on stb.id_solicitacao = si.id
      inner join servidores s on s.sistema = si.modulo
      where "; // and upper(tb.tipo) <> 'NFS'

      $statement = $db->prepare($sql);

      foreach ($parametros as $indice => $valor) {
        if ($indice != 'acao') {
          switch ($indice) {
            case 'plataforma':
              $sql .= " AND s.plataforma = '{$valor}' ";
            break;
            case 'modulo':
              $sql .= " AND si.{$indice} ilike '%{$valor}%' ";
            break;
            case 'tipo':
              $sql .= " AND tb.{$indice} ilike '{$valor}' ";
            break;
            case 'ambiente':
              $sql .= "stb.ambiente = '{$valor}' ";
            break;
          }
          $arrayBindValue[$indice] = $valor;
        }
      }
      $sql .= "	order by tb.tipo ";

      $statement = $db->prepare($sql);
      
      $statement->execute();
      $registros = $statement->rowCount();
      $arrayRetorno = array();
      $arrayRetorno["registros"] = $registros;
      
      if ($registros == 0) {
        $array['info'] = "não foram encontrados resultados.";
        return $array;
        die;
      }
      
      foreach ($statement as $row ) {
        $arraySistemas[] = array (
        'nome' => $row['nome'],
        'tipobackend' => $row['tpbackend'],
        'porta' => $row['porta'],
        'ip' => $row['ip'],
        'tipo_nfs' => $row['tipo_nfs'],
        'endpoint' => $row['endpoint'],
        'mountpoint' => $row['mountpoint'],
        'servidores' => $row['servidores']
        );
      }
      
      $arrayRetorno["dados"] = $arraySistemas;
      
      return $arrayRetorno;

      } catch ( Exception $e ) {
      $array = [];
      $array['erro'] = "erro execucao da query";
      Transaction::close ();
      return $array;
      } finally {
      Transaction::close ();
    }
  }

  function listarBackendSistema($parametros) {
    try {
      Transaction::open('database');
      $db = Transaction::get();
      
      if (isset($parametros['tipo'])) {
        if ($parametros['tipo'] == 'adicional')
          $tipo = "  and solicitacoes_id is null and stb.tipo = '{$parametros['tipo']}'";
        else
          $tipo = "  and stb.tipo = '{$parametros['tipo']}'";
      }
      else
        $tipo = "";

      $sql = "select distinct stb.id, tp.tipo from solicitacoes_tipo_backends stb
      inner join tipo_backend tp on tp.id = stb.id_tipo_backend
      where id_solicitacao = {$parametros['id']} {$tipo}";

      $statement = $db->prepare($sql);
      
      $statement->execute();
      $registros = $statement->rowCount();
      $arrayRetorno = array();
      $arrayRetorno["registros"] = $registros;
      
      if ($registros == 0) {
        $array['info'] = "não foram encontrados resultados.";
        return $array;
        die;
      }
      
      foreach ($statement as $row ) {
        $arraySistemas[] = array (
        'tipo' => $row['tipo'],
        'id' => $row['id']
        );
      }
      
      $arrayRetorno["dados"] = $arraySistemas;
      
      return $arrayRetorno;
      } catch ( Exception $e ) {
      $array = [];
      $array['erro'] = "erro execucao da query";
      Transaction::close ();
      return $array;
      } finally {
      Transaction::close ();
    }
  }
  
  function listarTiposBackend($parametros) {
    try {
      Transaction::open('database');
      $db = Transaction::get();
      
      $arrayBindValue = [ ];
      $sql = "SELECT * from tipo_backend where status = 'ativado' order by tipo";
      
      foreach ($parametros as $indice => $valor) {
        if ($indice != 'acao') {
          switch ($indice) {
            case 'id':
            case 'tipo':
            $sql .= "AND {$indice} = :{$indice} ";
            break;      
          }
          $arrayBindValue[$indice] = $valor;
        }
      }
      
      $statement = $db->prepare($sql);
      foreach ($arrayBindValue as $indice => $valor) {
        $statement->bindValue ( ":{$indice}", $valor );
      }
      
      $statement->execute();
      $registros = $statement->rowCount();
      $arrayRetorno = array();
      $arrayRetorno["registros"] = $registros;
      
      if ($registros == 0) {
        $array['info'] = "não foram encontrados resultados.";
        return $array;
        die;
      }
  
      foreach ($statement as $row ) {

        $arraySistemas[] = array (
        'id' => $row['id'],
        'tipo' => $row['tipo'],
        'portas' => $row['portas'],
        'data_inclusao' => $row['data_inclusao']
        );
      }

      $arrayRetorno["dados"] = $arraySistemas;
      
      return $arrayRetorno;
      } catch ( Exception $e ) {
      $array = [];
      $array['erro'] = "erro execucao da query";
      Transaction::close ();
      return $array;
      } finally {
      Transaction::close ();
    }
  }     

  function getIDTipoBackend($backend) {
    try {
      Transaction::open('database');
      $db = Transaction::get();
      $sql = "SELECT id from tipo_backend where status = 'ativado' and tipo = :tipo ";
      $statement = $db->prepare($sql);
      $statement->bindValue(':tipo', $backend);
      $statement->execute();
      $registros = $statement->rowCount();
      $arrayRetorno = array();
      $arrayRetorno["registros"] = $registros;
      
      if ($registros == 0) {
        $array['info'] = "não foram encontrados resultados.";
        return $array;
        die;
      }
      
      foreach ($statement as $row ) {
        $arraySistemas[] = array (
        'id' => $row['id']
        );
      }
      
      $arrayRetorno["dados"] = $arraySistemas;
      
      return $arrayRetorno;
      } catch ( Exception $e ) {
      $array = [];
      $array['erro'] = "erro execucao da query";
      Transaction::close ();
      return $array;
      } finally {
      Transaction::close ();
    }
  }
  
  function listarRelacionamentosBackendPendentes($parametros) {
    try {
      Transaction::open('database');
      $db = Transaction::get();
      $arrayBindValue = [ ];
      $sql = "select distinct si.id as solicitacao, stb.tipo, si.modulo, stb.ambiente, si.data_solicitacao, si.backends, si.centralizadora from solicitacoes_infra si
       join solicitacoes_tipo_backends stb on si.id = stb.id_solicitacao 
       join tipo_backend tb on stb.id_tipo_backend = tb.id 
       where stb.status = 'pendente' and si.status='ativado' ";
      
      foreach ($parametros as $indice => $valor) {
        if ($indice != 'acao') {
          switch ($indice) {
            case 'solicitacao':
            $sql .= "AND si.{$indice} = :{$indice} ";
            break;
            case 'ambiente':
            $sql .= "AND stb.{$indice} = :{$indice} ";
            break;
            case 'modulo':
            $sql .= "AND si.{$indice} = :{$indice} ";
            break;  
            case 'tipo':
              $sql .= "AND stb.{$indice} = :{$indice} ";
              break;           
          }
          $arrayBindValue[$indice] = $valor;
        }
      }
      
      $statement = $db->prepare($sql);
      foreach ($arrayBindValue as $indice => $valor) {
        $statement->bindValue ( ":{$indice}", $valor );
      }
      
      $statement->execute();
      $registros = $statement->rowCount();
      $arrayRetorno = array();
      $arrayRetorno["registros"] = $registros;
      
      if ($registros == 0) {
        $array['info'] = "não foram encontrados resultados.";
        return $array;
        die;
      }
      
      foreach ($statement as $row ) {
        $backends = $db->query("select tb.tipo from solicitacoes_infra si 
        join solicitacoes_tipo_backends stb on si.id = stb.id_solicitacao 
        join tipo_backend tb on stb.id_tipo_backend = tb.id 
        where stb.status = 'pendente' and si.id = {$row['solicitacao']}", PDO::FETCH_ASSOC)->fetchAll();

        $arrayResultados[] = array (
        'id_solicitacao' => $row['solicitacao'],
        'id' => $row['solicitacao'],
        'modulo' => $row['modulo'],
        'ambiente' => $row['ambiente'],
        'tipo' => $row['tipo'],
        'centralizadora' => $row['centralizadora'],
        'data_solicitacao' => $row['data_solicitacao'],
        'backends' => $backends
        );
      }
      
      $arrayRetorno["dados"] = $arrayResultados;
      
      return $arrayRetorno;
      } catch ( Exception $e ) {
      $array = [];
      $array['erro'] = "erro execucao da query";
      Transaction::close ();
      return $array;
      } finally {
      Transaction::close ();
    }
  }
  
  function listarRelacionamentosBackend($parametros) {
    try {
      Transaction::open('database');
      $db = Transaction::get();
      $arrayBindValue = [ ];
      $sql = "select si.id as solicitacao, si.modulo, stb.ambiente, tb.tipo, si.data_solicitacao from solicitacoes_infra si join solicitacoes_tipo_backends stb
      on si.id = stb.id_solicitacao join tipo_backend tb on stb.id_tipo_backend = tb.id ";

      $sqlinicial = [];

      foreach ($parametros as $indice => $valor) {
        if ($indice != 'acao') {
          switch ($indice) {
            case 'solicitacao':
            $sqlinicial[] = "si.{$indice} = :{$indice} ";
            break;
            case 'ambiente':
            $sqlinicial[] = "stb.{$indice} = :{$indice} ";
            break;
            case 'modulo':
            $sqlinicial[] .= "si.{$indice} = :{$indice} ";
            break;
            case 'status':
            $sqlinicial[] = "stb.{$indice} = :{$indice}";
            break;
          }
          $arrayBindValue[$indice] = $valor;
        }
      }
      
      if (count($parametros) > 1 ) {
        $sql = $sql . ' WHERE '. implode(" AND ", $sqlinicial);
      }
      
      $statement = $db->prepare($sql);
      foreach ($arrayBindValue as $indice => $valor) {
        $statement->bindValue ( ":{$indice}", $valor );
      }
      
      $statement->execute();
      $registros = $statement->rowCount();
      $arrayRetorno = array();
      $arrayRetorno["registros"] = $registros;
      
      if ($registros == 0) {
        $array['info'] = "não foram encontrados resultados.";
        return $array;
        die;
      }
      
      foreach ($statement as $row ) {
        $arrayResultados[] = array (
        'id_solicitacao' => $row['solicitacao'],
        'modulo' => $row['modulo'],
        'ambiente' => $row['ambiente'],
        'tipo' => $row['tipo'],
        'data_solicitacao' => $row['data_solicitacao']
        );
      }
      
      $arrayRetorno["dados"] = $arrayResultados;
      
      return $arrayRetorno;
      } catch ( Exception $e ) {
      $array = [];
      $array['erro'] = "erro execucao da query";
      Transaction::close ();
      return $array;
      } finally {
      Transaction::close ();
    }
  }  

  function listarBackendAdicional($parametros) {
    try {
      Transaction::open('database');
      $db = Transaction::get();
      $arrayBindValue = [ ];
      $sql = "SELECT * from vw_backend_adicional ";
      
      foreach ($parametros as $indice => $valor) {
        if ($indice != 'acao') {
          $sqlinicial[] = "{$indice} = :{$indice} ";
          $arrayBindValue[$indice] = $valor;
        }
      }
      
      if (count($parametros) > 1 ) {
        $sql = $sql . ' WHERE '. implode(" AND ", $sqlinicial);
      }
      
      $statement = $db->prepare($sql);
      foreach ($arrayBindValue as $indice => $valor) {
        $statement->bindValue ( ":{$indice}", $valor );
      }
      
      $statement->execute();
      $registros = $statement->rowCount();
      $arrayResultado = array();
      $arrayResultado["registros"] = $registros;
      
      if ($registros == 0) {
        $array['info'] = "não foram encontrados resultados.";
        return $array;
        die;
      }
      
      foreach ($statement as $row ) {
        
        $arrayRetorno[] = array (
        'id' => $row['id_solicitacao'],
        'sistema' => $row['sistema'],
        'req' => $row['req'],
        'wo' => $row['wo'],
        'solicitante' => $row['solicitante'],
        'centralizadora' => "x",//$row['centralizadora'],
        'ambiente' => $row['ambiente'],
        'tipo' => $row['tipo']
        );
      }
      
      $arrayResultado["dados"] = $arrayRetorno;
      
      return $arrayResultado;
      } catch ( Exception $e ) {
      $array = [];
      $array['erro'] = "erro execucao da query";
      Transaction::close();
      return $array;
      } finally {
      Transaction::close();
      }
  }

  function listarBackendRelacionados($parametros) {
    try {
      Transaction::open('database');
      $db = Transaction::get();
      $arrayBindValue = [ ];
      $sql = "SELECT * from vw_backend_relacionado ";
      
      foreach ($parametros as $indice => $valor) {
        if ($indice != 'acao') {
          $sqlinicial[] = "{$indice} = :{$indice} ";
          $arrayBindValue[$indice] = $valor;
        }
      }
      
      if (count($parametros) > 1 ) {
        $sql = $sql . ' WHERE '. implode(" AND ", $sqlinicial);
      }
      
      $statement = $db->prepare($sql);
      foreach ($arrayBindValue as $indice => $valor) {
        $statement->bindValue ( ":{$indice}", $valor );
      }
      
      $statement->execute();
      $registros = $statement->rowCount();
      $arrayResultado = array();
      $arrayResultado["registros"] = $registros;
      
      if ($registros == 0) {
        $array['info'] = "não foram encontrados resultados.";
        return $array;
        die;
      }
      
      foreach ($statement as $row ) {
        
        $arrayRetorno[] = array (
        'id' => $row['id'],
        'sistema' => $row['sistema'],
        'ambiente' => $row['ambiente'],
        'nome' => $row['nome'],
        'data_atualizacao' => $row['data_atualizacao'],
        'ip' => $row['ip'],
        'porta' => $row['porta'],
        'tipo' => $row['tipo']
        );
      }
      
      $arrayResultado["dados"] = $arrayRetorno;
      
      return $arrayResultado;
      } catch ( Exception $e ) {
      $array = [];
      $array['erro'] = "erro execucao da query";
      Transaction::close();
      return $array;
      } finally {
      Transaction::close();
      }
  }
?>