<?php
class ConfigRecursoVM
{

    //ENDPOINTS
    const ENDPOINT_REQ              = "/api/arsys/v1/entry/GSC:RF223:IntSRM_Definicao?fields=values(GSC_chrIDRegistro,GSC_chrNumeroRequisicao)";
    const ENDPOINT_QUESTIONARIO     = "/api/arsys/v1/entry/GSC:RF224:IntSRM_Perguntas?fields=values(GSC_chrIDRegistro)";
    const ENDPOINT_PROCESSAREQ      = "/api/arsys/v1/entry/GSC:RF223:IntSRM_Definicao";
    const ENDPOINT_LOGIN             = "/api/jwt/login";
    const ENDPOINT_LOGOUT             = "/api/jwt/logout";
    const API_HMP                   = "http://scthmapllx0106.df.caixa:8008";
    const API_PRD                   = "http://cctdcapllx0388.df.caixa:8008";


    const ENDPOINT_ALLOCATION_CRQ     = "/api/arsys/v1/entry/CHG:CFG%20Ticket%20Num%20Generator/";
    const ENDPOINT_GET_PEOPLE         = "/api/arsys/v1/entry/CTM:People/";
    const ENDPOINT_CREATE_CHANGE     = "/api/arsys/v1/entry/CHG:ChangeInterface_Create/";
    const ENDPOINT_QUERY_CHANGE     = "/api/arsys/v1/entry/CHG:Infrastructure%20Change/";



    //QUESTIONARIO
    public $questionario = [

        'unidade' => array("values" => array(
            "GSC_chrIDRegistroPai" => "",
            "GSC_chrPergunta" => "Informar a unidade demandante",
            "GSC_chrResposta" => "CEPTI"
        )),
        'area' => array("values" => array(
            "GSC_chrIDRegistroPai" => "",
            "GSC_chrPergunta" => "Selecionar a área de operações responsável pela sustentação do serviço",
            "GSC_chrResposta" => "Brasília"
        )),
        'ambiente' => array("values" => array(
            "GSC_chrIDRegistroPai" => "",
            "GSC_chrPergunta" => "Selecionar ambiente que o aporte de recurso será realizado",
            "GSC_chrResposta" => "Desenvolvimento (DES)"
        )),
        'ic' => array("values" => array(
            "GSC_chrIDRegistroPai" => "",
            "GSC_chrPergunta" => "Selecionar o IC que receberá o aporte de recurso",
            "GSC_chrResposta" => "Servidor lógico"
        )),
        'dados_ic' => array("values" => array(
            "GSC_chrIDRegistroPai" => "",
            "GSC_chrPergunta" => "Informar os dados do IC que receberá o aporte",
            "GSC_chrResposta" => "simpi-contabil - des"
        )),
        'recurso' => array("values" => array(
            "GSC_chrIDRegistroPai" => "",
            "GSC_chrPergunta" => "Informar qual o recurso e quanto será aportado",
            "GSC_chrResposta" => "VCPU: 2 | Memoria: -1 GB | Disco/OPT: 20 GB | Disco/LOG: 18 GB"
        )),
        'telefone' => array("values" => array(
            "GSC_chrIDRegistroPai" => "",
            "GSC_chrPergunta" => "Informar telefones para contato",
            "GSC_chrResposta" => "Teams"
        )),
        'caixa_postal' => array("values" => array(
            "GSC_chrIDRegistroPai" => "",
            "GSC_chrPergunta" => "Informar caixa postal da unidade demandante",
            "GSC_chrResposta" => "Teams"
        )),
        'detalhe' => array("values" => array(
            "GSC_chrIDRegistroPai" => "",
            "GSC_chrPergunta" => "Informar mais detalhes sobre o atendimento a ser realizado",
            "GSC_chrResposta" => "Prezado Analista,"
        ))
    ];
   
}
