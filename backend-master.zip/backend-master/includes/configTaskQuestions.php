<?php
    class ConfigTaskQuestions {

        //ENDPOINTS
        const ENDPOINT_REQ      		= "/api/arsys/v1/entry/GSC:RF223:IntSRM_Definicao?fields=values(GSC_chrIDRegistro,GSC_chrNumeroRequisicao)";
        const ENDPOINT_QUESTIONARIO     = "/api/arsys/v1/entry/GSC:RF224:IntSRM_Perguntas?fields=values(GSC_chrIDRegistro)";
        const ENDPOINT_PROCESSAREQ      = "/api/arsys/v1/entry/GSC:RF223:IntSRM_Definicao";
        const ENDPOINT_LOGIN 			= "/api/jwt/login";
        const ENDPOINT_LOGOUT 			= "/api/jwt/logout";
        const API_HMP                   = "http://scthmapllx0106.df.caixa:8008";
        const API_PRD                   = "http://cctdcapllx0388.df.caixa:8008";

        
        const ENDPOINT_ALLOCATION_CRQ 	= "/api/arsys/v1/entry/CHG:CFG%20Ticket%20Num%20Generator/";
        const ENDPOINT_GET_PEOPLE 		= "/api/arsys/v1/entry/CTM:People/";
        const ENDPOINT_CREATE_CHANGE 	= "/api/arsys/v1/entry/CHG:ChangeInterface_Create/";
        const ENDPOINT_QUERY_CHANGE 	= "/api/arsys/v1/entry/CHG:Infrastructure%20Change/";

        

        public $questionario = [
            'menu1' => array("values" => array(
                "GSC_chrIDRegistroPai" => "",
                "GSC_chrPergunta" => "Selecione a sua Comunidade",
                "GSC_chrResposta" => ""
            )),
            'menu2' => array("values" => array(
                "GSC_chrIDRegistroPai" => "",
                "GSC_chrPergunta" => "O que você deseja?",
                "GSC_chrResposta" => "Descrever as tecnologias e necessidade para o Sistema na camada de aplicação e apresentação nas Esteiras DevOps"
            )),
    
            'descricao' => array("values" => array(
                "GSC_chrIDRegistroPai" => "",
                "GSC_chrPergunta" => "Descrição do ambiente a ser criado",
                "GSC_chrResposta" => ""
            ))
        ];
    }
?>