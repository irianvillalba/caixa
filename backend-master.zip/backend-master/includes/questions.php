<?php

ini_set("xdebug.var_display_max_children", -1);
ini_set("xdebug.var_display_max_data", -1);
ini_set("xdebug.var_display_max_depth", -1);

class Questions
{

    public $token;
    public $req;
    private $ch;
    private $api;


    function __construct($ambiente)
    {
        $this->ch = curl_init();
        if (strtolower($ambiente) == 'hmp')
            $this->api = ConfigTaskQuestions::API_HMP;
        else
            $this->api = ConfigTaskQuestions::API_PRD;
    }

    //passo 0  - Requisitar o Token 
    public function getToken($usuario, $senha)
    {

        $options = array(
            CURLOPT_URL =>              $this->api . ConfigTaskQuestions::ENDPOINT_LOGIN,
            CURLOPT_POST =>             1,
            CURLOPT_POSTFIELDS =>       "username={$usuario}&password={$senha}",
            CURLOPT_RETURNTRANSFER =>    1,
            CURLOPT_HTTPHEADER =>       array(
                "Content-Type:application/x-www-form-urlencoded",
                'cache-control:no-cache'
            )
        );

        curl_setopt_array($this->ch, $options);
        $result = curl_exec($this->ch);
        return $result;
    }


    public function buscarTask()
    {

        $options = array(
            CURLOPT_URL =>  $this->api . "/api/arsys/v1/entry/SRD:ServiceRequestDefinition?q='SRD_Title'%3D%22Criação de Ambientes para os Sistemas Centralizados%22",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "GET",
            CURLOPT_HTTPHEADER =>       array(
                "Content-Type:application/json",
                'Authorization:AR-JWT ' . $this->token
            )
        );

        curl_setopt_array($this->ch, $options);
        $result = curl_exec($this->ch);

    
        return json_decode($result);
    }

    public function criarCapaREQ()
    {

        $post = json_encode(array('values' => array(
            "GSC_ddlStatus" => "Processar",
            "GSC_chrTituloRequisicao" => "Criação de Ambientes para os Sistemas Centralizados",
            "GSC_chrIDInstancia" => "SRGAA5V0F9OUSAQUR4VGQTSLYUZQPR",
            "GSC_ddlStatusRequisicao" => "Draft",
            "GSC_chrSolicitadoPor" => "USR_CETADPOR1",
            "GSC_chrSolicitadoPara" => "USR_CETADPOR1",
            "GSC_ddlOrigem" => "{Web Services}"
        )));

        $options = array(
            CURLOPT_URL =>              $this->api . ConfigTaskQuestions::ENDPOINT_REQ,
            CURLOPT_RETURNTRANSFER =>   true,
            CURLOPT_ENCODING =>         "",
            CURLOPT_MAXREDIRS =>        10,
            CURLOPT_TIMEOUT =>          0,
            CURLOPT_FOLLOWLOCATION =>   true,
            CURLOPT_HTTP_VERSION =>     CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST =>    "POST",
            CURLOPT_POSTFIELDS =>       $post,
            CURLOPT_HTTPHEADER =>       array(
                "Content-Type:application/json",
                'Authorization:AR-JWT ' . $this->token
            )
        );

        curl_setopt_array($this->ch, $options);
        $cabecalho = json_decode(curl_exec($this->ch));

        if (isset($cabecalho->values->GSC_chrIDRegistro))
            $result = $cabecalho->values->GSC_chrIDRegistro;
        else
            $result = $cabecalho;


        return $result;
    }

    public function criarQuestionario1($regra, $req , $descricao )
    {


        $config = new ConfigTaskQuestions();
        $comunidade = $regra["api"];
       
        foreach ($config->questionario as $q) {

            $q['values']['GSC_chrIDRegistroPai'] = $req;
            if ($q['values']['GSC_chrPergunta'] == "Selecione a sua Comunidade")
                $q['values']['GSC_chrResposta'] = $comunidade;
            if ($q['values']['GSC_chrPergunta'] == "Descrição do ambiente a ser criado")
                $q['values']['GSC_chrResposta'] = $descricao;

                $questao = json_encode($q, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);

        $options = array(
            CURLOPT_URL =>              $this->api . ConfigTaskQuestions::ENDPOINT_QUESTIONARIO,
            CURLOPT_POST =>             1,
            CURLOPT_HEADER =>           false,
            CURLOPT_CUSTOMREQUEST =>    "POST",
            CURLOPT_HTTPHEADER =>       CURL_HTTP_VERSION_1_1,
            CURLOPT_POSTFIELDS =>       $questao,
            CURLOPT_RETURNTRANSFER =>    1,
            CURLOPT_HTTPHEADER =>       array(
                "Content-Type:application/json",
                'Authorization:AR-JWT ' . $this->token
            )
        );

        curl_setopt_array($this->ch, $options);
        $result = curl_exec($this->ch);
        
    }
        
    }



    public function AtualizandoReq($req)
    {

        $post = json_encode(array('values' => array(
            "GSC_ddlStatus" => "Inicio"
        )));


        $config = new ConfigTaskQuestions();
        $options = array(
            CURLOPT_URL =>              $this->api . ConfigTaskQuestions::ENDPOINT_PROCESSAREQ . "/{$req}",
            CURLOPT_HEADER =>           true,
            CURLOPT_CUSTOMREQUEST =>    "PUT",
            CURLOPT_POST =>             1,
            CURLOPT_POSTFIELDS =>       $post,
            CURLOPT_RETURNTRANSFER =>    1,
            CURLOPT_HTTPHEADER =>       array(
                "Content-Type:application/json",
                'Authorization:AR-JWT ' . $this->token,
                "X-AR-Client-Type:34"
            )
        );

        curl_setopt_array($this->ch, $options);
        $result = json_decode(curl_exec($this->ch));

        

        return $result;
    }


    public function buscarReq($req)
    {

        $options = array(
            CURLOPT_URL =>  $this->api . "/api/arsys/v1/entry/GSC:RF223:IntSRM_Definicao?q='GSC_chrIDRegistro'%3D%22" . "{$req}" . "%22",
            CURLOPT_HEADER =>           false,
            CURLOPT_CUSTOMREQUEST =>    "GET",
            CURLOPT_RETURNTRANSFER =>    1,
            CURLOPT_HTTPHEADER =>       array(
                "Content-Type:application/json",
                'Authorization:AR-JWT ' . $this->token
            )
        );

        curl_setopt_array($this->ch, $options);
        $result = json_decode(curl_exec($this->ch));

        return $result;
    }



    private function logout()
    {
        $options = array(
            CURLOPT_URL =>              $this->api . ConfigTaskQuestions::ENDPOINT_LOGOUT,
            CURLOPT_POST =>             1,
            CURLOPT_RETURNTRANSFER =>    1,
            CURLOPT_HTTPHEADER =>       array(
                "cache-control:no-cache",
                'Authorization:AR-JWT ' . $this->token
            )
        );

        curl_setopt_array($this->ch, $options);
        $result = curl_exec($this->ch);
    }

    function __destruct()
    {
        $this->logout();
        curl_close($this->ch);
    }
}
