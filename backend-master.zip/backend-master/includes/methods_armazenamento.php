<?php

function armazenamentoSolicitar($request)
{
  try {
    $data = json_decode($request,true);
    
    $obj = new ArmazenamentoBusiness();
    

    $rec = $obj->abrirRequisicao($data);
    if ($rec["status"] == "OK") {
      $ret = $obj->gravarSolicitacao($data,$rec);
      if ($ret) {       
        return Utils::apiReturn("OK","Solicitação ".$rec['requisicao']." cadastrada com sucesso!");
      } else {
        $obj->cancelaRequisicao($rec['requisicao']);
        return Utils::apiReturn("ERRO","Erro ao gerar a solicitação");
      }
    } else {
      return Utils::apiReturn($rec['status'], $rec['mensagem']);
    }
  }catch(NegocioException $ne){
    http_response_code(200);
    return  Utils::apiReturn('ERRO',$ne->getMessage());
  } catch (Exception $e) {
    http_response_code(500);
    return Utils::apiReturn("ERRO", $e->getMessage());
  }
}
function armazenamentoListarParticoes($request)
{
try{
 $b = new ArmazenamentoBusiness();
$ret = $b->listarParticoes($request['ambiente']);
return Utils::apiReturnList(count($ret),$ret);  
}catch(NegocioException $ne){
  http_response_code(200);
  return  Utils::apiReturn('ERRO',$ne->getMessage());
} catch (Exception $e) {
  http_response_code(500);
  return Utils::apiReturn("ERRO", $e->getMessage());
}
}
function armazenamentoListar($request)
{
 $b = new ArmazenamentoBusiness();
 try{
$ret =  $b->listarArmazenamentos($request['sistema'],$request['ambiente']);
return Utils::apiReturnList(count($ret),$ret);
}catch(NegocioException $ne){
  http_response_code(200);
  return  Utils::apiReturn('ERRO',$ne->getMessage());
} catch (Exception $e) {
  http_response_code(500);
  return Utils::apiReturn("ERRO", $e->getMessage());
}
}