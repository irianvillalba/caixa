<?php 
function testeReqDns($json){
    $json_post = json_decode($json, true);
    $objVip = new Vip();
    return $objVip->criarRequisicaoDNS($json_post);
}

function testeRotaOkd($json){
    $retorno=[];
    $json_post = json_decode($json, true);
    $cli = new DNSClient(dns_endpoint);
    $array = explode("-",$json_post['sistema']);
      $retOKD = $cli->registraRotaOKD($array[0]."-".strtolower($json_post['ambiente']),$json_post['sistema']."-".strtolower($json_post['ambiente']),$json_post["fqdn"],$json_post["site"]);
      if(isset($retOKD->error)){
        $retorno["mensagemRotaOKD"] = $retOKD->error;
      }else{
        $retorno["mensagemRotaOKD"] = "Rota OKD Criada com sucesso!";
      }
      return $retOKD;
}