<?php
  
  //cadastrar solicitação de recursos (method POST)
  function solicitarRecursoContainer($json) {
    $json = json_decode($json, true);
    Transaction::open('database');
    $db = Transaction::get();
    try {

            $dt_inclusao = date('Y-m-d H:i:s');

            $db->exec("insert into recursos_container 
            (cpu, memoria, justificativa, opcoes, status, matricula, sistema, ambiente, dt_inclusao) values 
            ({$json['cpu']},{$json['memoria']},'{$json['justificativa']}', 
            '{$json['opcao']}', 'solicitado', '{$json['matricula']}', '{$json['sistema']}', '{$json['ambiente']}', '{$dt_inclusao}')");

            $mensagem = "Solicitado com sucesso.";
            http_response_code(201);

        } catch (Exception $e) {
          $mensagem = "Descricao: {$e->getMessage()}";
        } finally {
          Transaction::close();
      }
    return($mensagem);
  }  

  function editarRecursoContainer($json) {
    $json = json_decode($json, true);

    Transaction::open('database');
    $db = Transaction::get();
    try {
            $dt_alteracao = date('Y-m-d H:i:s');

            $db->exec("update recursos_container SET cpu = {$json['cpu']}, memoria = {$json['memoria']}, 
            justificativa_status = '{$json['justificativa_status']}',
            dt_alteracao = '{$dt_alteracao}' where id = {$json['id_recurso']}");

            $mensagem = "Alterado com sucesso.";
            http_response_code(201);
        } catch (Exception $e) {
          $mensagem = "Descricao: {$e->getMessage()}";
        } finally {
          Transaction::close();
      }
    return($mensagem);
  } 
  
  //mudança de status da solicitacao (method POST)
  function mudancaStatusRecursoContainer($json) {
    $json = json_decode($json, true);

    Transaction::open('database');
    $db = Transaction::get();
    try {

            $dt_alteracao = date('Y-m-d H:i:s');

            $db->exec("update recursos_container SET status = '{$json['status']}', justificativa_status = '{$json['justificativa_status']}',
            dt_alteracao='{$dt_alteracao}' , matricula_aprovacao='{$json['matricula_aprovacao']}'
            where id = {$json['id_recurso']}");

            $mensagem = "Status alterado com sucesso.";
            http_response_code(201);

        } catch (Exception $e) {
          $mensagem = "Descricao: {$e->getMessage()}";
        } finally {
          Transaction::close();
      }
    return($mensagem);
  }  

  //retorna  a lista de solicitacoes (method GET)
  function listaSolicitacaoRecursoContainer() {
    try {
      Transaction::open('database');
      $db = Transaction::get();

      $sql = "select * from recursos_container order by dt_inclusao";

      $registros = $db->query($sql,PDO::FETCH_ASSOC)->fetchAll();
      
      return $registros;
      } catch ( Exception $e ) {
        $array = [];
        $array['erro'] = "erro execucao da query";
        Transaction::close ();
        return $array;
      } finally {
      Transaction::close ();
    }
  }
  
  //retorna a lista de solicitacoes por sistema/ambiente (method GET)
  function listaSolicitacaoRecursoContainerSistema($json) {
    try {
      Transaction::open('database');
      $db = Transaction::get();

      $sql = "select * from recursos_container where sistema = '{$json['sistema']}' and ambiente = '{$json['ambiente']}' order by dt_inclusao desc, status";

      $registros = $db->query($sql,PDO::FETCH_ASSOC)->fetchAll();
      
      return $registros;
      } catch ( Exception $e ) {
        $array = [];
        $array['erro'] = "erro execucao da query";
        Transaction::close ();
        return $array;
      } finally {
      Transaction::close ();
    }
  }
  
  //retorna a solicitação aprovada por sistema/ambiente (method GET)
  function listaAprovadoRecursoContainerSistema($json) {
    try {
      Transaction::open('database');
      $db = Transaction::get();

      $sql = "select id, sistema, ambiente, cpu, memoria from recursos_container 
      where sistema = '{$json['sistema']}' and ambiente = '{$json['ambiente']}' and status = 'aprovado'";

      $registros = $db->query($sql,PDO::FETCH_ASSOC)->fetchAll();
      
      return $registros;
      } catch ( Exception $e ) {
        $array = [];
        $array['erro'] = "erro execucao da query";
        Transaction::close ();
        return $array;
      } finally {
      Transaction::close ();
    }
  }