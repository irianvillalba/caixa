Autentica um usuário no CORPCAIXA.

|MÉTODO|CHAMADA|
|:----------|:-----------|
|POST|https://infra.devops.caixa/api/api.php?acao=autenticarUsuario|

-----

#### Parâmetros obrigatórios

|PARÂMETRO|DESCRIÇÃO|
|:----------|:-----------|
|**usuario**|usuario no formato cxxxxxx.|
|**senha**|Senha do usuário.|

-----

#### Exemplo de JSON a ser usado na chamada

```json
{
	"usuario":"c080028",
	"senha":"abcde65"
}
```

-----

#### Retorno esperado

- sim: Caso a autenticação ocorra com sucesso.
- nao: No caso de falha na autenticação.