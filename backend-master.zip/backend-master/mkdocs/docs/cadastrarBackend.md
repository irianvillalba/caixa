Realiza o cadastramento de um novo backend na Base de dados.

|MÉTODO|CHAMADA|
|:----------|:-----------|
|POST|https://infra.devops.caixa/api/api.php?acao=cadastrarBackend|

-----

#### Parâmetros obrigatórios

|PARÂMETRO|DESCRIÇÃO|
|:----------|:-----------|
|**nome**|Nome do Backend.|
|**tipo**|Id do tipo do backend.|
|**ambiente**|Ambiente do backend.|
|**ip**|IP do backend.|
|**porta**|Porta do Backend.|
|**servidores**|Servidores onde o backend está localizado, separados por vírgula.|

-----

#### Exemplo de JSON a ser usado na chamada

```json
{
    "nome": "ora43",
    "tipo": "1",
    "ambiente": "des",
    "ip": "10.216.76.185",
    "porta": "5432",
    "servidores": "drjscgerlx0031"
}
```

-----

#### Exemplo de Retorno esperado

```json
{
	"dados": {
		"nome": "ora43",
		"tipo": "1",
		"ambiente": "des",
		"ip": "10.216.76.185",
		"porta": "5432",
		"servidores": "drjscgerlx0031",
		"data_cadastro": "2020-01-10 17:50:33",
		"status": "ativado"
	},
	"retorno": {
		"status": "sucesso",
		"mensagem": "cadastro realizado com sucesso!"
	}
}
```