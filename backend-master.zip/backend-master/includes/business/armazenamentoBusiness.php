<?php
class ArmazenamentoBusiness
{
  public $db = null;

  public function __construct()
  {
    Transaction::open('database');
    $this->db = Transaction::get();    
  }

  public function __destruct()
  {
    Transaction::close();
  }
  private  $questionario = [

    'menu1' => array("values" => array(
      "GSC_chrIDRegistroPai" => "",
      "GSC_chrPergunta" => "Tipo do Serviço",
      "GSC_chrResposta" => "Disponibilização/Remoção de Espaço em Disco"
    )),

    'menu2' => array("values" => array(
      "GSC_chrIDRegistroPai" => "",
      "GSC_chrPergunta" => "Qual o atendimento a ser realizado?",
      "GSC_chrResposta" => ""
     
    )),

    
  ];

  public function gravarSolicitacao($request, $requisicao)
  {
         
     try{ 
      

      $armazenamento = new ArmazenamentoEntity();
      $armazenamento->solicitacao_data = Date("Y-m-d H:i:s");
      $armazenamento->plataforma = $request['plataforma'];
      $armazenamento->sistema = strtolower($request['sistema']);
      $armazenamento->ambiente = strtolower($request['ambiente']);
      $armazenamento->tipo_disco = $request['op_tipo_disco'];
      $armazenamento->op_nas_ponto_montagem = $request['op_nas_ponto_montagem'];
      $armazenamento->op_nas_tipo_compartilhamento = $request['op_nas_tipo_compartilhamento'];
      $armazenamento->mf_mascara_arquivo = $request['mf_mascara_arquivo'];
      $armazenamento->mf_nome_particao = $request['mf_nome_particao'];
      $armazenamento->volumetria = $request['volumetria'];
      $armazenamento->acompanhar = $request['acompanhar_solicitacao'];
      $armazenamento->hostnames = json_encode($request['host_names']);
      $armazenamento->mainframe_hostnames = json_encode($request['op_nas_mf_host_names']);
      $armazenamento->solicitacao_requisicao = $requisicao['requisicao'];
      $armazenamento->solicitacao_status = 'aberto';
      $armazenamento->solicitante_nome = $request['solicitante'];
      $armazenamento->solicitante_matricula = $request['matricula'];
      $armazenamento->observacoes = $request['observacoes'];
      $armazenamento->store();
      return true;   
    }catch(Exception $e){
      return false;
    }
    
  }

  public function listarParticoes($ambiente){    
      
    $sql = "select * from armazenamento_particoes where ambiente = '".strtoupper($ambiente)."' order by particao asc";
    $registros = $this->db->query($sql,PDO::FETCH_ASSOC)->fetchAll();      
      return  $registros;    
   
  }

  public function geraResumo($arrayItens){
    $resumo = "Solicitação de Armazenamento\n";
    $resumo .="****************************************************\n";
    $resumo .= "SOLICITANTE: ".$arrayItens['matricula']."\n";
    $resumo .= "SISTEMA/AMBIENTE: ".strtoupper($arrayItens['sistema'])."/".strtoupper($arrayItens['ambiente'])."\n";
    $resumo .= "PLATAFORMA: ".$arrayItens['plataforma']."\n";
    $resumo .= "VOLUMETRIA: ".$arrayItens['volumetria']."\n";
    if($arrayItens['plataforma'] == 'MAINFRAME'){
      $resumo .= "MÁSCARA DO ARQUIVO: ".$arrayItens['mf_mascara_arquivo']."\n";
      $resumo .= "NOME DA PARTIÇÃO: ".$arrayItens['mf_nome_particao']."\n";
    }
    if($arrayItens['plataforma'] == 'OPEN'){
      $resumo .= "TIPO DE DISCO: ".$arrayItens['op_tipo_disco']."\n";

      //pega os hostnames
      if($arrayItens['control_hostnames']){
        $hostnames = "'".implode("','",$arrayItens['host_names'])."'";
      }else{
      $listaSistema = "'".implode("','",$arrayItens['host_names'])."'";
      $hostnames = $this->getHostnamesBySistemas($listaSistema,$arrayItens['ambiente']);
      };
      $resumo .= "HOSTNAMES: ".$hostnames."\n";

      if($arrayItens['op_tipo_disco']=='NAS'){
        $resumo .= "PONTO DE MONTAGEM: ".$arrayItens['op_nas_ponto_montagem']."\n";
        $resumo .= "TIPO DE COMPARTILHAMENTO: ".$arrayItens['op_nas_tipo_compartilhamento']."\n";
        if(count($arrayItens['op_nas_mf_host_names'])>0){
          $listaparticoes = "'".implode("','",$arrayItens['op_nas_mf_host_names'])."'";
          $resumo .= "VAI COMUNICAR COM MAINFRAME: SIM\n";
          $resumo .= "Transformação de Caracteres? (EBC/DIC para ASCII)E: SIM\n";
          $resumo .= "VERSÃO DO NFS: 3\n";
          $resumo .= "PARTIÇÕES MAINFRAME A COMPARTILHAR: ".$listaparticoes."\n";
        }else{
          $resumo .= "VAI COMUNICAR COM MAINFRAME: NÃO\n";
        }
      }
    }
    $resumo .= "OBSERVAÇÕES: ".$arrayItens['observacoes']."\n";
    $resumo.= "****************************************************";
    
  

    return $resumo;

  }

  public function listarArmazenamentos($sistema,$ambiente){  
    
   
       //verifica se o sistema e ambiente já possui solicitacao
       $sql = "select * from armazenamento where ambiente = '".strtolower($ambiente)."' and sistema='".strtolower($sistema)."' order by solicitacao_data asc";
       $registros = $this->db->query($sql,PDO::FETCH_ASSOC)->fetchAll();
       foreach ($registros as $key => $arm) {
        if($arm['solicitacao_status']!= 'Concluído'){
          //vai no gcs atualizar o status da req
          $gsc = new GSCClient(gsc_endpoint,gsc_user,gsc_password);
          $result = $gsc->recGetRequest($arm['solicitacao_requisicao']);
         $status = $result->entries[0]->values->Status;
          $sqlUpdate = "update armazenamento set solicitacao_status = '$status' where id = ".$arm['id'];
          $this->db->exec($sqlUpdate);
          $registros[$key]['solicitacao_status']=$status;
        }
       }
      
      return  $registros;    
    
    
  }

  public function getHostnamesBySistemas($sistemas,$ambiente){   
   
       //verifica se o sistema e ambiente já possui solicitacao
       $sql = "select servidores_json from servidores where sistema in($sistemas) and ambiente = '$ambiente'";

       $registros = $this->db->query($sql,PDO::FETCH_ASSOC)->fetchAll();
      $hostnames = [];
      foreach ($registros as $key => $value) {
        $servidor = json_decode($value['servidores_json']);
        $hostnames[] = $servidor[0]->nome;
      }
      return  implode(",",$hostnames);    
    
   
  }

  public function abrirRequisicao($json_post)
  {
    
             $retorno = [];
        
    try{

        

        $gsc = new GSCClient(gsc_endpoint,gsc_user,gsc_password);

          if ($gsc->connected == false) {
            $retorno = [
              "status" => 'ERRO_API',
              "mensagem" => 'Erro na comunicação com a API do GSC'
            ];
            return;
          }
          
          $capa = $gsc->recPostDefinitition('CETAD - Armazenamento - Requisições CEDES',gsc_instance_id_armazenamento,gsc_user,gsc_user);
          
          if (isset($capa->error)) {
            $retorno = [
              "status" => 'ERRO_API',
              "mensagem" => $capa->error
            ];
            return;
          }

          $registerId = $capa->values->GSC_chrIDRegistro;
          $descricao = $this->geraResumo($json_post);
          
        
          

            foreach ($this->questionario as $q) {

                $q['values']['GSC_chrIDRegistroPai'] = $registerId;
                if ($q['values']['GSC_chrPergunta'] == "Qual o atendimento a ser realizado?")
                    $q['values']['GSC_chrResposta'] = $descricao;
                
                    $gsc->recPostQuestion($registerId,$q);
            }  


        //atualizando a requisição
        $gsc->recPutProcess($registerId,"Inicio");    

        $requestNumber =  $gsc->recGetRequestNumber($registerId);

          if ($requestNumber->entries[0]->values->GSC_chrNumeroRequisicao == 'ERRO') {

            $retorno = [
              "status" => 'ERRO_API',
              "mensagem" => $requestNumber->entries[0]->values->GSC_chrMensagem
            ];
            return;
          }

          $numreq = $requestNumber->entries[0]->values->GSC_chrNumeroRequisicao;
          //RETORNANDO REQ  
          $retorno = [
            "status" => 'OK',
            "requisicao" => $requestNumber->entries[0]->values->GSC_chrNumeroRequisicao,
            "mensagem" => $requestNumber->entries[0]->values->GSC_chrMensagem,
            "registroPai" => $requestNumber->entries[0]->values->GSC_chrIDRegistro
          ];
    } catch (\Exception $e) {
        $retorno = [
          "status" => 'ERRO',
          "mensagem" => $e->getMessage()
        ];
      } finally {  
        $gsc = null;      
        return  $retorno;
      }
  }

  public function cancelaRequisicao(String $requestNumber)
  {
    $retorno = false;
    try {
      $gsc = new GSCClient(gsc_endpoint, gsc_user, gsc_password);

      if ($gsc->connected == false) {
        $retorno = false;
        return;
      }
      $request = $gsc->recGetRequest($requestNumber);
      if (isset($request['error'])) {
        $retorno = false;
        return;
      }
      $retorno = $gsc->recPutCancelRequest($request->SysRequestID);
    } catch (\Exception $e) {
      $retorno = false;
    } finally {
      $gsc = null;
      return  $retorno;
    }
  }
}
