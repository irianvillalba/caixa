<?php

class Cota extends Record {
    
    const TABLENAME = 'solicitacao_limites_cotas';
    
}
