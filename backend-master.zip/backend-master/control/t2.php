<?php

print "t";