<?php

class Logger
{
	const LEVEL_OFF   	= 0;
	const LEVEL_INFO  	= 1;
	const LEVEL_ERROR 	= 2;
	const LEVEL_DEBUG 	= 3;
	
	const TYPE_TXT		= 'txt';
	const TYPE_XML		= 'xml';
	const TYPE_HTML		= 'html';
	
	const STD_TYPE 		= 'txt';
	const STD_LEVEL 	= 1;
	
	private $filelog;  		// local do arquivo de gravacao do LOG
    private $type;			// set tipo do arquivo 
    private $level_number;	// set leevl do arquivo de log
    private $config;		// array de captura do arquivo de configuracao
    
    public function __construct($filelog = NULL, $level = NULL) {
    	$this->type 		= self::STD_TYPE;	// set standard type
    	$this->level_number = self::STD_LEVEL;	// set standard level
   		$this->filelog 		= $filelog;			// set arquivo para saida do log
    }
    
    public function loadFileConfig($fileconfig) {
    // carrega arquivo de configuracao
    	if (file_exists($fileconfig)) {									// se o arquivo existe							
    		$this->config 		= parse_ini_file($fileconfig);			// carrega array de configuracao
    		$type = isset($this->config['log_type']) ? 					// set var type	
    					$this->config['log_type'] : self::STD_TYPE;		
    		$this->setType($type);
    		$level = isset($this->config['log_level']) ?				// set var level
    					$this->config['log_level'] : self::STD_LEVEL;
    		$this->setLevel($level);
    		if (isset($this->config['log_file'])) {
    			$this->filelog = $this->config['log_file'];
    		}
    	} else {
    		throw new Exception(										// se nao encontra arquivo
    			"Arquivo de configuracao '{$fileconfig}' nao encontrado");	// lanca uma exception
    	}
    }
    
    public function setFileLog($filelog) { $this->filelog = $filelog; }

    public function setLevel($level) {
    // set level entre 0 [OFF} e 3 [DEBUG]
    	if ( $level >= self::LEVEL_OFF and $level <= self::LEVEL_DEBUG ) {
    		$this->level_number = $level;
    	} else {
    		$this->level_number = self::STD_LEVEL; 	// carrega standard (INFO) caso opcao '$level' invalida
    	}
    }
    
    public function getlevel() { $this->level_number; }
    
    public function setType($type) {
    // set type caso entre 'html' e 'xml'
    	if ( ($type === 'html') or ($type === 'xml') ) {
    		$this->type = $type;
    	} else {
    		$this->type = self::STD_TYPE;	// carrega standard (txt) caso opcao '$type' invalida
    	}
    }
    
    public function write($message, $level = null) {
    	if (isset($this->filelog)) {
    		$level = isset($level) ? $level : self::STD_LEVEL;
    		if (  $level <= $this->level_number) {
    	   		date_default_timezone_set('America/Sao_Paulo');
    			$time = date("Y-m-d H:i:s");
    			switch ($this->type) {
    				case 'txt':
    					$text = "$time :: $message\n";
    					break;
    				case 'xml':
    					$text = "<log>\n";
    					$text.= "   <time>$time</time>\n";
    					$text.= "   <message>$message</message>\n";
    					$text.= "</log>\n";
    					break;
    				case 'html':
    					$text = "<p>\n";
    					$text.= "   <b>$time</b> : \n";
    					$text.= "   <i>$message</i> <br>\n";
    					$text.= "</p>\n";
    					break;
    			} // end_switch
    			$handler = fopen($this->filelog, 'a');
    			fwrite($handler, $text);
    			fclose($handler);
    		} // end_if
     	} else {
    		throw new Exception('Nao foi informado arquivo de gravacao de log');
    	}
    } // end_function write()
    
    
}









