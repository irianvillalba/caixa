Lista os se as solicaçãoes já possuem backends cadastrados, geradas à partir de uma solicitação de infraestrutura.

|MÉTODO|CHAMADA|
|:----------|:-----------|
|GET|https://infra.devops.caixa/api/api.php?acao=listarRelacionamentosBackend|

-----

#### Retorno

Para cada registro encontrado, as seguintes informações são retornadas na consulta:

|VALOR|DESCRIÇÃO|
|:----------:|:-----------:|
|**id_solicitacao**|ID da solciitação que originou a necessidade de relacionamento.|
|**sistema**|Nome do sistema a ser relacionado.|
|**ambiente**|Ambiente de execução do sistema.|
|**tipo**|Tipo do backend.|
|**data_solicitacao**|Data na qual a solicitação foi realizada.|



-----


#### Exemplo de Retorno esperado

```json
{
	"registros": 43,
	"dados": [
		{
			"id_solicitacao": 40,
			"sistema": "sicac",
			"ambiente": "prd",
			"tipo": "mq",
			"data_solicitacao": "2019-12-26 20:23:50"
		},
...
		{
			"id_solicitacao": 71,
			"sistema": "siabc",
			"ambiente": "des",
			"tipo": "db2",
			"data_solicitacao": "2020-02-06 11:44:55"
		}
	]
}
```