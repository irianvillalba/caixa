<?php
class GSCClient {
    public $token;    
    private $ch;
    private $endpoint;
    private $user;
    private $password;
    public $connected=false;
    function __construct(String $endpoint,String $user,String $password)
    {
        $this->ch = curl_init();
        $this->endpoint = $endpoint;
        $this->user = $user;
        $this->password = $password;
        $this->connected = $this->login();
    }

    function __destruct()
    {
        $this->logoff();
    }

    public function gerarREQ($titulo,$gscInstanceId,$questionario){
       try{
        //CRIA A CAPA DA REQ
        $capa = $this->recPostDefinitition($titulo,$gscInstanceId,$this->user,$this->user);
        if (isset($capa->error)) {
        throw new Exception($capa->error, 1);        
        }
        //RECUPERA O REGISTER ID
        $registerId = $capa->values->GSC_chrIDRegistro;

        
        //RESPONDE AS QUESTÕES
        foreach ($questionario as $key => $question) {
            $respondida = false;
            $question['values']['GSC_chrIDRegistroPai'] = $registerId;
            if(isset($question['values']['QuestionDef_InstanceID'])){
                $respostas = $this->recGetQuestionChoices($question['values']['QuestionDef_InstanceID']);
                if (isset($respostas->error)) {
                    throw new Exception($respostas->error, 1);        
                }
                $question['values']['GSC_chrResposta'] = $respostas->entries[$question['values']['ItemIndex']]->values->ChoiceLabel;
                unset($question['values']['QuestionDef_InstanceID']);
                unset($question['values']['ItemIndex']);
                
            }
            $resp = $this->recPostQuestion($registerId,$question);
             //if($resp){
             //    echo $question['values']['GSC_chrResposta'];
            // }
            //print_r($question);
        }
        //exit();

        //atualizando a requisição
        if($this->recPutProcess($registerId,"Inicio")){
            $requestNumber =  $this->recGetRequestNumber($registerId);
            if (isset($requestNumber->error)) {
                throw new Exception($requestNumber->error, 1);        
            }
            return $requestNumber;
        }else {
            throw new Exception("GSC - não foi possível dar início a requisição", 1);  
        }

        

    }catch(Exception $e){
        return json_decode('{"error":"'.$e->getMessage().'"}');
    }
    }

    public function login ():bool {
        try{
            $options = array(
                CURLOPT_URL =>              $this->endpoint . '/api/jwt/login',
                CURLOPT_POST =>             1,
                CURLOPT_POSTFIELDS =>       "username={$this->user}&password={$this->password}",
                CURLOPT_RETURNTRANSFER =>    1,
                CURLOPT_TIMEOUT => 25,
                CURLOPT_HTTPHEADER =>       array(
                    "Content-Type:application/x-www-form-urlencoded",
                    'cache-control:no-cache'
                )
            );
    
            curl_setopt_array($this->ch, $options);
            $result = curl_exec($this->ch);
            if(curl_errno($this->ch)){
                return false;
            }   
            
            $status = curl_getinfo($this->ch,CURLINFO_HTTP_CODE);
            switch ($status) {
                case 200:
                    $this->token = 'AR-JWT '.$result;
                   return true;
                    break;                
                default:
                    return false;
                    break;
            }            
        }catch(Exception $e){
            return false;
        }
        
    }
    public function logoff():bool {
        try{
        $this->user = null;
        $this->password = null;
        $post = json_encode(array('logout' => true));
        $options = array(
            CURLOPT_URL =>              $this->endpoint . '/api/jwt/logout',
            CURLOPT_RETURNTRANSFER =>   true,
            CURLOPT_ENCODING =>         "",
            CURLOPT_MAXREDIRS =>        10,
            CURLOPT_TIMEOUT =>          0,
            CURLOPT_FOLLOWLOCATION =>   true,
            CURLOPT_HTTP_VERSION =>     CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST =>    "POST",
            CURLOPT_POSTFIELDS =>       $post,
            CURLOPT_HTTPHEADER =>       array(
                "Content-Type:application/json",
                'Authorization:' . $this->token
            )
        );

        curl_setopt_array($this->ch, $options);
        $result = curl_exec($this->ch);
        if(curl_errno($this->ch)){
            return false;
        }   
        
        $status = curl_getinfo($this->ch,CURLINFO_HTTP_CODE);
        switch ($status) {
            case 204:                
               return true;
                break;                
            default:
                return false;
                break;
        }
        return true;
    }catch(Exception $e){
        return false;
    }finally{
        curl_close($this->ch);
    }
    }

    public function recGetRequestDefinition(String $title) {
        try{
        $options = array(
                    CURLOPT_URL =>  $this->endpoint . "/api/arsys/v1/entry/SRD:ServiceRequestDefinition?q='SRD_Title'%3D%22{$title}%22",
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_ENCODING => "",
                    CURLOPT_MAXREDIRS => 10,
                    CURLOPT_TIMEOUT => 5,
                    CURLOPT_FOLLOWLOCATION => true,
                    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                    CURLOPT_CUSTOMREQUEST => "GET",
                    CURLOPT_HTTPHEADER =>       array(
                        "Content-Type:application/json",
                        'Authorization:' . $this->token
                    )
                );
                curl_setopt_array($this->ch, $options);
                $result = curl_exec($this->ch);
                if(curl_errno($this->ch)){
                    return  json_decode('{"error":"recGetRequestDefinition-Falha ao executar o comando."}');
                }   
                
                $status = curl_getinfo($this->ch,CURLINFO_HTTP_CODE);
                switch ($status) {
                    case 200:                       
                       return json_decode($result);
                        break;                
                    default:
                        return json_decode('{"error":"recGetRequestDefinition-Response code: '.$status.'"}');
                        break;
                }
        }catch(Exception $e){
            return json_decode('{"error":"recGetRequestDefinition-'.$e->getMessage().'"}');
        }
        
    }

    public function recGetQuestions(String $instanceId) {
        try{
            $options = array(
                        CURLOPT_URL =>  $this->endpoint . "/api/arsys/v1/entry/SRM:QuestionDef_SRD?q='SRD_ID'%3D%22{$instanceId}%22",
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_ENCODING => "",
                        CURLOPT_MAXREDIRS => 10,
                        CURLOPT_TIMEOUT => 5,
                        CURLOPT_FOLLOWLOCATION => true,
                        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                        CURLOPT_CUSTOMREQUEST => "GET",
                        CURLOPT_HTTPHEADER =>       array(
                            "Content-Type:application/json",
                            'Authorization:' . $this->token
                        )
                    );
                    curl_setopt_array($this->ch, $options);
                    $result = curl_exec($this->ch);
                    if(curl_errno($this->ch)){
                        return  json_decode('{"error":"recGetQuestions-Falha ao executar o comando."}');
                    }   
                    
                    $status = curl_getinfo($this->ch,CURLINFO_HTTP_CODE);
                    switch ($status) {
                        case 200:                       
                           return json_decode($result);
                            break;                
                        default:
                            return json_decode('{"error":"recGetQuestions- Response code: '.$status.'"}');
                    }
            }catch(Exception $e){
                return json_decode('{"error":"recGetQuestions-'.$e->getMessage().'"}');
            }

    }

    public function recGetQuestionChoices(String $questionId) {
        
        try{
            $options = array(
                        CURLOPT_URL =>  $this->endpoint . "/api/arsys/v1/entry/SRM:QuestionChoices?q='QuestionDef_InstanceID'%3D%22{$questionId}%22",
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_ENCODING => "",
                        CURLOPT_MAXREDIRS => 10,
                        CURLOPT_TIMEOUT => 5,
                        CURLOPT_FOLLOWLOCATION => true,
                        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                        CURLOPT_CUSTOMREQUEST => "GET",
                        CURLOPT_HTTPHEADER =>       array(
                            "Content-Type:application/json",
                            'Authorization:' . $this->token
                        )
                    );
                    curl_setopt_array($this->ch, $options);
                    $result = curl_exec($this->ch);
                    if(curl_errno($this->ch)){
                        return  json_decode('{"error":"recGetQuestionChoices-Falha ao executar o comando."}');
                    }   
                    
                    $status = curl_getinfo($this->ch,CURLINFO_HTTP_CODE);
                    switch ($status) {
                        case 200:                       
                           return json_decode($result);
                            break;                
                        default:
                            return json_decode('{"error":"recGetQuestionChoices-Response code: '.$status.$result.'"}');
                            break;
                    }
            }catch(Exception $e){
                return json_decode('{"error":"recGetQuestionChoices-'.$e->getMessage().'"}');
            }
    }

    public function recPostDefinitition(String $title,String $instanceId,String $userFor,String $userTo)  {
        $post = json_encode(array('values' => array(
            "GSC_ddlStatus" => 'Processar',
            "GSC_chrTituloRequisicao" => $title,
            "GSC_chrIDInstancia" => $instanceId,
            "GSC_ddlStatusRequisicao" => 'Draft',
            "GSC_chrSolicitadoPor" => $userFor,
            "GSC_chrSolicitadoPara" => $userTo,
            "GSC_ddlOrigem" => 'Web Services'
        )));

        


        try{
            $options = array(
                CURLOPT_URL =>              $this->endpoint .'/api/arsys/v1/entry/GSC:RF223:IntSRM_Definicao?fields=values(GSC_chrIDRegistro,GSC_chrNumeroRequisicao)',
                CURLOPT_RETURNTRANSFER =>   true,
                CURLOPT_ENCODING =>         "",
                CURLOPT_MAXREDIRS =>        10,
                CURLOPT_TIMEOUT =>          0,
                CURLOPT_FOLLOWLOCATION =>   true,
                CURLOPT_HTTP_VERSION =>     CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST =>    "POST",
                CURLOPT_POSTFIELDS =>       $post,
                CURLOPT_HTTPHEADER =>       array(
                    "Content-Type:application/json",
                    'Authorization:' . $this->token
                )
            );
                    curl_setopt_array($this->ch, $options);
                    $result = curl_exec($this->ch);
                    if(curl_errno($this->ch)){
                       
                        return json_decode('{"error":"recPostDefinitition-Falha ao executar o comando."}');
                    }   

                    $status = curl_getinfo($this->ch,CURLINFO_HTTP_CODE);
                   
                    switch ($status) {
                        case 201:                                              
                           return json_decode($result);
                            break;                
                        default:
                            $erros = json_decode($result);
                            return json_decode('{"error":"recPostDefinitition-Response code: '.$status.'-'.$erros[0]->messageText.'"}');
                            break;
                    }
            }catch(Exception $e){
                
                return json_decode('{"error":"recPostDefinitition-'.$e->getMessage().'"}');
            }
    }
    public function recPostQuestion(String $registerId, array $questions) : bool{        
        
               try{
                
        $questao = json_encode($questions, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
         
            $options
             = array(
                CURLOPT_URL =>              $this->endpoint .'/api/arsys/v1/entry/GSC:RF224:IntSRM_Perguntas?fields=values(GSC_chrIDRegistro)',
                CURLOPT_POST =>             1,   
                CURLOPT_HEADER =>           false,
                CURLOPT_CUSTOMREQUEST =>    "POST",
                CURLOPT_POSTFIELDS =>       $questao,
                CURLOPT_HTTPHEADER =>       array("Accept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7"), 
                CURLOPT_RETURNTRANSFER=>    1,
                CURLOPT_HTTPHEADER =>       array(
                    "Content-Type:application/json",
                    'Authorization:' . $this->token
                )
            );
                    curl_setopt_array($this->ch, $options);
                    $result = curl_exec($this->ch);
                    if(curl_errno($this->ch)){
                        return false;
                    }   
                    
                    $status = curl_getinfo($this->ch,CURLINFO_HTTP_CODE);
                    switch ($status) {
                        case 200:                       
                           return true;
                            break;
                            case 201:                       
                                return true;
                                 break;
                                 case 204:                       
                                    return true;
                                     break;                
                        default:
                            return false;
                            break;
                    }
            }catch(Exception $e){
                return false;
            }
    }

    public function recPutProcess(String $registerId, String $status) : bool{
        try{
            $post = json_encode(array('values' => array(
                "GSC_ddlStatus" => $status
            )));
    
           $options = array(
                CURLOPT_URL =>              $this->endpoint . "/api/arsys/v1/entry/GSC:RF223:IntSRM_Definicao/{$registerId}",
                CURLOPT_HEADER =>           true,
                CURLOPT_CUSTOMREQUEST =>    "PUT",
                CURLOPT_POST =>             1,
                CURLOPT_POSTFIELDS =>       $post,
                CURLOPT_RETURNTRANSFER =>    1,
                CURLOPT_HTTPHEADER =>       array(
                    "Content-Type:application/json",
                    'Authorization:' . $this->token,
                    "X-AR-Client-Type:34"
                )
            );
        
                curl_setopt_array($this->ch, $options);
                $result = curl_exec($this->ch);
                if(curl_errno($this->ch)){
                    return false;
                }   
                
                $status = curl_getinfo($this->ch,CURLINFO_HTTP_CODE);
                switch ($status) {
                    case 200:                       
                       return true;
                        break;
                        case 201:                       
                            return true;
                             break;
                             case 204:                       
                                return true;
                                 break;                
                    default:
                        return false;
                        break;
                }
        }catch(Exception $e){
            return false;
        }
        

    }

    public function recGetRequestNumber(String $registerId){
        try{
            $options = array(
                CURLOPT_URL =>  $this->endpoint . "/api/arsys/v1/entry/GSC:RF223:IntSRM_Definicao?q='GSC_chrIDRegistro'%3D%22" .$registerId. "%22&fields=values(GSC_chrIDRegistro,GSC_chrNumeroRequisicao,GSC_chrMensagem)",
                CURLOPT_HEADER =>           false,
                CURLOPT_CUSTOMREQUEST =>    "GET",
                CURLOPT_RETURNTRANSFER =>    1,
                CURLOPT_HTTPHEADER =>       array(
                    "Content-Type:application/json",
                    'Authorization:' . $this->token
                )
            );
                    curl_setopt_array($this->ch, $options);
                    $result = curl_exec($this->ch);
                    if(curl_errno($this->ch)){
                        return  json_decode('{"error":"recGetRequestNumber-Falha ao executar o comando."}');
                    }   
                    
                    $status = curl_getinfo($this->ch,CURLINFO_HTTP_CODE);
                    switch ($status) {
                        case 200:                       
                           return json_decode($result);
                            break;                
                        default:
                        $erros = json_decode($result);
                        return json_decode('{"error":"recGetRequestNumber-Response code: '.$status.'-'.$erros[0]->messageText.'"}');
                            break;
                    }
            }catch(Exception $e){
                return json_decode('{"error":"recGetRequestNumber-'.$e->getMessage().'"}');
            }
    }

    public function recGetRequest(String $requestNumber){
        try{
            $options = array(
                CURLOPT_URL =>  $this->endpoint . "/api/arsys/v1/entry/SRM:Request?q=%27Request%20Number%27%3D%22{$requestNumber}%22",
                CURLOPT_HEADER =>           false,
                CURLOPT_CUSTOMREQUEST =>    "GET",
                CURLOPT_RETURNTRANSFER =>    1,
                CURLOPT_HTTPHEADER =>       array(
                    "Content-Type:application/json",
                    'Authorization:' . $this->token
                )
            );
                    curl_setopt_array($this->ch, $options);
                    $result = curl_exec($this->ch);
                    if(curl_errno($this->ch)){
                        return  json_decode('{"error":"recGetRequest-Falha ao executar o comando."}');
                    }   
                    
                    $status = curl_getinfo($this->ch,CURLINFO_HTTP_CODE);
                    switch ($status) {
                        case 200:                       
                           return json_decode($result);
                            break;                
                        default:
                        $erros = json_decode($result);
                        return json_decode('{"error":"recGetRequest-Response code: '.$status.'-'.$erros[0]->messageText.'"}');
                            break;
                    }
            }catch(Exception $e){
                return json_decode('{"error":"recGetRequest-'.$e->getMessage().'"}');
            }
    }
    public function recPutRegisterLogActivity(String $sysRequestId, String $summary, String $details,String $secureLog='Yes',String $viewAccess='Public'):bool{
        try{
             $log = json_encode(array('values' => array(
                "z1D Action" => "MODIFY",
                "z1D_WorkInfoType" => "General Information",
                "z1D_WorkInfoSummary" => $summary,
                "z1D_WorkInfoDetails" => $details,
                "z1D_WorkInfoSecureLog" => $secureLog,
                "z1D_WorkInfoViewAccess" => $viewAccess,
            )));
    
           $options = array(
                CURLOPT_URL =>              $this->endpoint . "/api/arsys/v1/entry/SRM:RequestInterface/{$sysRequestId}",
                CURLOPT_HEADER =>           true,
                CURLOPT_CUSTOMREQUEST =>    "PUT",
                CURLOPT_POST =>             1,
                CURLOPT_POSTFIELDS =>       $log,
                CURLOPT_RETURNTRANSFER =>    1,
                CURLOPT_HTTPHEADER =>       array(
                    "Content-Type:application/json",
                    'Authorization:' . $this->token                    
                )
            );
        
                curl_setopt_array($this->ch, $options);
                $result = curl_exec($this->ch);
                if(curl_errno($this->ch)){
                    return false;
                }   
                
                $status = curl_getinfo($this->ch,CURLINFO_HTTP_CODE);
                switch ($status) {
                    case 200:                       
                       return true;
                        break;
                        case 201:                       
                            return true;
                             break;
                             case 204:                       
                                return true;
                                 break;                
                    default:
                        return false;
                        break;
                }
        }catch(Exception $e){
            return false;
        }
    }
    public function recGetLogActivity(String $requestNumber) {
        try{
            $options = array(
                CURLOPT_URL =>  $this->endpoint . "GET: /api/arsys/v1/entry/“SRM:WorkInfo?q='Request Number'%3D%22{$requestNumber}%22",
                CURLOPT_HEADER =>           false,
                CURLOPT_CUSTOMREQUEST =>    "GET",
                CURLOPT_RETURNTRANSFER =>    1,
                CURLOPT_HTTPHEADER =>       array(
                    "Content-Type:application/json",
                    'Authorization:' . $this->token
                )
            );
                    curl_setopt_array($this->ch, $options);
                    $result = curl_exec($this->ch);
                    if(curl_errno($this->ch)){
                        return  json_decode('{"error":"recGetLogActivity-Falha ao executar o comando."}');
                    }   
                    
                    $status = curl_getinfo($this->ch,CURLINFO_HTTP_CODE);
                    switch ($status) {
                        case 200:                       
                           return json_decode($result);
                            break;                
                        default:
                        $erros = json_decode($result);
                        return json_decode('{"error":"recGetLogActivity-Response code: '.$status.'-'.$erros[0]->messageText.'"}');
                            break;
                    }
            }catch(Exception $e){
                return json_decode('{"error":"recGetLogActivity-'.$e->getMessage().'"}');
            }
    }
    public function recPutCancelRequest(String $sysRequestId): bool {
        try{
            $log = json_encode(array('values' => array(
               "StatusUpdatedSource" => "User",
               "Status" => "Cancelled"
           )));
   
          $options = array(
               CURLOPT_URL =>              $this->endpoint . "/api/arsys/v1/entry/SRM:RequestInterface/{$sysRequestId}",
               CURLOPT_HEADER =>           true,
               CURLOPT_CUSTOMREQUEST =>    "PUT",
               CURLOPT_POST =>             1,
               CURLOPT_POSTFIELDS =>       $log,
               CURLOPT_RETURNTRANSFER =>    1,
               CURLOPT_HTTPHEADER =>       array(
                   "Content-Type:application/json",
                   'Authorization:' . $this->token                    
               )
           );
       
               curl_setopt_array($this->ch, $options);
               $result = curl_exec($this->ch);
               if(curl_errno($this->ch)){
                   return false;
               }   
               
               $status = curl_getinfo($this->ch,CURLINFO_HTTP_CODE);
               switch ($status) {
                   case 200:                       
                      return true;
                       break;
                       case 201:                       
                           return true;
                            break;
                            case 204:                       
                               return true;
                                break;                
                   default:
                       return false;
                       break;
               }
       }catch(Exception $e){
           return false;
       }
    }
}