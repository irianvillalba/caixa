<?php
class ConfigNuvemPublca
{

    //ENDPOINTS
    const ENDPOINT_REQ              = "/api/arsys/v1/entry/GSC:RF223:IntSRM_Definicao?fields=values(GSC_chrIDRegistro,GSC_chrNumeroRequisicao)";
    const ENDPOINT_QUESTIONARIO     = "/api/arsys/v1/entry/GSC:RF224:IntSRM_Perguntas?fields=values(GSC_chrIDRegistro)";
    const ENDPOINT_PROCESSAREQ      = "/api/arsys/v1/entry/GSC:RF223:IntSRM_Definicao";
    const ENDPOINT_LOGIN             = "/api/jwt/login";
    const ENDPOINT_LOGOUT             = "/api/jwt/logout";
    const API_HMP                   = "http://scthmapllx0106.df.caixa:8008";
    const API_PRD                   = "http://cctdcapllx0388.df.caixa:8008";


    const ENDPOINT_ALLOCATION_CRQ     = "/api/arsys/v1/entry/CHG:CFG%20Ticket%20Num%20Generator/";
    const ENDPOINT_GET_PEOPLE         = "/api/arsys/v1/entry/CTM:People/";
    const ENDPOINT_CREATE_CHANGE     = "/api/arsys/v1/entry/CHG:ChangeInterface_Create/";
    const ENDPOINT_QUERY_CHANGE     = "/api/arsys/v1/entry/CHG:Infrastructure%20Change/";



    //QUESTIONARIO
    public $questionario = [

        'menu1' => array("values" => array(
            "GSC_chrIDRegistroPai" => "",
            "GSC_chrPergunta" => "Qual o assunto para atendimento?",
            "GSC_chrResposta" => "Computação"
        )),

        'menu2' => array("values" => array(
        "GSC_chrPergunta" => "Selecione o item para atendimento",
        "GSC_chrResposta" => "Máquina Virtual",
        "GSC_chrSubPergunta" => "Selecione a atividade a ser executada",
        "GSC_chrSubSelecao" => "Criar e Configurar Máquina Virtual"
        )),

       
        'ambiente' => array("values" => array(
            "GSC_chrIDRegistroPai" => "",
            "GSC_chrPergunta" => "Ambiente / Subscrição",
            "GSC_chrResposta" => ""
            
        )),

        'dtAtendimento' => array("values" => array(
            "GSC_chrIDRegistroPai" => "",
            "GSC_chrPergunta" => "Data esperada para atendimento",
            "GSC_chrResposta" => "2023-12-28T19:00:00-03:00"
        )),

        'descricao' => array("values" => array(
            "GSC_chrIDRegistroPai" => "",
            "GSC_chrPergunta" => "Descrição da solicitação",
            "GSC_chrResposta" => ""
        ))
    ];

   
}
