<?php
class ConfigVip
{

    //ENDPOINTS
    const ENDPOINT_REQ              = "/api/arsys/v1/entry/GSC:RF223:IntSRM_Definicao?fields=values(GSC_chrIDRegistro,GSC_chrNumeroRequisicao)";
    const ENDPOINT_QUESTIONARIO     = "/api/arsys/v1/entry/GSC:RF224:IntSRM_Perguntas?fields=values(GSC_chrIDRegistro)";
    const ENDPOINT_PROCESSAREQ      = "/api/arsys/v1/entry/GSC:RF223:IntSRM_Definicao";
    const ENDPOINT_LOGIN             = "/api/jwt/login";
    const ENDPOINT_LOGOUT             = "/api/jwt/logout";
    const API_HMP                   = "http://scthmapllx0106.df.caixa:8008";
    const API_PRD                   = "http://cctdcapllx0388.df.caixa:8008";


    const ENDPOINT_ALLOCATION_CRQ     = "/api/arsys/v1/entry/CHG:CFG%20Ticket%20Num%20Generator/";
    const ENDPOINT_GET_PEOPLE         = "/api/arsys/v1/entry/CTM:People/";
    const ENDPOINT_CREATE_CHANGE     = "/api/arsys/v1/entry/CHG:ChangeInterface_Create/";
    const ENDPOINT_QUERY_CHANGE     = "/api/arsys/v1/entry/CHG:Infrastructure%20Change/";



    //QUESTIONARIO
    public $questionario = [

        'menu1' => array("values" => array(
            "GSC_chrIDRegistroPai" => "",
            "GSC_chrPergunta" => "Qual o tipo de serviço?",
            "GSC_chrResposta" => "Alterar configurações em balanceador"
        )),

        'menu2' => array("values" => array(
            "GSC_chrIDRegistroPai" => "",
            "GSC_chrPergunta" => "Detalhe do serviço",
            "GSC_chrResposta" => "SLB (balanceamento local)",
            "GSC_chrSubPergunta01" => "Qual o tipo de serviço?",
            "GSC_chrSelecao01" => "Alterar configurações em balanceador"
        )),

        'sistema' => array("values" => array(
            "GSC_chrIDRegistroPai" => "",
            "GSC_chrPergunta" => "Qual é o nome do sistema/serviço?",
            "GSC_chrResposta" => "",
            "GSC_chrSubPergunta01" => "Qual o tipo de serviço?",
            "GSC_chrSelecao01" => "Alterar configurações em balanceador",
            "GSC_chrSubPergunta02" => "Detalhe do serviço",
            "GSC_chrSelecao02" => "SLB (balanceamento local)"
        )),


        'vip' => array("values" => array(
            "GSC_chrIDRegistroPai" => "",
            "GSC_chrPergunta" => "Qual é o VIP de acesso ao sistema/serviço?",
            "GSC_chrResposta" => "",
            "GSC_chrSubPergunta01" => "Qual o tipo de serviço?",
            "GSC_chrSelecao01" => "Alterar configurações em balanceador",
            "GSC_chrSubPergunta02" => "Detalhe do serviço",
            "GSC_chrSelecao02" => "SLB (balanceamento local)"
        )),

        'FQDN' => array("values" => array(
            "GSC_chrIDRegistroPai" => "",
            "GSC_chrPergunta" => "Qual é o FQDN de acesso ao sistema/serviço?",
            "GSC_chrResposta" => "",
            "GSC_chrSubPergunta01" => "Qual o tipo de serviço?",
            "GSC_chrSelecao01" => "Alterar configurações em balanceador",
            "GSC_chrSubPergunta02" => "Detalhe do serviço",
            "GSC_chrSelecao02" => "SLB (balanceamento local)"
        )),


        'atividade' => array("values" => array(
            "GSC_chrIDRegistroPai" => "",
            "GSC_chrPergunta" => "Selecione a atividade a ser executada",
            "GSC_chrResposta" => "Solicitar inclusão de SLB (balanceamento local)",
            "GSC_chrSubPergunta01" => "Qual o tipo de serviço?",
            "GSC_chrSelecao01" => "Alterar configurações em balanceador",
            "GSC_chrSubPergunta02" => "Detalhe do serviço",
            "GSC_chrSelecao02" => "SLB (balanceamento local)"
        )),


        'dtInicio' => array("values" => array(
            "GSC_chrIDRegistroPai" => "",
            "GSC_chrPergunta" => "Data e Hora de execução",
            "GSC_chrResposta" => "2022-12-28T19:00:00-03:00",
            "GSC_chrSubPergunta01" => "Qual o tipo de serviço?",
            "GSC_chrSelecao01" => "Alterar configurações em balanceador",
            "GSC_chrSubPergunta02" => "Detalhe do serviço",
            "GSC_chrSelecao02" => "SLB (balanceamento local)",
            "GSC_chrSubPergunta03" => "Selecione a atividade a ser executada",
            "GSC_chrSelecao03" => "Solicitar inclusão de SLB (balanceamento local)"
        )),

        'dtFinal' => array("values" => array(
            "GSC_chrIDRegistroPai" => "",
            "GSC_chrPergunta" => "Prazo final do atendimento",
            "GSC_chrResposta" => "2022-12-28T19:00:00-03:00",
            "GSC_chrSubPergunta01" => "Qual o tipo de serviço?",
            "GSC_chrSelecao01" => "Alterar configurações em balanceador",
            "GSC_chrSubPergunta02" => "Detalhe do serviço",
            "GSC_chrSelecao02" => "SLB (balanceamento local)",
            "GSC_chrSubPergunta03" => "Selecione a atividade a ser executada",
            "GSC_chrSelecao03" => "Solicitar inclusão de SLB (balanceamento local)"
        )),

        'descricao' => array("values" => array(
            "GSC_chrIDRegistroPai" => "",
            "GSC_chrPergunta" => "Descrição da solicitação",
            "GSC_chrResposta" => ""
        ))
    ];


    public $questionarioDNS = [

        
        'menu0' => array("values" => array(
            "GSC_chrIDRegistroPai" => "",
            "GSC_chrPergunta" => "Informe a solicitação",
            "GSC_chrResposta" => "Inclusão"
        )),

        'menu1' => array("values" => array(
            "GSC_chrIDRegistroPai" => "",
            "GSC_chrPergunta" => "Endpoint de internet?",
            "GSC_chrResposta" => "Não",            
            "GSC_chrSubPergunta01" => "Informe a solicitação",
            "GSC_chrSelecao01" => "Inclusão"
        )),        
        'menu3' => array("values" => array(
            "GSC_chrIDRegistroPai" => "",
            "GSC_chrPergunta" => "Ambiente",
            "GSC_chrResposta" => "On premise",
            "GSC_chrSubPergunta02"=>"Endpoint de internet?",
            "GSC_chrSelecao02"=>"Não",
            "GSC_chrSubPergunta01"=>"Informe a solicitação",
            "GSC_chrSelecao01"=>"Inclusão"
        )),
        

        'menu4' => array("values" => array(
            "GSC_chrIDRegistroPai" => "",
            "GSC_chrPergunta" => "Tipo de registro",
            "GSC_chrResposta" => "Host (A)",
            "GSC_chrSubPergunta03"=>"Ambiente",
            "GSC_chrSelecao03"=>"On premise",
            "GSC_chrSubPergunta02"=>"Endpoint de internet?",
            "GSC_chrSelecao02"=>"Não",
            "GSC_chrSubPergunta01"=>"Informe a solicitação",
            "GSC_chrSelecao01"=>"Inclusão"
        )),

        'menu5' => array("values" => array(
            "GSC_chrIDRegistroPai" => "",
            "GSC_chrPergunta" => "Nome DNS",
            "GSC_chrResposta" => "",
            "GSC_chrSubPergunta04"=>"Tipo de registro",
            "GSC_chrSelecao04"=>"Host (A)",
            "GSC_chrSubPergunta03"=>"Ambiente",
            "GSC_chrSelecao03"=>"On premise",
            "GSC_chrSubPergunta02"=>"Endpoint de internet?",
            "GSC_chrSelecao02"=>"Não",
            "GSC_chrSubPergunta01"=>"Informe a solicitação",
            "GSC_chrSelecao01"=>"Inclusão"
        )),

        'menu6' => array("values" => array(
            "GSC_chrIDRegistroPai" => "",
            "GSC_chrPergunta" => "Endereço IP",
            "GSC_chrResposta" => "",
            "GSC_chrSubPergunta04"=>"Tipo de registro",
            "GSC_chrSelecao04"=>"Host (A)",
            "GSC_chrSubPergunta03"=>"Ambiente",
            "GSC_chrSelecao03"=>"On premise",
            "GSC_chrSubPergunta02"=>"Endpoint de internet?",
            "GSC_chrSelecao02"=>"Não",
            "GSC_chrSubPergunta01"=>"Informe a solicitação",
            "GSC_chrSelecao01"=>"Inclusão"            
        )),
        'menu7' => array("values" => array(
            "GSC_chrIDRegistroPai" => "",
            "GSC_chrPergunta" => "Unidade/Coordenação Demandante",
            "GSC_chrResposta" => "CESTI35",
            "GSC_chrSubPergunta04"=>"Tipo de registro",
            "GSC_chrSelecao04"=>"Host (A)",
            "GSC_chrSubPergunta03"=>"Ambiente",
            "GSC_chrSelecao03"=>"On premise",
            "GSC_chrSubPergunta02"=>"Endpoint de internet?",
            "GSC_chrSelecao02"=>"Não",
            "GSC_chrSubPergunta01"=>"Informe a solicitação",
            "GSC_chrSelecao01"=>"Inclusão"            
        )),

        'menu8' => array("values" => array(
            "GSC_chrIDRegistroPai" => "",
            "GSC_chrPergunta" => "Descrição/Observação",
            "GSC_chrResposta" => "",
            "GSC_chrSubPergunta04"=>"Tipo de registro",
            "GSC_chrSelecao04"=>"Host (A)",
            "GSC_chrSubPergunta03"=>"Ambiente",
            "GSC_chrSelecao03"=>"On premise",
            "GSC_chrSubPergunta02"=>"Endpoint de internet?",
            "GSC_chrSelecao02"=>"Não",
            "GSC_chrSubPergunta01"=>"Informe a solicitação",
            "GSC_chrSelecao01"=>"Inclusão"
        ))
    ];
   
}
