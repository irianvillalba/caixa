<?php
require_once "ConfigVip.php";
ini_set("xdebug.var_display_max_children", -1);
ini_set("xdebug.var_display_max_data", -1);
ini_set("xdebug.var_display_max_depth", -1);

class Vip
{
    public function criarRequisicaoVip(String $iplist,String $portas, $json_post) {
        $retorno = [];
     try{
      $gsc = new GSCClient(gsc_endpoint,gsc_user,gsc_password);
     
      if ($gsc->connected == false) {
        $retorno = [
          "title" => 'ERRO_API',
          "mensagem" => 'Erro na comunicação com a API do GSC'
        ];
        return;
      }

      $capa = $gsc->recPostDefinitition('Suporte à Rede Data Center',gsc_instance_id_vip,gsc_user,gsc_user);
      if (isset($capa->error)) {
        $retorno = [
          "title" => 'ERRO_API',
          "mensagem" => $capa->error
        ];
        return;
      }
      $registerId = $capa->values->GSC_chrIDRegistro;

      $dtE = date("Y-m-d") . "T19:00:00-03:00";
      $dtF = date("Y-m-d", strtotime('+1 day')) . "T19:00:00-03:00";

      $descricaoVip = " Solicitamos apontamento e configuração do VIP para os IPs reais listados: \n
    ****************************************************************************************** \n
    Lista de IPS : $iplist
    ******************************************************************************************\n
    PORTA:$portas \n 
    TEMPO DE PERSISTÊNCIA: 15 MINUTOS\n 
    PERSISTÊNCIA: IP\n 
    SSL OFFLOADING";

       $fqdn = $json_post["registros"]["fqdn"];
        $sistema = $json_post["registros"]['sistema'];
        $vipIp = $json_post['dados']["Gerar"]['0'];
        $config = new ConfigVip();        
        foreach ($config->questionario as $q) {

            $q['values']['GSC_chrIDRegistroPai'] = $registerId;
            if ($q['values']['GSC_chrPergunta'] == "Qual é o nome do sistema/serviço?")
                $q['values']['GSC_chrResposta'] = $sistema;
            if ($q['values']['GSC_chrPergunta'] == "Qual é o FQDN de acesso ao sistema/serviço?")
                $q['values']['GSC_chrResposta'] = $fqdn;
            if ($q['values']['GSC_chrPergunta'] == "Qual é o VIP de acesso ao sistema/serviço?")
                $q['values']['GSC_chrResposta'] = $vipIp;
            if ($q['values']['GSC_chrPergunta'] == "Data e Hora de execução")
                $q['values']['GSC_chrResposta'] = $dtE;
            if ($q['values']['GSC_chrPergunta'] == "Prazo final do atendimento")
                $q['values']['GSC_chrResposta'] = $dtF;
            if ($q['values']['GSC_chrPergunta'] == "Descrição da solicitação")
                $q['values']['GSC_chrResposta'] = $descricaoVip;
                $gsc->recPostQuestion($registerId,$q);
        }  
    

    //atualizando a requisição
    $gsc->recPutProcess($registerId,"Inicio");    

    $requestNumber =  $gsc->recGetRequestNumber($registerId);

      if ($requestNumber->entries[0]->values->GSC_chrNumeroRequisicao == 'ERRO') {

        $retorno = [
          "title" => 'ERRO_API',
          "mensagem" => $requestNumber->entries[0]->values->GSC_chrMensagem
        ];
        return;
      }

      $numreq = $requestNumber->entries[0]->values->GSC_chrNumeroRequisicao;
      //RETORNANDO REQ  
      $retorno = [
        "title" => 'OK',
        "requisicao" => $requestNumber->entries[0]->values->GSC_chrNumeroRequisicao,
        "mensagem" => $requestNumber->entries[0]->values->GSC_chrMensagem,
        "registroPai" => $requestNumber->entries[0]->values->GSC_chrIDRegistro
      ];
    } catch (\Exception $e) {
        $retorno = [
          "title" => 'ERRO',
          "mensagem" => $e->getMessage()
        ];
      } finally {   
        $gsc = null;     
        return  $retorno;
      }
    }
    
    public function criarRequisicaoDNS($json_post){
        $retorno = [];
try{
    
    $gsc = new GSCClient(gsc_endpoint,gsc_user,gsc_password);
      
      if ($gsc->connected == false) {
        $retorno = [
          "title" => 'ERRO_API',
          "mensagem" => 'Erro na comunicação com a API do GSC'
        ];
        return;
      }

      $descricao = "Solicitamos cadastrar o DNS informado.";
      $fqdn = $json_post["registros"]["fqdn"];
      $vipIp = $json_post['dados']["Gerar"]['0'];      
      $config = new ConfigVip();        
      $respostas = $config->questionarioDNS;
        foreach ($respostas as $key => $q) {            
            if ($q['values']['GSC_chrPergunta'] == "Nome DNS")
                $respostas[$key]['values']['GSC_chrResposta'] = $fqdn;
            if ($q['values']['GSC_chrPergunta'] == "Endereço IP")
                $respostas[$key]['values']['GSC_chrResposta'] = $vipIp;
            if ($q['values']['GSC_chrPergunta'] == "Descrição/Observação")
                $respostas[$key]['values']['GSC_chrResposta'] = $descricao;
                
                
        }
      $requestNumber = $gsc->gerarREQ('DNS - Solicitação',gsc_instance_id_dns,$respostas);
      if (isset($requestNumber->error)) {
        $retorno = [
          "title" => 'ERRO_API',
          "mensagem" => $requestNumber->error
        ];
        return;
      }

      if ($requestNumber->entries[0]->values->GSC_chrNumeroRequisicao == 'ERRO') {

        $retorno = [
          "title" => 'ERRO_API',
          "mensagem" => $requestNumber->entries[0]->values->GSC_chrMensagem
        ];
        return;
      }

      $numreq = $requestNumber->entries[0]->values->GSC_chrNumeroRequisicao;
      //RETORNANDO REQ  
      $retorno = [
        "title" => 'OK',
        "requisicao" => $requestNumber->entries[0]->values->GSC_chrNumeroRequisicao,
        "mensagem" => $requestNumber->entries[0]->values->GSC_chrMensagem,
        "registroPai" => $requestNumber->entries[0]->values->GSC_chrIDRegistro
      ];
} catch (\Exception $e) {
    $retorno = [
      "title" => 'ERRO',
      "mensagem" => $e->getMessage()
    ];
  } finally {  
    $gsc = null;      
    return  $retorno;
  }
    }

    

    public function cancelaRequisicao(String $requestNumber){
        $retorno = false;
        try{
            $gsc = new GSCClient(gsc_endpoint,gsc_user,gsc_password);
      
      if ($gsc->connected == false) {
        $retorno = false;
        return;
      }
      $request = $gsc->recGetRequest($requestNumber);
      if(isset($request['error'])){
        $retorno = false;
        return;
      }
      $retorno = $gsc->recPutCancelRequest($request->SysRequestID );
    } catch (\Exception $e) {
        $retorno =false;
      } finally {  
        $gsc = null;      
        return  $retorno;
      }
    }

    


    



    

    
}
