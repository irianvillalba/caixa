Relaciona os backends com as solicitações.

|MÉTODO|CHAMADA|
|:----------|:-----------|
|POST|https://infra.devops.caixa/api/api.php?acao=relacionarBackend|

-----

#### Parâmetros obrigatórios

|PARÂMETRO|DESCRIÇÃO|
|:----------|:-----------|
|**solicitacao**|ID da solicitação.|
|**ambiente**|Ambiente do backend.|
|**tipo_backend**|Tipo do backend a ser relacionado, conforme informado na solicitação.|
|**id_backend**|ID do backend a ser relacionado, conforme cadastro na base.|

> O **id_backend** corresponde ao ID originado após o cadastro utilizando a função [cadastrarBackend](https://infra.devops.caixa/docs/cadastrarBackend/).
> 
> Os IDs podem ser obtidos através de consulta no endpoint [listarBackend](https://infra.devops.caixa/docs/listarBackend/).

-----

#### Exemplo de JSON a ser usado na chamada

```json
{
  "solicitacao": "39",
    "ambiente": "tqs",
	  "backends": {
      "oracle": "6",
    }
}
```

-----

#### Retornos esperados

- No caso de Erros: `"Erro ao relacionar."`
- No caso de sucesso: `"Relacionamento realizado."`