Lista as solicitações de infraestrutura recepcionadas.

|MÉTODO|CHAMADA|
|:----------|:-----------|
|GET|https://infra.devops.caixa/api/api.php?acao=listarSolicitacoes|


-----

#### Retorno

Para cada registro encontrado, as seguintes informações são retornadas na consulta:

|VALOR|DESCRIÇÃO|
|:----------:|:-----------:|
|**id**|ID da solicitação.|
|**sistema**|Nome do sistema.|
|**repositorio**|Repositório do sistema no ADS.|
|**plataforma_tipo**|Tipo de Plataforma.|
|**plataforma_versao**|Versão da Plataforma.|
|**solicitante**|Usuário reponsável pela solicitação.|
|**centralizadora**|Centralizadora ou lotação do usuário.|
|**ambiente**|Ambiente a ser utilizado pelo sistema.|
|**data_solicitacao**|Data na qual a solicitação foi realizada.|
|**backends**|Listagem dos backends que serão utilizados pelo sistema.|

-----

#### Exemplo de chamada

```bash
https://infra.devops.caixa/api/api.php?acao=listarTiposBackend
```

-----


#### Exemplo de Retorno esperado

```json
{
	"registros": 25,
	"dados": [
		{
			"id": 57,
			"sistema": "siuuu",
			"repositorio": "http://labdevops.caixa/DefaultCollection/template_JAVA/_git/siads_ptr",
			"plataforma": {
				"tipo": "jboss",
				"versao": "7"
			},
			"solicitante": "c080028",
			"centralizadora": "7260",
			"ambiente": "des",
			"data_solicitacao": "2020-01-06 19:08:14",
			"backends": [
				"oracle"
			]
		},
    ...
  ]
}
    
```