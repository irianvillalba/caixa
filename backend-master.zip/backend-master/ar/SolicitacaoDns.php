<?php

class SolicitacaoDns extends Record {
    
    const TABLENAME = 'solicitacoes_dns';
    
}