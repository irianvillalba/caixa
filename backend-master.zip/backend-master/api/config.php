<?php
    class Config {

        //ENDPOINTS
        const ENDPOINT_FETCH_RISKS		= "/api/arsys/v1/entry/CHG:ChangeRiskFactors";
        const ENDPOINT_ALLOCATION_CRQ 	= "/api/arsys/v1/entry/CHG:CFG%20Ticket%20Num%20Generator/";
        const ENDPOINT_GET_PEOPLE 		= "/api/arsys/v1/entry/CTM:People/";
        const ENDPOINT_CREATE_CHANGE 	= "/api/arsys/v1/entry/CHG:ChangeInterface_Create/";
        const ENDPOINT_QUERY_CHANGE 	= "/api/arsys/v1/entry/CHG:Infrastructure%20Change/";
        const ENDPOINT_LOGIN 			= "/api/jwt/login";
        const ENDPOINT_LOGOUT 			= "/api/jwt/logout";
        const API_HMP                   = "http://scthmapllx0106.df.caixa:8008";
        const API_PRD                   = "http://cctdcapllx0388.df.caixa:8008";
        
        //QUESTIONARIO
        public $questionario = [
            'questao1' => array(
                "Infrastructure Change ID" =>   '',
                "Company" =>                    'CAIXA',
                "Status" =>                     'Enabled',
                "Question_Sequence" =>          1,
                "Template Instance Id" =>       "",
                "Risk Weight" =>                "2",
                "Risk Value (char)" =>          "NÃO",
                "Risk Value" =>                 "1",
                "Risk Factor" =>                "A mudança está relacionada a outra(s) mudança(s) e/ou envolve outros sites?\nSe SIM, informe o número da(s) mudanças na aba “Relacionamento” e/ou os sites envolvidos na Informação de trabalho “Avaliação de Risco”"
            ),
            'questao2' => array(
                "Infrastructure Change ID" =>   '',
                "Company" =>                    'CAIXA',
                "Status" =>                     'Enabled',
                "Question_Sequence" =>          2,
                "Template Instance Id" =>       "",
                "Risk Weight" =>                "5",
                "Risk Value (char)" =>          "NÃO",
                "Risk Value" =>                 "1",
                "Risk Factor" =>                "Haverá interrupção dos serviços que deveriam estar disponíveis, durante a execução da mudança?"
            ),
            'questao3' => array(
                "Infrastructure Change ID" =>   '',
                "Company" =>                    'CAIXA',
                "Status" =>                     'Enabled',
                "Question_Sequence" =>          3,
                "Template Instance Id" =>       "",
                "Risk Weight" =>                "3",
                "Risk Value (char)" =>          "BAIXA",
                "Risk Value" =>                 "1",
                "Risk Factor" =>                "Qual é a complexidade técnica para execução da mudança?"
            ),
            'questao4' => array(
                "Infrastructure Change ID" =>   '',
                "Company" =>                    'CAIXA',
                "Status" =>                     'Enabled',
                "Question_Sequence" =>          4,
                "Template Instance Id" =>       "",
                "Risk Weight" =>                "5",
                "Risk Value (char)" =>          "SIM",
                "Risk Value" =>                 "1",
                "Risk Factor" =>                "O componente alterado possui redundância?"
            ),
            'questao5' => array(
                "Infrastructure Change ID" =>   '',
                "Company" =>                    'CAIXA',
                "Status" =>                     'Enabled',
                "Question_Sequence" =>          5,
                "Template Instance Id" =>       "",
                "Risk Weight" =>                "4",
                "Risk Value (char)" =>          "SIM",
                "Risk Value" =>                 "1",
                "Risk Factor" =>                "O componente alterado tem cobertura contratual de suporte?"
            ),
            'questao6' => array(
                "Infrastructure Change ID" =>   '',
                "Company" =>                    'CAIXA',
                "Status" =>                     'Enabled',
                "Question_Sequence" =>          6,
                "Template Instance Id" =>       "",
                "Risk Weight" =>                "5",
                "Risk Value (char)" =>          "SIM",
                "Risk Value" =>                 "1",
                "Risk Factor" =>                "Existe plano de retorno definido?\\nDetalhe os procedimentos do plano ou justifique, quando não aplicável, na Informação de Trabalho “Plano de Retorno”."
            ),
            'questao7' => array(
                "Infrastructure Change ID" =>   '',
                "Company" =>                    'CAIXA',
                "Status" =>                     'Enabled',
                "Question_Sequence" =>          7,
                "Template Instance Id" =>       "",
                "Risk Weight" =>                "2",
                "Risk Value (char)" =>          "SIM",
                "Risk Value" =>                 "1",
                "Risk Factor" =>                "Haverá validação do ambiente após a execução da mudança?\\nSe SIM, informe o período que a validação será realizada e a unidade que a executará."
            )
        ];

        public $templateHMP = [
            "CHGAA5V0F9LE5AP90FTOP83C5V0BHM",
            "CHGAA5V0F9LE5AP90FU1P83C680BHQ",
            "CHGAA5V0F9LE5AP90FVAP83C7I0BHU",
            "CHGAA5V0F9LE5AP90FVSP83C7Z0BHZ",
            "CHGAA5V0F9LE5AP90FWKP83C8R0BID",
            "CHGAA5V0F9LE5AP90FXJP83C960BIH",
            "CHGAA5V0F9LE5AP90FYAP83CKI0BI1"
        ];

        public $templatePRD = [
            "CHGAA5V0HHG1YAPMV1MBPLYDR60L04",
            "CHGAA5V0HHAKPAPMV1OBPLYDT7CZA4",
            "CHGAA5V0HHJP7APMV1OZPLYDU5UIRF",
            "CHGAA5V0HHJP7APMV1PTPLYDVIUJJN",
            "CHGAA5V0HHAKPAPMV1RNPLYDXCDBQD",
            "CHGAA5V0HHI8LAPMV1TEPLYDY9QNZ3",
            "CHGAA5V0HHJP7APMV1TSPLYDZIU2XR"
        ];
    }
?>